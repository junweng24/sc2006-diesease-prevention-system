// TODO: Configure Vite with the React plugin and proxy API requests to the Express backend.
