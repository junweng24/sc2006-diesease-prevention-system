// TODO: Mount <App /> into the #root element.
