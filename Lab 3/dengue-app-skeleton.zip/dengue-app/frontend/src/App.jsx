// TODO: Root component: set up routing for public pages (map, report, alerts, subscribe, volunteer) and official pages (login, review, manage).
// TODO: Each page calls the backend HTTP routes exposed by the server control classes.
