// TODO: NotificationChannel (<<interface>>, Strategy): contract for a delivery channel.
// TODO: type: ChannelType.
// TODO: send(recipient, message): deliver message; implementations throw on failure.
