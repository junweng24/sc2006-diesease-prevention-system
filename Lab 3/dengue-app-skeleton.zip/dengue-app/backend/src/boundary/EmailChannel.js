// TODO: EmailChannel (<<boundary>>): implements NotificationChannel for email (type = EMAIL).
// TODO: send(recipient, message): deliver via the external email service.
