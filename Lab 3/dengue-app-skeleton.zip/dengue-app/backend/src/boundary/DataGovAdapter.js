// TODO: DataGovAdapter (<<boundary>>): wrapper for the data.gov.sg external API.
// TODO: fetchDengueClusters(): return DengueCluster[].
// TODO: fetchClinics(): return Clinic[].
