// TODO: SmsChannel (<<boundary>>): implements NotificationChannel for SMS (type = SMS).
// TODO: send(recipient, message): deliver via the external SMS gateway.
