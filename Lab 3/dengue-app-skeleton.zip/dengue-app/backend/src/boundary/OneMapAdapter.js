// TODO: OneMapAdapter (<<boundary>>): wrapper for the OneMap geocoding API.
// TODO: search(query): return matching GeoLocation[].
// TODO: reverseGeocode(lat, lng): return the GeoLocation for the coordinates.
