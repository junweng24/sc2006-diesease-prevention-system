// TODO: ServerApp (<<startup>>): application entry point.
// TODO: Hold private fields: config (Config) and db (Database).
// TODO: start(): read Config, open Database, build repositories, build controllers, register routes, listen.
// TODO: buildRepositories(): instantiate every repository with the shared Database.
// TODO: buildControllers(): create and wire every control class with its repositories, services and boundary adapters.
// TODO: buildControllers(): register NotificationChannel strategies (SmsChannel, EmailChannel) with NotificationService.
// TODO: registerRoutes(): map Express HTTP routes to controller methods (routes omitted from design).
