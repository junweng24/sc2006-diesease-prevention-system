// TODO: Config (<<singleton>>): application configuration read by ServerApp.
// TODO: getInstance(): static; return the single shared Config instance (load env/settings once).
