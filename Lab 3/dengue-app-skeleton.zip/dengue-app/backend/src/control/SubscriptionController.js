// TODO: SubscriptionController (<<control>>): public alert subscriptions.
// TODO: Uses SubscriptionRepository and NotificationService.
// TODO: subscribe(input): validate, save AlertSubscription, send confirmation; return the subscription.
