// TODO: VolunteerActivityController (<<control>>): officials manage volunteer activities.
// TODO: Uses VolunteerActivityRepository, VolunteerRegistrationRepository and NotificationService (listener, Observer).
// TODO: listActivities(filter, now): return activities with refreshed status.
// TODO: createActivity(input, officialId, now): validate, save and notify activity published.
// TODO: editActivity(id, changes, now): validate changes against current registrations and save.
// TODO: getActivityStatus(id): return ActivityStatusSummary (quota, registered, remaining).
// TODO: getRoster(id): return VolunteerRegistration[] for the activity.
