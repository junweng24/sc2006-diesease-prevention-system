// TODO: HotspotReportController (<<control>>): public submission and official review of hotspot reports.
// TODO: Uses HotspotReportRepository, HotspotRepository and InputValidator.
// TODO: submitReport(input, photo, now): validate, generate referenceId, store photo and report; return referenceId.
// TODO: listReports(filter): return HotspotReport[] matching filter.
// TODO: getReport(referenceId): return one HotspotReport.
// TODO: reviewReport(referenceId, status, officialId, version, now): check version, transition status, create Hotspot when verified.
