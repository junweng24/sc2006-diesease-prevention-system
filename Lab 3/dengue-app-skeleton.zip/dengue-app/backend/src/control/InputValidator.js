// TODO: InputValidator (<<control>>): stateless validation used by every controller before touching entities or repositories.
// TODO: All methods are static and return a ValidationResult (valid flag + field errors).
// TODO: validateReportInput(input), validatePhoto(file), validateLocation(location) (must be within Singapore).
// TODO: validateRegistrationInput(input), validateActivityInput(input, now, registered).
// TODO: validateAlertInput(input), validateSubscriptionInput(input), validateHotspotInput(input, diseaseTypes).
