// TODO: PasswordHasher (<<control>>): password hashing.
// TODO: hash(plain): return a salted hash string.
// TODO: verify(plain, hash): return whether the plain password matches the hash.
