// TODO: AuthController (<<control>>): official login, logout and token verification.
// TODO: Uses OfficialRepository, TokenService and PasswordHasher.
// TODO: login(username, password, now): check lockout, verify hash, record failures or reset; return Session with token.
// TODO: logout(token): invalidate the session token.
// TODO: verifyToken(token): return Claims for an authenticated official.
