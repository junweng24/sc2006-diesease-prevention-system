// TODO: ClinicController (<<control>>): find nearby clinics.
// TODO: Uses ClinicCache.
// TODO: findNearest(location, now): validate location, sort clinics by distance; return NearbyClinics.
