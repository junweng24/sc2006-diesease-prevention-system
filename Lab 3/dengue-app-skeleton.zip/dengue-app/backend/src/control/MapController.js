// TODO: MapController (<<control>>): supply data for the map view.
// TODO: Uses HotspotRepository, ClusterCacheRepository, ClinicCache and OneMapAdapter.
// TODO: getMapData(filter, now): combine active hotspots, dengue clusters and clinics into MapData.
// TODO: searchAddress(query): validate and delegate to OneMapAdapter.search; return GeoLocation[].
// TODO: reverseGeocode(lat, lng): validate and delegate to OneMapAdapter.reverseGeocode.
