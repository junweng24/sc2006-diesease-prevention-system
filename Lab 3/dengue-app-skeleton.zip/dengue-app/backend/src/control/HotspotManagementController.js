// TODO: HotspotManagementController (<<control>>): officials manage hotspots directly.
// TODO: Uses HotspotRepository and InputValidator.
// TODO: listHotspots(filter): return Hotspot[].
// TODO: addHotspot(input, officialId): validate and create an OFFICIAL-source Hotspot.
// TODO: removeHotspot(hotspotId): call Hotspot.remove() and save.
