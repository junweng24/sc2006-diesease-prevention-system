// TODO: NotificationService (<<control>>): Observer listener notified by alert and activity controllers.
// TODO: Holds NotificationChannel strategies (SMS, EMAIL); uses SubscriptionRepository and NotificationLogRepository.
// TODO: notifyAlertPublished(alert): send to matching subscribers via their channels, log each attempt; return DispatchSummary.
// TODO: notifyActivityPublished(activity): notify subscribers who want volunteer news; return DispatchSummary.
// TODO: sendSubscriptionConfirmation(sub): send a confirmation message to a new subscriber.
