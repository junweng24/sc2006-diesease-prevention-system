// TODO: PublicAlertController (<<control>>): manage public alerts.
// TODO: Uses InputValidator, PublicAlertRepository and NotificationService (listener, Observer).
// TODO: listPublishedAlerts(): return all published PublicAlerts.
// TODO: getAlert(id): return one PublicAlert or a not-found error.
// TODO: previewAlert(input): validate input and return an AlertPreview (incl. SMS text) without saving.
// TODO: publishAlert(input, officialId, now): validate, save the alert, notify NotificationService, return PublishResult.
