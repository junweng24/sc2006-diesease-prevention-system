// TODO: VolunteerEnrollmentController (<<control>>): public volunteer sign-up.
// TODO: Uses VolunteerActivityRepository and VolunteerRegistrationRepository (within a Database transaction).
// TODO: listOpenActivities(now): return activities that can accept registrations.
// TODO: register(activityId, input, now): validate, check canAcceptRegistration, save registration, update counts/status.
