// TODO: TokenService (<<control>>): issue and verify session tokens.
// TODO: issue(payload): return a signed token string.
// TODO: verify(token): return decoded Claims or throw if invalid/expired.
