// TODO: Database (<<singleton>>): shared database connection, created by ServerApp.
// TODO: getInstance(file): static; return the single Database instance for the given file.
// TODO: query(sql, params): run a parameterised query, return Rows.
// TODO: transaction(work): run work inside a transaction and return its result.
