// TODO: VolunteerRegistrationRepository (<<container>>): extends Repository<VolunteerRegistration>.
// TODO: Implement save(entity) and toEntity(row) for VolunteerRegistration.
// TODO: Add lookup of registrations by activity id (roster).
