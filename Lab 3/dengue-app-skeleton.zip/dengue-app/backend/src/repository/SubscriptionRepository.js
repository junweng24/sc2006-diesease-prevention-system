// TODO: SubscriptionRepository (<<container>>): extends Repository<AlertSubscription>.
// TODO: Implement save(entity) and toEntity(row) for AlertSubscription.
// TODO: Add queries for subscribers by region / volunteer-news preference.
