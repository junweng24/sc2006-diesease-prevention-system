// TODO: Repository<T> (<<container>>, abstract): generic base class for all repositories.
// TODO: findById(id): return one T or null.
// TODO: findAll(): return T[].
// TODO: save(entity): abstract; insert or update entity, return T.
// TODO: toEntity(row): abstract, protected; map a database row to an entity.
