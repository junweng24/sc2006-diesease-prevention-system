// TODO: ClusterCacheRepository (<<container>>): extends Repository; caches DengueClusters.
// TODO: Refresh the cache from DataGovAdapter.fetchDengueClusters() when stale.
