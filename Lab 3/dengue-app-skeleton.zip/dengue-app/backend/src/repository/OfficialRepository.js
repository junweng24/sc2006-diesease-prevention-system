// TODO: OfficialRepository (<<container>>): extends Repository<Official>.
// TODO: Implement save(entity) and toEntity(row) for Official.
// TODO: Add lookup by username for login.
