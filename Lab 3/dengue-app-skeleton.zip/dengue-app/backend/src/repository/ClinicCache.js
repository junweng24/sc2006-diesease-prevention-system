// TODO: ClinicCache (<<container>>): in-memory cache of clinics.
// TODO: getClinics(now): return ClinicList, refreshing from DataGovAdapter.fetchClinics() when stale.
