// TODO: NotificationLogRepository (<<container>>): extends Repository<NotificationLog>.
// TODO: Implement save(entity) and toEntity(row) for NotificationLog.
// TODO: Add queries for retrying PENDING_RETRY deliveries.
