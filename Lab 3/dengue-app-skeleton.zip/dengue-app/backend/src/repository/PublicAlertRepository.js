// TODO: PublicAlertRepository (<<container>>): extends Repository<PublicAlert>.
// TODO: Implement save(entity) and toEntity(row) for PublicAlert.
// TODO: Add query for published alerts.
