// TODO: VolunteerActivityRepository (<<container>>): extends Repository<VolunteerActivity>.
// TODO: Implement save(entity) and toEntity(row) for VolunteerActivity.
// TODO: Add queries for open activities and filtered listings.
