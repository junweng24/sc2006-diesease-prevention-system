// TODO: HotspotRepository (<<container>>): extends Repository<Hotspot>.
// TODO: Implement save(entity) and toEntity(row) for Hotspot.
// TODO: Add queries for active hotspots by filter.
