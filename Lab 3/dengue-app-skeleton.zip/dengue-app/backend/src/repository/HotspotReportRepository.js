// TODO: HotspotReportRepository (<<container>>): extends Repository<HotspotReport>.
// TODO: Implement save(entity) and toEntity(row) for HotspotReport.
// TODO: Add lookup by referenceId and version-checked update.
