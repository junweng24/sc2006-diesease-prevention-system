// TODO: VolunteerActivity (<<entity>>): a volunteer event organised by officials.
// TODO: Fields: id, title, targetArea, eventDateTime, headcountQuota, registeredCount, priority, description, status (ActivityStatus).
// TODO: Associations: createdBy -> Official (1); contactPerson -> ContactDetails (0..1, composition); registrations -> VolunteerRegistration (0..*, aggregation).
// TODO: remainingSlots(): return headcountQuota - registeredCount.
// TODO: isFull(): return true when no slots remain.
// TODO: canAcceptRegistration(now): return true if OPEN, not full and event not yet past.
// TODO: refreshStatus(now): recompute status (OPEN / FULL / COMPLETED) from counts and date.
