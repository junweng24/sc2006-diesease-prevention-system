// TODO: ContactDetails (<<entity>>): optional contact information value object.
// TODO: Fields: name, phone, email.
// TODO: isEmpty(): return true when no contact fields are provided.
