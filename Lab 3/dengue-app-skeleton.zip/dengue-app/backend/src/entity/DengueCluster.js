// TODO: DengueCluster (<<entity>>): an official dengue cluster from data.gov.
// TODO: Fields: clusterId, locality, caseCount. Composition: boundary -> GeoLocation (1..*).
// TODO: riskLevel(): derive RiskLevel (LOW / HIGH) from caseCount.
