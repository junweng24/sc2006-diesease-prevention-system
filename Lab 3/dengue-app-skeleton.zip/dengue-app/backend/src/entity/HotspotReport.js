// TODO: HotspotReport (<<entity>>): a public report of a possible breeding site.
// TODO: Fields: referenceId, siteType (BreedingSiteType), description, photoPath, status (ReportStatus), submittedAt, reviewedAt, version (optimistic locking).
// TODO: Composition: location -> GeoLocation (1); contact -> ContactDetails (0..1).
// TODO: Association: reviewedBy -> Official (0..1).
// TODO: canTransitionTo(next): return whether the ReportStatus transition is allowed.
// TODO: transitionTo(next, officialId, now): validate and apply status change, set reviewer and reviewedAt.
// TODO: generateReferenceId(now): static; produce a unique, human-readable reference id.
