// TODO: PublicAlert (<<entity>>): an alert published to the public and subscribers.
// TODO: Fields: id, title, body, category, severity (Severity), targetRegion, publishedAt.
// TODO: Association: publishedBy -> Official (1).
// TODO: toSmsText(): return a short SMS-safe text version of the alert.
