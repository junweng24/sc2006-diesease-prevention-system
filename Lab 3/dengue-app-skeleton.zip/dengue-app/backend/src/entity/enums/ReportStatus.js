// TODO: ReportStatus (<<enumeration>>): define frozen values {UNVERIFIED, VERIFIED_ACTIVE, RESOLVED, DISMISSED}.
