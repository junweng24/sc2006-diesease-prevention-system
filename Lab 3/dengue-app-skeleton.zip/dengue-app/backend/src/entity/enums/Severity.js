// TODO: Severity (<<enumeration>>): define frozen values {LOW, MEDIUM, HIGH, CRITICAL}.
