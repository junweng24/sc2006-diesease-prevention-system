// TODO: BreedingSiteType (<<enumeration>>): define frozen values {STAGNANT_WATER, CONTAINER, DRAIN, PLANT_POT, CONSTRUCTION_SITE, OTHER}.
