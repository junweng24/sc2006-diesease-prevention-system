// TODO: RiskLevel (<<enumeration>>): define frozen values {LOW, HIGH}.
