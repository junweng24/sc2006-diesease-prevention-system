// TODO: DeliveryStatus (<<enumeration>>): define frozen values {SENT, FAILED, PENDING_RETRY}.
