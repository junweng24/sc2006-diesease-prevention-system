// TODO: HotspotSource (<<enumeration>>): define frozen values {OFFICIAL, VERIFIED_REPORT}.
