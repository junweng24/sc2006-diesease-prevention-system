// TODO: OfficialRole (<<enumeration>>): define frozen values {OFFICIAL}.
