// TODO: ActivityStatus (<<enumeration>>): define frozen values {OPEN, FULL, COMPLETED, CANCELLED}.
