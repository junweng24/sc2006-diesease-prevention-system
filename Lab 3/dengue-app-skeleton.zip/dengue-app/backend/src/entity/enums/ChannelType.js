// TODO: ChannelType (<<enumeration>>): define frozen values {SMS, EMAIL}.
