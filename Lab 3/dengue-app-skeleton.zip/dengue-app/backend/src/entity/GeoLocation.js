// TODO: GeoLocation (<<entity>>): a geographic point with address.
// TODO: Fields: latitude, longitude, address, postalCode.
// TODO: isWithinSingapore(): return whether coordinates fall inside Singapore bounds.
// TODO: distanceKmTo(other): return great-circle distance in km to another GeoLocation.
