// TODO: AlertSubscription (<<entity>>): a member of the public subscribed to alerts.
// TODO: Fields: id, email, phone, channels (ChannelType[]), region, wantsVolunteerNews, consentGiven.
// TODO: matchesRegion(region): return whether this subscription should receive alerts for the region.
