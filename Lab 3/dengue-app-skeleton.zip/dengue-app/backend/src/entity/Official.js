// TODO: Official (<<entity>>): an authenticated government official.
// TODO: Fields: id, username, passwordHash, role (OfficialRole), failedLoginAttempts, lockedUntil.
// TODO: isLocked(now): return whether the account is currently locked.
// TODO: recordFailedLogin(now, maxAttempts, lockoutMinutes): increment attempts and lock the account when maxAttempts is reached.
// TODO: resetFailedLogins(): clear failed attempts after a successful login.
