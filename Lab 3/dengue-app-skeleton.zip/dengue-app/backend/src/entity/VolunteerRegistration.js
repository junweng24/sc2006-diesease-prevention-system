// TODO: VolunteerRegistration (<<entity>>): a volunteer's sign-up for an activity.
// TODO: Fields: id, consentGiven, registeredAt.
// TODO: Composition: contact -> ContactDetails (1). Belongs to one VolunteerActivity.
