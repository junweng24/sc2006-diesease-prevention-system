// TODO: Hotspot (<<entity>>): a disease hotspot shown on the map.
// TODO: Fields: id, diseaseType, caseCount, riskLevel (RiskLevel), source (HotspotSource), isActive, createdAt.
// TODO: Composition: location -> GeoLocation (1).
// TODO: Associations: createdBy -> Official (1); createdFrom -> HotspotReport (0..1).
// TODO: remove(): mark the hotspot as inactive (soft delete).
// TODO: fromVerifiedReport(report, officialId): static factory creating a Hotspot (source VERIFIED_REPORT) from a verified HotspotReport.
