// TODO: NotificationLog (<<entity>>): record of one notification delivery attempt.
// TODO: Fields: id, subjectType, subjectId, channel (ChannelType), recipient, status (DeliveryStatus), errorMessage, attemptCount.
// TODO: Association: about -> PublicAlert (1) (or other subject identified by subjectType/subjectId).
