// TODO: Clinic (<<entity>>): a clinic the public can visit.
// TODO: Fields: code, name, phone. Composition: location -> GeoLocation (1).
// TODO: distanceKmFrom(from): return distance in km from the given GeoLocation.
