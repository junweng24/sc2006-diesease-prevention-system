/**
 * Fills an empty database with demo data so the prototype can be shown straight away:
 * one official account, some alerts, hotspots, volunteer activities and hotspot reports.
 * Usage: npm run seed
 *
 * Safe to run again: the official is only created if missing, and the demo records are only
 * added if there are no alerts yet. To start over, stop the server and delete server/data/.
 */
import { Config } from '../src/config/Config.js';
import { PasswordHasher } from '../src/control/auth/PasswordHasher.js';
import { ContactDetails } from '../src/entity/ContactDetails.js';
import { GeoLocation } from '../src/entity/GeoLocation.js';
import { Hotspot } from '../src/entity/Hotspot.js';
import { HotspotReport } from '../src/entity/HotspotReport.js';
import { PublicAlert } from '../src/entity/PublicAlert.js';
import { VolunteerActivity } from '../src/entity/VolunteerActivity.js';
import { Database } from '../src/repository/Database.js';
import { HotspotReportRepository } from '../src/repository/HotspotReportRepository.js';
import { HotspotRepository } from '../src/repository/HotspotRepository.js';
import { OfficialRepository } from '../src/repository/OfficialRepository.js';
import { PublicAlertRepository } from '../src/repository/PublicAlertRepository.js';
import { VolunteerActivityRepository } from '../src/repository/VolunteerActivityRepository.js';

const DEMO_USERNAME = 'officer';
const DEMO_PASSWORD = 'ChangeMe123!';

const HOUR = 60 * 60 * 1000;
const DAY = 24 * HOUR;

/** 9 a.m. Singapore time, `days` days from now. */
const daysFromNow = (days, hourSgt = 9) => {
  const d = new Date(Date.now() + days * DAY);
  d.setUTCHours(hourSgt - 8, 0, 0, 0);
  return d;
};
const hoursAgo = (h) => new Date(Date.now() - h * HOUR);

const db = Database.getInstance(Config.getInstance().databaseFile);
const officials = new OfficialRepository(db);
const alerts = new PublicAlertRepository(db);

let official = await officials.findByUsername(DEMO_USERNAME);
if (!official) {
  const hash = await new PasswordHasher().hash(DEMO_PASSWORD);
  await db.query('INSERT INTO officials (username, password_hash) VALUES ($1, $2)',
    [DEMO_USERNAME, hash]);
  official = await officials.findByUsername(DEMO_USERNAME);
  console.log(`Created official "${DEMO_USERNAME}" with password "${DEMO_PASSWORD}"`);
} else {
  console.log(`Official "${DEMO_USERNAME}" already exists`);
}

if ((await alerts.findLatest(1)).length > 0) {
  console.log('Demo data already present, nothing else to add.');
  await db.close();
  process.exit(0);
}

const by = official.id;

for (const a of [
  {
    title: 'Dengue cases rising in Tampines',
    body: 'NEA has reported a rise in dengue cases around Tampines Street 81-83. '
      + 'Remove stagnant water at home every week, apply insect repellent, and see a doctor if '
      + 'you have a sudden fever, headache or joint pain.',
    category: 'Dengue', severity: 'HIGH', targetRegion: 'East', publishedAt: hoursAgo(5),
  },
  {
    title: 'Weekly reminder: Do the Mozzie Wipeout',
    body: 'Turn over pails, change water in vases, clear blocked roof gutters and loosen soil '
      + 'in potted plants. Five minutes a week stops Aedes mosquitoes breeding.',
    category: 'Prevention', severity: 'LOW', targetRegion: 'ALL', publishedAt: hoursAgo(30),
  },
  {
    title: 'Zika case detected in Jurong West',
    body: 'One locally transmitted Zika case has been confirmed near Jurong West Street 91. '
      + 'Pregnant women in the area should take extra care and see a doctor if unwell.',
    category: 'Zika', severity: 'MEDIUM', targetRegion: 'West', publishedAt: hoursAgo(54),
  },
]) {
  await alerts.save(new PublicAlert({ ...a, publishedBy: by }));
}

const hotspots = new HotspotRepository(db);
for (const h of [
  { diseaseType: 'DENGUE', lat: 1.3540, lng: 103.9370, address: 'Tampines Street 81', caseCount: 14 },
  { diseaseType: 'DENGUE', lat: 1.3236, lng: 103.9273, address: 'Bedok North Avenue 3', caseCount: 6 },
  { diseaseType: 'ZIKA', lat: 1.3404, lng: 103.6936, address: 'Jurong West Street 91', caseCount: 1 },
  { diseaseType: 'DENGUE', lat: 1.4360, lng: 103.7865, address: 'Woodlands Drive 14', caseCount: 11 },
  { diseaseType: 'CHIKUNGUNYA', lat: 1.3691, lng: 103.8454, address: 'Ang Mo Kio Avenue 3', caseCount: 3 },
]) {
  await hotspots.save(new Hotspot({
    diseaseType: h.diseaseType,
    location: new GeoLocation({ latitude: h.lat, longitude: h.lng, address: h.address }),
    caseCount: h.caseCount,
    riskLevel: h.caseCount >= 10 ? 'HIGH' : 'LOW',
    source: 'OFFICIAL',
    createdBy: by,
  }));
}

const activities = new VolunteerActivityRepository(db);
for (const a of [
  {
    title: 'Tampines block inspection', targetArea: 'Tampines Street 81', days: 3, quota: 20,
    priority: 'HIGH', description: 'Check common corridors and void decks for stagnant water. '
      + 'Gloves and torches provided. Meet at the Blk 823 void deck.',
  },
  {
    title: 'Woodlands park clean-up', targetArea: 'Woodlands Waterfront Park', days: 7, quota: 12,
    priority: 'NORMAL', description: 'Clear litter and containers that collect rainwater.',
  },
  {
    title: 'Community talk helpers', targetArea: 'Bedok Community Centre', days: 10, quota: 2,
    priority: 'LOW', description: 'Help set up a dengue awareness booth. Only 2 helpers needed.',
  },
]) {
  await activities.save(new VolunteerActivity({
    title: a.title,
    targetArea: a.targetArea,
    eventDateTime: daysFromNow(a.days),
    headcountQuota: a.quota,
    priority: a.priority,
    description: a.description,
    contactPerson: new ContactDetails({ name: 'Officer Tan', phone: '61234567' }),
    createdBy: by,
  }));
}

const reports = new HotspotReportRepository(db);
for (const r of [
  {
    lat: 1.3483, lng: 103.6831, address: '50 Nanyang Avenue, Singapore 639798',
    siteType: 'CONSTRUCTION_SITE', hours: 3,
    description: 'Large puddles at the construction site next to the bus stop, lots of mosquitoes in the evening.',
    contact: { name: 'Alex Lim', phone: '91234567', email: 'alex@example.com' },
  },
  {
    lat: 1.3005, lng: 103.8556, address: 'Bugis Street, Singapore 188869',
    siteType: 'DRAIN', hours: 20, description: 'Blocked drain with stagnant water behind the shophouses.',
  },
]) {
  const submittedAt = hoursAgo(r.hours);
  await reports.save(new HotspotReport({
    referenceId: HotspotReport.generateReferenceId(submittedAt),
    location: new GeoLocation({ latitude: r.lat, longitude: r.lng, address: r.address }),
    siteType: r.siteType,
    description: r.description,
    contact: r.contact ? new ContactDetails(r.contact) : null,
    submittedAt,
  }));
}

console.log('Added demo alerts, hotspots, volunteer activities and hotspot reports.');
await db.close();
