/**
 * Creates an official account with a bcrypt-hashed password.
 * Usage: npm run create-official -- <username> <password>
 */
import { Config } from '../src/config/Config.js';
import { PasswordHasher } from '../src/control/auth/PasswordHasher.js';
import { Database } from '../src/repository/Database.js';

const [username, password] = process.argv.slice(2);
const role = 'OFFICIAL';
if (!username || !password) {
  console.error('Usage: npm run create-official -- <username> <password>');
  process.exit(1);
}

const db = Database.getInstance(Config.getInstance().databaseFile);
const hash = await new PasswordHasher().hash(password);
await db.query(
  'INSERT INTO officials (username, password_hash, role) VALUES ($1, $2, $3)',
  [username, hash, role]);
console.log(`Created ${role} "${username}"`);
await db.close();
