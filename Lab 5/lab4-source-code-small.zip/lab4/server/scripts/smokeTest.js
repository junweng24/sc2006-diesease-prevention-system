/**
 * Demo-day pre-flight check (Lab 4 §3.2.4, §3.4). Starts the real server on a throwaway database
 * and walks the demo's use cases over HTTP, so a problem shows up before the client sees it.
 * The demo database and uploaded photos are not touched.
 *
 * Usage (from server/): npm run smoke
 * Calls data.gov.sg and OneMap for real, and a failure of those is reported as a WARNING because
 * the system has a fallback for it (NFR-04). Exit code 1 means a required check failed.
 */
import { spawn, spawnSync } from 'node:child_process';
import { mkdirSync, rmSync, writeFileSync } from 'node:fs';
import { DatabaseSync } from 'node:sqlite';

const PORT = 3100;
const BASE = `http://localhost:${PORT}/api`;
const WORK_DIR = 'data/smoke';
const env = {
  ...process.env,
  PORT: String(PORT),
  DATABASE_FILE: `${WORK_DIR}/smoke.db`,
  UPLOAD_DIR: `${WORK_DIR}/uploads`,
};
const NODE_FLAGS = ['--disable-warning=ExperimentalWarning'];

/** A minimal JPEG header, enough for the photo upload path. */
const TINY_JPEG = Buffer.from('ffd8ffe000104a46494600010100000100010000ffd9', 'hex');

let cookie = '';
const results = [];

function record(level, uc, name, ok, detail = '') {
  results.push({ level, uc, name, ok, detail });
  const mark = ok ? 'PASS' : level === 'optional' ? 'WARN' : 'FAIL';
  console.log(`${mark}  ${uc.padEnd(10)} ${name}${detail ? `  (${detail})` : ''}`);
}
const check = (uc, name, ok, detail) => record('required', uc, name, Boolean(ok), detail);
const optional = (uc, name, ok, detail) => record('optional', uc, name, Boolean(ok), detail);

async function api(method, path, body, { form = false } = {}) {
  const headers = cookie ? { cookie } : {};
  let payload;
  if (form) payload = body;
  else if (body !== undefined) {
    headers['content-type'] = 'application/json';
    payload = JSON.stringify(body);
  }
  const res = await fetch(BASE + path, { method, headers, body: payload });
  const setCookie = res.headers.get('set-cookie');
  if (setCookie) cookie = setCookie.split(';')[0];
  const text = await res.text();
  let json = null;
  try { json = text ? JSON.parse(text) : null; } catch { /* not JSON */ }
  return { status: res.status, json };
}

async function waitForServer() {
  for (let i = 0; i < 40; i += 1) {
    try {
      if ((await fetch(`${BASE}/alerts`)).ok) return;
    } catch { /* still starting */ }
    await new Promise((r) => { setTimeout(r, 250); });
  }
  throw new Error('Server did not start');
}

async function runChecks() {
  // --- Public user ---
  let r = await api('GET', '/alerts');
  check('UC16', 'seeded alerts on home feed', r.status === 200 && r.json.length === 3, `${r.json?.length} alerts`);
  r = await api('GET', `/alerts/${r.json[0].id}`);
  check('UC16', 'alert details', r.status === 200 && r.json.title);

  r = await api('GET', '/map');
  check('UC1', 'map returns hotspots', r.status === 200 && r.json.hotspots.length > 0, `${r.json.hotspots.length} hotspots`);
  optional('UC1', 'live NEA dengue clusters', r.json.clusters.length > 0 && !r.json.isStale, `${r.json.clusters.length} clusters, stale=${r.json.isStale}`);
  r = await api('GET', '/map?diseaseType=ZIKA');
  check('UC1', 'disease filter hides dengue clusters', r.status === 200 && r.json.clusters.length === 0);

  r = await api('GET', '/map/search?q=Tampines');
  optional('UC2', 'OneMap address search', r.status === 200 && r.json.length > 0, `status ${r.status}`);
  r = await api('GET', '/clinics?lat=1.3329&lng=103.7436');
  optional('UC19', 'nearest CHAS clinics (live)', r.status === 200 && (r.json.clinics ?? r.json).length > 0, `status ${r.status}`);

  r = await api('POST', '/subscriptions', { channels: ['SMS', 'EMAIL'], phone: '91234567', email: 'smoke@example.com', region: 'East', wantsVolunteerNews: true, consentGiven: true });
  check('UC15', 'subscribe by SMS and email', r.status === 201, `status ${r.status}`);
  r = await api('POST', '/subscriptions', { channels: ['SMS'], phone: '91234567', region: 'East', consentGiven: true });
  check('UC15 2b', 'second subscription refused', r.status === 409);
  r = await api('POST', '/subscriptions', { channels: ['SMS'], phone: '61234567', region: 'East', consentGiven: true });
  check('UC15 2a', 'landline for SMS refused', r.status === 422 && r.json.details.phone);

  const reportForm = (extra = {}, photo = TINY_JPEG, type = 'image/jpeg') => {
    const form = new FormData();
    form.set('report', JSON.stringify({ location: { latitude: 1.35, longitude: 103.94 }, siteType: 'DRAIN', description: 'Smoke test report', ...extra }));
    if (photo) form.set('photo', new Blob([photo], { type }), 'photo.jpg');
    return form;
  };
  r = await api('POST', '/reports', reportForm(), { form: true });
  check('UC3-UC5', 'report with photo gets a reference ID', r.status === 201 && /^HR-/.test(r.json.referenceId), r.json?.referenceId);
  const referenceId = r.json.referenceId;
  r = await api('POST', '/reports', reportForm({ description: 'x' }, TINY_JPEG, 'image/png'), { form: true });
  check('UC4 2b', 'PNG photo refused', r.status === 422 && r.json.details.photo);
  r = await api('POST', '/reports', reportForm({ description: 12345 }, null), { form: true });
  check('UC3 3a', 'non-text description gives a field error, not a 500', r.status === 422 && r.json.details.description, `status ${r.status}`);

  const list = (await api('GET', '/volunteer-activities')).json;
  const tiny = list.find((a) => a.headcountQuota === 2);
  check('UC6', 'open activities listed', list.length === 3 && tiny, `${list.length} activities`);
  const volunteer = (n) => ({ name: `Volunteer ${n}`, phone: `9000000${n}`, email: `v${n}@example.com`, consentGiven: true });
  r = await api('POST', `/volunteer-activities/${tiny.id}/registrations`, volunteer(1));
  check('UC6', 'register first volunteer', r.status === 201 && r.json.activity.remainingSlots === 1);
  r = await api('POST', `/volunteer-activities/${tiny.id}/registrations`, volunteer(1));
  check('UC6 4a', 'duplicate registration refused', r.status === 409);
  r = await api('POST', `/volunteer-activities/${tiny.id}/registrations`, volunteer(2));
  check('UC6', 'second volunteer fills the quota', r.status === 201 && r.json.activity.remainingSlots === 0);
  r = await api('POST', `/volunteer-activities/${tiny.id}/registrations`, volunteer(3));
  check('UC6 2a', 'quota full refused', r.status === 409 && /full/i.test(r.json.error), r.json?.error);

  // --- Access control ---
  r = await api('GET', '/admin/dashboard');
  check('NFR-01', 'portal refused without login', r.status === 401);
  r = await api('GET', `/admin/reports/${referenceId}/photo`);
  check('NFR-02', 'report photo refused without login', r.status === 401);
  r = await api('POST', '/auth/login', { username: 'officer', password: 'wrong' });
  check('UC14 2a', 'wrong password refused', r.status === 401, r.json?.error);
  r = await api('POST', '/auth/login', { username: 'officer', password: 'ChangeMe123!' });
  check('UC14', 'log in', r.status === 200 && r.json.official.username === 'officer');

  // --- Official ---
  r = await api('GET', '/admin/dashboard');
  check('FR-18', 'dashboard counts', r.status === 200 && r.json.pendingReports >= 3, `${r.json.pendingReports} pending`);

  r = await api('GET', `/admin/reports/${referenceId}`);
  const version = r.json.version;
  check('UC8', 'open the new report', r.status === 200 && r.json.status === 'UNVERIFIED');
  r = await api('GET', `/admin/reports/${referenceId}/photo`);
  check('UC8', 'official can see the photo', r.status === 200);
  r = await api('PATCH', `/admin/reports/${referenceId}`, { status: 'RESOLVED', version });
  check('UC8', 'illegal status change refused', r.status === 422);
  r = await api('PATCH', `/admin/reports/${referenceId}`, { status: 'VERIFIED_ACTIVE', version });
  check('UC8', 'verify report', r.status === 200 && r.json.status === 'VERIFIED_ACTIVE', `status ${r.status}`);
  r = await api('PATCH', `/admin/reports/${referenceId}`, { status: 'RESOLVED', version });
  check('UC8 4a', 'stale version refused', r.status === 409);
  const onMap = async () => (await api('GET', '/map')).json.hotspots.filter((h) => h.sourceReportId === referenceId).length;
  check('UC8', 'verified report is on the public map', (await onMap()) === 1);
  const latest = (await api('GET', `/admin/reports/${referenceId}`)).json.version;
  r = await api('PATCH', `/admin/reports/${referenceId}`, { status: 'RESOLVED', version: latest });
  check('UC8', 'resolve report', r.status === 200);
  check('UC8', 'resolved report leaves the public map', (await onMap()) === 0);

  r = await api('POST', '/admin/hotspots', { diseaseType: 'DENGUE', caseCount: 12, location: { latitude: 1.4, longitude: 103.8 } });
  check('UC17', 'add hotspot; 10+ cases is high risk', r.status === 201 && r.json.riskLevel === 'HIGH', r.json?.riskLevel);
  const added = r.json.id;
  r = await api('DELETE', `/admin/hotspots/${added}`);
  check('UC17', 'remove hotspot', r.status === 204);

  const alert = { title: 'Smoke test alert', body: 'Clear stagnant water.', category: 'Dengue', severity: 'HIGH', targetRegion: 'East' };
  r = await api('POST', '/admin/alerts/preview', alert);
  check('UC7', 'preview alert', r.status === 200);
  r = await api('POST', '/admin/alerts', alert);
  check('UC7', 'publish and dispatch to the 2 channels', r.status === 201 && r.json.dispatch.sent === 2, JSON.stringify(r.json?.dispatch));
  r = await api('POST', '/admin/alerts', { ...alert, title: 12345 });
  check('UC7', 'non-text title gives a field error, not a 500', r.status === 422 && r.json.details.title, `status ${r.status}`);

  const inDays = (d) => new Date(Date.now() + d * 86_400_000).toISOString();
  r = await api('POST', '/admin/activities', { title: 'Smoke activity', targetArea: 'Bedok', eventDateTime: inDays(5), headcountQuota: 5, contactName: 'Officer Tan', contactPhone: '61234567' });
  check('UC9', 'create activity', r.status === 201, `status ${r.status}`);
  r = await api('POST', '/admin/activities', { title: 'Past', targetArea: 'Bedok', eventDateTime: inDays(-1), headcountQuota: 5 });
  check('UC9 3a', 'past date refused', r.status === 422 && r.json.details.eventDateTime);
  r = await api('GET', `/admin/activities/${tiny.id}/status`);
  check('UC10', 'occupancy is 100%', r.status === 200 && r.json.occupancyPercent === 100, `${r.json?.occupancyPercent}%`);
  r = await api('GET', `/admin/activities/${tiny.id}/roster`);
  check('UC10', 'roster has both volunteers', r.status === 200 && r.json.length === 2);
  r = await api('PUT', `/admin/activities/${tiny.id}`, { headcountQuota: 1 });
  check('UC11 2a', 'quota below registered count refused', r.status === 422);
  r = await api('PUT', `/admin/activities/${tiny.id}`, { targetArea: 'Tampines Hub' });
  check('UC11', 'edit venue', r.status === 200 && r.json.targetArea === 'Tampines Hub');

  // --- UC15 unsubscribe: the token only ever reaches the subscriber's message, so read it here ---
  r = await api('GET', '/subscriptions/unsubscribe/not-a-real-token');
  check('UC15', 'invalid unsubscribe link refused', r.status === 404);
  const db = new DatabaseSync(env.DATABASE_FILE);
  const { unsubscribe_token: token } = db.prepare('SELECT unsubscribe_token FROM alert_subscriptions LIMIT 1').get();
  db.close();
  r = await api('GET', `/subscriptions/unsubscribe/${token}`);
  check('UC15', 'opening the link changes nothing', r.status === 200 && r.json.alreadyUnsubscribed === false);
  r = await api('POST', `/subscriptions/unsubscribe/${token}`);
  check('UC15', 'unsubscribe withdraws consent', r.status === 200);
  r = await api('POST', `/subscriptions/unsubscribe/${token}`);
  check('UC15', 'used link refused', r.status === 409);
  r = await api('POST', '/admin/alerts', { ...alert, title: 'After unsubscribing' });
  check('UC15', 'no message after unsubscribing', r.status === 201 && r.json.dispatch.sent === 0, JSON.stringify(r.json?.dispatch));

  r = await api('POST', '/auth/logout');
  check('UC18', 'log out', r.status === 204);
  cookie = '';
  r = await api('GET', '/admin/dashboard');
  check('UC18', 'portal refused after logout', r.status === 401);

  // Five failures in a row lock the account: done last because it leaves the account locked.
  let lockStatus = 0;
  for (let i = 0; i < 5; i += 1) {
    lockStatus = (await api('POST', '/auth/login', { username: 'officer', password: 'wrong' })).status;
  }
  check('UC14 2b', 'locked after 5 failures', lockStatus === 423, `status ${lockStatus}`);
  r = await api('POST', '/auth/login', { username: 'officer', password: 'ChangeMe123!' });
  check('UC14 2b', 'correct password refused while locked', r.status === 423);
}

function main() {
  rmSync(WORK_DIR, { recursive: true, force: true });
  mkdirSync(WORK_DIR, { recursive: true });
  const seed = spawnSync(process.execPath, [...NODE_FLAGS, 'scripts/seedDemo.js'], { env, encoding: 'utf8' });
  if (seed.status !== 0) throw new Error(`Seeding failed: ${seed.stderr}`);

  const server = spawn(process.execPath, [...NODE_FLAGS, 'src/index.js'], { env, stdio: 'ignore' });
  const finish = (code) => {
    server.kill();
    setTimeout(() => {
      rmSync(WORK_DIR, { recursive: true, force: true });
      process.exit(code);
    }, 500);
  };

  waitForServer().then(runChecks).then(() => {
    const failed = results.filter((x) => !x.ok && x.level === 'required');
    const warned = results.filter((x) => !x.ok && x.level === 'optional');
    const passed = results.filter((x) => x.ok).length;
    console.log(`\n${passed}/${results.length} passed, ${failed.length} failed, ${warned.length} warnings`);
    writeFileSync('test-results/smoke.json', JSON.stringify(results, null, 2));
    finish(failed.length ? 1 : 0);
  }).catch((err) => {
    console.error('Smoke test aborted:', err);
    finish(1);
  });
}

main();
