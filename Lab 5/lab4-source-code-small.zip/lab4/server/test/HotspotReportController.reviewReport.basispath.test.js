import { afterAll, beforeEach, describe, expect, test, vi } from 'vitest';

import { HotspotReportController } from '../src/control/HotspotReportController.js';
import { GeoLocation } from '../src/entity/GeoLocation.js';
import { Hotspot } from '../src/entity/Hotspot.js';
import { HotspotReport } from '../src/entity/HotspotReport.js';
import { HotspotSource, ReportStatus } from '../src/entity/enums.js';
import { ResultRecorder } from './helpers/recorder.js';

/**
 * Lab 4 §3.2.2 Basis path tests for HotspotReportController.reviewReport (UC8, FR-29).
 * Predicates: report found (inside getReport), version matches, transition allowed, row saved,
 * status = VERIFIED_ACTIVE, status = RESOLVED, more linked hotspots (for loop).
 * V(G) = 7 + 1 = 8, so 8 independent paths; one test per path.
 */
const recorder = new ResultRecorder('basispath-reviewReport');
afterAll(() => recorder.save());

const NOW = new Date('2026-11-02T12:00:00.000Z');
const REF = 'HR-20261102-AAAA';
const OFFICIAL = 7;

let report;
let reportRepo;
let hotspotRepo;
let controller;

const makeReport = (status = ReportStatus.UNVERIFIED, version = 1) => new HotspotReport({
  referenceId: REF,
  location: new GeoLocation({ latitude: 1.35, longitude: 103.8 }),
  siteType: 'DRAIN',
  description: 'Stagnant water',
  status,
  version,
});
const linkedHotspot = () => new Hotspot({
  id: 1, diseaseType: 'DENGUE', location: report.location, source: HotspotSource.VERIFIED_REPORT,
  sourceReportId: REF, createdBy: OFFICIAL,
});

beforeEach(() => {
  report = makeReport();
  reportRepo = {
    findById: vi.fn(async (id) => (id === REF ? report : null)),
    updateStatusWithVersion: vi.fn(async () => true),
  };
  hotspotRepo = {
    save: vi.fn(async (h) => h),
    findActiveBySourceReport: vi.fn(async () => []),
  };
  controller = new HotspotReportController({
    db: { transaction: (work) => work('client') }, reportRepo, hotspotRepo, uploadDir: 'unused',
  });
});

async function run(referenceId, status, version) {
  try {
    const r = await controller.reviewReport(referenceId, status, OFFICIAL, version, NOW);
    return `saved, status ${r.status}, hotspots saved: ${hotspotRepo.save.mock.calls.length}`;
  } catch (err) {
    return `${err.name}: ${err.message}`;
  }
}
const STALE = 'ConflictError: This report was updated by someone else. Reloaded latest version.';

describe('HotspotReportController.reviewReport basis paths', () => {
  test('P1 unknown reference ID', async () => {
    const expected = 'NotFoundError: Report not found';
    const actual = await run('HR-NONE', ReportStatus.VERIFIED_ACTIVE, 1);
    recorder.add({ id: 'P1', input: 'reference ID that does not exist', expected, actual });
    expect(actual).toBe(expected);
    expect(reportRepo.updateStatusWithVersion).not.toHaveBeenCalled();
  });

  test('P2 stale version loaded by the official (UC8 4a)', async () => {
    report = makeReport(ReportStatus.UNVERIFIED, 2);
    const actual = await run(REF, ReportStatus.VERIFIED_ACTIVE, 1);
    recorder.add({ id: 'P2', input: 'official loaded version 1, database has version 2', expected: STALE, actual });
    expect(actual).toBe(STALE);
    expect(reportRepo.updateStatusWithVersion).not.toHaveBeenCalled();
  });

  test('P3 status change that is not allowed', async () => {
    const expected = 'ValidationError: Please correct the highlighted fields';
    const actual = await run(REF, ReportStatus.RESOLVED, 1);
    recorder.add({ id: 'P3', input: 'UNVERIFIED report set straight to RESOLVED', expected, actual });
    expect(actual).toBe(expected);
    expect(report.status).toBe(ReportStatus.UNVERIFIED);
  });

  test('P4 another official saves first, between the read and the write', async () => {
    reportRepo.updateStatusWithVersion.mockResolvedValue(false);
    const actual = await run(REF, ReportStatus.VERIFIED_ACTIVE, 1);
    recorder.add({ id: 'P4', input: 'versions match on read, but the versioned update changes no row', expected: STALE, actual });
    expect(actual).toBe(STALE);
    expect(hotspotRepo.save).not.toHaveBeenCalled();
  });

  test('P5 verify: the report becomes a hotspot on the public map', async () => {
    const expected = 'saved, status VERIFIED_ACTIVE, hotspots saved: 1';
    const actual = await run(REF, ReportStatus.VERIFIED_ACTIVE, 1);
    recorder.add({ id: 'P5', input: 'UNVERIFIED report set to VERIFIED_ACTIVE', expected, actual });
    expect(actual).toBe(expected);
    expect(hotspotRepo.save.mock.calls[0][0]).toMatchObject({ sourceReportId: REF, isActive: true });
    expect(report.reviewedBy).toBe(OFFICIAL);
  });

  test('P6 dismiss: the map is not touched (UC8 3a)', async () => {
    const expected = 'saved, status DISMISSED, hotspots saved: 0';
    const actual = await run(REF, ReportStatus.DISMISSED, 1);
    recorder.add({ id: 'P6', input: 'UNVERIFIED report set to DISMISSED', expected, actual });
    expect(actual).toBe(expected);
    expect(hotspotRepo.findActiveBySourceReport).not.toHaveBeenCalled();
  });

  test('P7 resolve with no linked hotspot: loop body skipped', async () => {
    report = makeReport(ReportStatus.VERIFIED_ACTIVE);
    const expected = 'saved, status RESOLVED, hotspots saved: 0';
    const actual = await run(REF, ReportStatus.RESOLVED, 1);
    recorder.add({ id: 'P7', input: 'VERIFIED_ACTIVE report set to RESOLVED, no linked hotspot', expected, actual });
    expect(actual).toBe(expected);
  });

  test('P8 resolve with a linked hotspot: it leaves the public map (FR-21)', async () => {
    report = makeReport(ReportStatus.VERIFIED_ACTIVE);
    const hotspot = linkedHotspot();
    hotspotRepo.findActiveBySourceReport.mockResolvedValue([hotspot]);
    const expected = 'saved, status RESOLVED, hotspots saved: 1';
    const actual = await run(REF, ReportStatus.RESOLVED, 1);
    recorder.add({ id: 'P8', input: 'VERIFIED_ACTIVE report set to RESOLVED, one linked hotspot', expected, actual });
    expect(actual).toBe(expected);
    expect(hotspot.isActive).toBe(false);
  });
});
