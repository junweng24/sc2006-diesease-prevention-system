import { afterAll, beforeEach, describe, expect, test, vi } from 'vitest';

import { AuthController } from '../src/control/AuthController.js';
import { AccountLockedError, AuthError } from '../src/control/errors.js';
import { Official } from '../src/entity/Official.js';
import { ResultRecorder } from './helpers/recorder.js';

/**
 * Lab 4 §3.2.2 Basis path tests for AuthController.login (UC14, NFR-01).
 * Predicates: !username, !password, !official, isLocked, !ok, isLocked (after failure).
 * V(G) = 6 + 1 = 7, so 7 independent paths; one test per path. Collaborators are fakes,
 * which is possible because they are injected through the constructor.
 */
const recorder = new ResultRecorder('basispath-login');
afterAll(() => recorder.save());

const NOW = new Date('2026-11-02T12:00:00.000Z');
const MAX = 5;
const LOCK_MINUTES = 15;

let official;
let repo;
let hasher;
let tokens;
let auth;

beforeEach(() => {
  official = new Official({ id: 7, username: 'officer', passwordHash: 'HASH' });
  repo = {
    findByUsername: vi.fn(async (u) => (u === 'officer' ? official : null)),
    updateLoginState: vi.fn(async () => {}),
  };
  hasher = { verify: vi.fn(async (plain) => plain === 'right') };
  tokens = { issue: vi.fn(() => 'TOKEN') };
  auth = new AuthController({
    officialRepo: repo, hasher, tokens, maxFailedLogins: MAX, lockoutMinutes: LOCK_MINUTES,
  });
});

/** Runs login and describes the outcome in words. */
async function run(username, password) {
  try {
    const r = await auth.login(username, password, NOW);
    return `success, token ${r.token}, official ${r.official.username}`;
  } catch (err) {
    return `${err.name}: ${err.message}`;
  }
}
const LOCKED = `AccountLockedError: ${new AccountLockedError(LOCK_MINUTES).message}`;
const INVALID = `AuthError: ${new AuthError().message}`;

describe('AuthController.login basis paths', () => {
  test('P1 username empty: rejected before any database call', async () => {
    const actual = await run('', 'right');
    recorder.add({ id: 'P1', input: 'username "", password "right"', expected: INVALID, actual });
    expect(actual).toBe(INVALID);
    expect(repo.findByUsername).not.toHaveBeenCalled();
  });

  test('P2 password empty: rejected before any database call', async () => {
    const actual = await run('officer', '');
    recorder.add({ id: 'P2', input: 'username "officer", password ""', expected: INVALID, actual });
    expect(actual).toBe(INVALID);
    expect(repo.findByUsername).not.toHaveBeenCalled();
  });

  test('P3 unknown username: same message as a wrong password', async () => {
    const actual = await run('ghost', 'right');
    recorder.add({ id: 'P3', input: 'username "ghost" (does not exist)', expected: INVALID, actual });
    expect(actual).toBe(INVALID);
    expect(hasher.verify).not.toHaveBeenCalled();
  });

  test('P4 account already locked: password is not even checked', async () => {
    official.lockedUntil = new Date(NOW.getTime() + 60_000);
    const actual = await run('officer', 'right');
    recorder.add({ id: 'P4', input: 'correct password, account locked for 1 more minute', expected: LOCKED, actual });
    expect(actual).toBe(LOCKED);
    expect(hasher.verify).not.toHaveBeenCalled();
  });

  test('P5 wrong password, below the limit: failure counted, not locked', async () => {
    const actual = await run('officer', 'wrong');
    recorder.add({ id: 'P5', input: 'wrong password, 0 earlier failures', expected: INVALID, actual });
    expect(actual).toBe(INVALID);
    expect(official.failedLoginAttempts).toBe(1);
    expect(official.lockedUntil).toBeNull();
    expect(repo.updateLoginState).toHaveBeenCalledOnce();
  });

  test('P6 wrong password reaching the limit: locked for 15 minutes', async () => {
    official.failedLoginAttempts = MAX - 1;
    const actual = await run('officer', 'wrong');
    recorder.add({ id: 'P6', input: 'wrong password, 4 earlier failures (5th failure)', expected: LOCKED, actual });
    expect(actual).toBe(LOCKED);
    expect(official.lockedUntil).toEqual(new Date(NOW.getTime() + LOCK_MINUTES * 60_000));
    expect(repo.updateLoginState).toHaveBeenCalledOnce();
  });

  test('P7 correct password: token issued and failure counter reset', async () => {
    official.failedLoginAttempts = 3;
    const expected = 'success, token TOKEN, official officer';
    const actual = await run('officer', 'right');
    recorder.add({ id: 'P7', input: 'correct password, 3 earlier failures', expected, actual });
    expect(actual).toBe(expected);
    expect(official.failedLoginAttempts).toBe(0);
    expect(tokens.issue).toHaveBeenCalledWith({ officialId: 7, role: 'OFFICIAL' });
  });
});
