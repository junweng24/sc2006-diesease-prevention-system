import { afterAll, describe, expect, test } from 'vitest';

import { InputValidator } from '../src/control/InputValidator.js';
import { ResultRecorder } from './helpers/recorder.js';

/**
 * Lab 4 §3.2.1 Black-box tests for the «control» class InputValidator.
 *
 * Derived from the requirements and use cases only (FR-11, FR-12, FR-15, FR-22, FR-32, NFR-03,
 * NFR-04; UC3-UC7, UC9, UC11, UC15, UC17), not from the code.
 *   EC  = one representative of an equivalence class
 *   BVA = a value on or next to a boundary
 * To keep the suite small (§3.2.3), each test changes ONE field of an otherwise valid input, so
 * a failure points at one rule, and one value stands for its whole class.
 */
const recorder = new ResultRecorder('blackbox-InputValidator');
afterAll(() => recorder.save());

const NOW = new Date('2026-11-02T12:00:00.000Z');
const MB5 = 5 * 1024 * 1024;
const LOC = { latitude: 1.35, longitude: 103.8 };
const str = (n) => 'x'.repeat(n);

const report = (o = {}) => ({ location: LOC, siteType: 'DRAIN', description: 'Stagnant water', ...o });
const reg = (o = {}) => ({ name: 'Tan Ah Kow', phone: '91234567', email: 'tan@example.com', consentGiven: true, ...o });
const activity = (o = {}) => ({
  title: 'Mozzie patrol', targetArea: 'Tampines', eventDateTime: '2026-12-01T10:00:00.000Z', headcountQuota: 10, ...o,
});
const alert = (o = {}) => ({ title: 'Dengue alert', body: 'Clear stagnant water', category: 'DENGUE', severity: 'HIGH', targetRegion: 'East', ...o });
const sub = (o = {}) => ({ channels: ['SMS'], phone: '91234567', region: 'East', consentGiven: true, ...o });
const hotspot = (o = {}) => ({ diseaseType: 'DENGUE', location: LOC, caseCount: 3, ...o });

/** Turns a ValidationResult into "valid" or "invalid: <field>[, <field>]". */
const outcome = (r) => (r.isValid ? 'valid' : `invalid: ${Object.keys(r.errors).join(', ')}`);
const bool = (b) => (b ? 'valid' : 'invalid');

function group(name, cases, run) {
  describe(name, () => {
    test.each(cases)('$id $technique $input -> $expected', ({ id, technique, input, expected, value }) => {
      const actual = run(value);
      recorder.add({ id, technique, input: `${name}: ${input}`, expected, actual });
      expect(actual).toBe(expected);
    });
  });
}
const c = (id, technique, input, value, expected) => ({ id, technique, input, value, expected });

group('Singapore phone (any)', [
  c('BB-01', 'EC', 'mobile starting 9: "91234567"', '91234567', 'valid'),
  c('BB-02', 'EC', 'landline starting 6: "61234567"', '61234567', 'valid'),
  c('BB-03', 'EC', 'with +65 prefix and space: "+65 81234567"', '+65 81234567', 'valid'),
  c('BB-04', 'EC', 'first digit not 6/8/9: "71234567"', '71234567', 'invalid'),
  c('BB-05', 'BVA', '7 digits (one below length): "9123456"', '9123456', 'invalid'),
  c('BB-06', 'BVA', '9 digits (one above length): "912345678"', '912345678', 'invalid'),
  c('BB-07', 'EC', 'contains letters: "9123abcd"', '9123abcd', 'invalid'),
  c('BB-08', 'EC', 'not a string: 91234567 (number)', 91234567, 'invalid'),
], (v) => bool(InputValidator.isValidSingaporePhone(v)));

group('Singapore phone (SMS, mobile only)', [
  c('BB-09', 'EC', 'mobile: "81234567"', '81234567', 'valid'),
  c('BB-10', 'EC', 'landline cannot receive SMS: "61234567"', '61234567', 'invalid'),
], (v) => bool(InputValidator.isValidSingaporePhone(v, { mobileOnly: true })));

group('Email', [
  c('BB-11', 'EC', 'normal address', 'tan@example.com', 'valid'),
  c('BB-12', 'EC', 'no @ sign', 'tan.example.com', 'invalid'),
  c('BB-13', 'BVA', 'top-level domain of 2 letters (minimum)', 'a@b.co', 'valid'),
  c('BB-14', 'BVA', 'top-level domain of 1 letter (below minimum)', 'a@b.c', 'invalid'),
  c('BB-15', 'BVA', '254 characters (maximum)', `${str(242)}@example.com`, 'valid'),
  c('BB-16', 'BVA', '255 characters (above maximum)', `${str(243)}@example.com`, 'invalid'),
], (v) => bool(InputValidator.isValidEmail(v)));

group('Photo (UC4: JPEG under 5 MB)', [
  c('BB-17', 'EC', 'no photo (optional)', null, 'valid'),
  c('BB-18', 'EC', 'PNG of a valid size', { mimeType: 'image/png', sizeBytes: 1000 }, 'invalid: photo'),
  c('BB-19', 'BVA', 'JPEG, 0 bytes', { mimeType: 'image/jpeg', sizeBytes: 0 }, 'invalid: photo'),
  c('BB-20', 'BVA', 'JPEG, 1 byte', { mimeType: 'image/jpeg', sizeBytes: 1 }, 'valid'),
  c('BB-21', 'BVA', 'JPEG, 5 MB minus 1 byte', { mimeType: 'image/jpeg', sizeBytes: MB5 - 1 }, 'valid'),
  c('BB-22', 'BVA', 'JPEG, exactly 5 MB', { mimeType: 'image/jpeg', sizeBytes: MB5 }, 'invalid: photo'),
], (v) => outcome(InputValidator.validatePhoto(v)));

group('Location (must be in Singapore)', [
  c('BB-23', 'EC', 'missing', undefined, 'invalid: location'),
  c('BB-24', 'BVA', 'latitude 1.15 (south limit)', { latitude: 1.15, longitude: 103.8 }, 'valid'),
  c('BB-25', 'BVA', 'latitude 1.149 (below)', { latitude: 1.149, longitude: 103.8 }, 'invalid: location'),
  c('BB-26', 'BVA', 'latitude 1.48 (north limit)', { latitude: 1.48, longitude: 103.8 }, 'valid'),
  c('BB-27', 'BVA', 'latitude 1.481 (above)', { latitude: 1.481, longitude: 103.8 }, 'invalid: location'),
  c('BB-28', 'BVA', 'longitude 103.6 (west limit)', { latitude: 1.35, longitude: 103.6 }, 'valid'),
  c('BB-29', 'BVA', 'longitude 103.599 (below)', { latitude: 1.35, longitude: 103.599 }, 'invalid: location'),
  c('BB-30', 'BVA', 'longitude 104.1 (east limit)', { latitude: 1.35, longitude: 104.1 }, 'valid'),
  c('BB-31', 'BVA', 'longitude 104.101 (above)', { latitude: 1.35, longitude: 104.101 }, 'invalid: location'),
  c('BB-32', 'EC', 'not numeric', { latitude: 'abc', longitude: 103.8 }, 'invalid: location'),
], (v) => outcome(InputValidator.validateLocation(v)));

group('Hotspot report (UC3, UC5)', [
  c('BB-33', 'EC', 'all required fields, anonymous (FR-12 optional contact)', report(), 'valid'),
  c('BB-34', 'EC', 'unknown site type', report({ siteType: 'VOLCANO' }), 'invalid: siteType'),
  c('BB-35', 'EC', 'description only spaces', report({ description: '   ' }), 'invalid: description'),
  c('BB-36', 'BVA', 'description 1000 characters (maximum)', report({ description: str(1000) }), 'valid'),
  c('BB-37', 'BVA', 'description 1001 characters', report({ description: str(1001) }), 'invalid: description'),
  c('BB-38', 'EC', 'description is not text', report({ description: 12345 }), 'invalid: description'),
  c('BB-39', 'EC', 'optional contact with a bad phone', report({ contact: { phone: '123' } }), 'invalid: contact.phone'),
  c('BB-40', 'EC', 'optional contact with a bad email', report({ contact: { email: 'nope' } }), 'invalid: contact.email'),
], (v) => outcome(InputValidator.validateReportInput(v)));

group('Volunteer registration (UC6, FR-15)', [
  c('BB-41', 'EC', 'all fields valid', reg(), 'valid'),
  c('BB-42', 'EC', 'name blank', reg({ name: ' ' }), 'invalid: name'),
  c('BB-43', 'BVA', 'name 100 characters (maximum)', reg({ name: str(100) }), 'valid'),
  c('BB-44', 'BVA', 'name 101 characters', reg({ name: str(101) }), 'invalid: name'),
  c('BB-45', 'EC', 'name is not text', reg({ name: 12345 }), 'invalid: name'),
  c('BB-46', 'EC', 'consent not given', reg({ consentGiven: false }), 'invalid: consentGiven'),
  c('BB-47', 'EC', 'consent is the text "true", not a tick', reg({ consentGiven: 'true' }), 'invalid: consentGiven'),
], (v) => outcome(InputValidator.validateRegistrationInput(v)));

group('Volunteer activity (UC9, UC11)', [
  c('BB-48', 'EC', 'all fields valid', { input: activity() }, 'valid'),
  c('BB-49', 'BVA', 'title 120 characters (maximum)', { input: activity({ title: str(120) }) }, 'valid'),
  c('BB-50', 'BVA', 'title 121 characters', { input: activity({ title: str(121) }) }, 'invalid: title'),
  c('BB-51', 'EC', 'title is not text', { input: activity({ title: 12345 }) }, 'invalid: title'),
  c('BB-52', 'EC', 'target area is not text', { input: activity({ targetArea: 12345 }) }, 'invalid: targetArea'),
  c('BB-53', 'BVA', 'event 1 ms in the past', { input: activity({ eventDateTime: new Date(NOW.getTime() - 1).toISOString() }) }, 'invalid: eventDateTime'),
  c('BB-54', 'BVA', 'event exactly now', { input: activity({ eventDateTime: NOW.toISOString() }) }, 'invalid: eventDateTime'),
  c('BB-55', 'BVA', 'event 1 ms in the future', { input: activity({ eventDateTime: new Date(NOW.getTime() + 1).toISOString() }) }, 'valid'),
  c('BB-56', 'EC', 'date is not a date', { input: activity({ eventDateTime: 'soon' }) }, 'invalid: eventDateTime'),
  c('BB-57', 'BVA', 'quota 0 (below minimum)', { input: activity({ headcountQuota: 0 }) }, 'invalid: headcountQuota'),
  c('BB-58', 'BVA', 'quota 1 (minimum)', { input: activity({ headcountQuota: 1 }) }, 'valid'),
  c('BB-59', 'BVA', 'quota 500 (maximum)', { input: activity({ headcountQuota: 500 }) }, 'valid'),
  c('BB-60', 'BVA', 'quota 501 (above maximum)', { input: activity({ headcountQuota: 501 }) }, 'invalid: headcountQuota'),
  c('BB-61', 'EC', 'quota not a whole number: 2.5', { input: activity({ headcountQuota: 2.5 }) }, 'invalid: headcountQuota'),
  c('BB-62', 'EC', 'quota not numeric: "abc"', { input: activity({ headcountQuota: 'abc' }) }, 'invalid: headcountQuota'),
  c('BB-63', 'EC', 'quota is true (a boolean, not a number)', { input: activity({ headcountQuota: true }) }, 'invalid: headcountQuota'),
  c('BB-64', 'BVA', 'edit: quota equal to the 5 registered', { input: activity({ headcountQuota: 5 }), registered: 5 }, 'valid'),
  c('BB-65', 'BVA', 'edit: quota one below the 5 registered', { input: activity({ headcountQuota: 4 }), registered: 5 }, 'invalid: headcountQuota'),
], (v) => outcome(InputValidator.validateActivityInput(v.input, NOW, v.registered ?? 0)));

group('Public alert (UC7, FR-22)', [
  c('BB-66', 'EC', 'all fields valid', alert(), 'valid'),
  c('BB-67', 'EC', 'unknown severity', alert({ severity: 'SEVERE' }), 'invalid: severity'),
  c('BB-68', 'BVA', 'message 2000 characters (maximum)', alert({ body: str(2000) }), 'valid'),
  c('BB-69', 'BVA', 'message 2001 characters', alert({ body: str(2001) }), 'invalid: body'),
  c('BB-70', 'EC', 'title is not text', alert({ title: 12345 }), 'invalid: title'),
  c('BB-71', 'EC', 'message is not text', alert({ body: 12345 }), 'invalid: body'),
  c('BB-72', 'EC', 'target region missing', alert({ targetRegion: '' }), 'invalid: targetRegion'),
], (v) => outcome(InputValidator.validateAlertInput(v)));

group('Alert subscription (UC15, FR-32)', [
  c('BB-73', 'EC', 'SMS with a mobile number', sub(), 'valid'),
  c('BB-74', 'EC', 'email only, no phone', sub({ channels: ['EMAIL'], phone: undefined, email: 'tan@example.com' }), 'valid'),
  c('BB-75', 'EC', 'both channels, both contacts', sub({ channels: ['SMS', 'EMAIL'], email: 'tan@example.com' }), 'valid'),
  c('BB-76', 'BVA', 'no channel chosen', sub({ channels: [] }), 'invalid: channels'),
  c('BB-77', 'EC', 'unknown channel', sub({ channels: ['PIGEON'] }), 'invalid: channels'),
  c('BB-78', 'EC', 'SMS with a landline', sub({ phone: '61234567' }), 'invalid: phone'),
  c('BB-79', 'EC', 'email chosen but no address', sub({ channels: ['EMAIL'], phone: undefined }), 'invalid: email'),
  c('BB-80', 'EC', 'no consent', sub({ consentGiven: false }), 'invalid: consentGiven'),
], (v) => outcome(InputValidator.validateSubscriptionInput(v)));

group('Hotspot (UC17)', [
  c('BB-81', 'EC', 'all fields valid', hotspot(), 'valid'),
  c('BB-82', 'EC', 'disease not in the configured list (NFR-08)', hotspot({ diseaseType: 'FLU' }), 'invalid: diseaseType'),
  c('BB-83', 'BVA', 'case count 0 (minimum)', hotspot({ caseCount: 0 }), 'valid'),
  c('BB-84', 'BVA', 'case count -1', hotspot({ caseCount: -1 }), 'invalid: caseCount'),
  c('BB-85', 'EC', 'case count 1.5', hotspot({ caseCount: 1.5 }), 'invalid: caseCount'),
], (v) => outcome(InputValidator.validateHotspotInput(v, ['DENGUE', 'ZIKA'])));
