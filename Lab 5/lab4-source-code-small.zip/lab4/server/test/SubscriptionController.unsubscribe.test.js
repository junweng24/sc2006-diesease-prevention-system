import { mkdtempSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import path from 'node:path';
import { DatabaseSync } from 'node:sqlite';

import express from 'express';
import { afterAll, afterEach, beforeAll, beforeEach, describe, expect, test, vi } from 'vitest';

import { errorHandler } from '../src/boundary/middleware/errorHandler.js';
import { publicRoutes } from '../src/boundary/routes/publicRoutes.js';
import { Config } from '../src/config/Config.js';
import { NotificationService } from '../src/control/NotificationService.js';
import { PublicAlertController } from '../src/control/PublicAlertController.js';
import { SubscriptionController } from '../src/control/SubscriptionController.js';
import { ConflictError, NotFoundError } from '../src/control/errors.js';
import { AlertSubscription } from '../src/entity/AlertSubscription.js';
import { PublicAlert } from '../src/entity/PublicAlert.js';
import { Database } from '../src/repository/Database.js';
import { NotificationLogRepository } from '../src/repository/NotificationLogRepository.js';
import { PublicAlertRepository } from '../src/repository/PublicAlertRepository.js';
import { SubscriptionRepository } from '../src/repository/SubscriptionRepository.js';

/**
 * UC15 Unsubscribe from public alerts (PDPA withdrawal of consent). Runs the real repositories
 * on a throwaway in-memory database, because the schema's constraints are part of the feature.
 * Only the delivery channels are fakes, so the tests can read what subscribers would receive.
 */
const NOW = new Date('2026-11-02T12:00:00.000Z');
const BASE_URL = 'https://dps.example.sg';
const OFFICIAL = 1;

let db;
let repo;
let sent;
let notifications;
let controller;
let alerts;

const channel = (type) => ({
  type,
  send: vi.fn(async (recipient, message) => { sent.push({ type, recipient, message }); }),
});

const input = (overrides = {}) => ({
  channels: ['SMS', 'EMAIL'],
  phone: '91234567',
  email: 'ann@example.com',
  region: 'East',
  consentGiven: true,
  ...overrides,
});

const alertInput = (overrides = {}) => ({
  title: 'Dengue cluster',
  body: 'Remove stagnant water.',
  category: 'Dengue',
  severity: 'HIGH',
  targetRegion: 'East',
  ...overrides,
});

const activity = () => ({
  id: 1,
  title: 'Clean-up',
  targetArea: 'Tampines',
  eventDateTime: new Date('2026-12-01T02:00:00.000Z'),
  remainingSlots: () => 3,
});

const tokenIn = (text) => text.match(/https:\/\/\S+\/unsubscribe\/(\S+)/)[1];

/** Subscribes someone and forgets the confirmation messages. */
async function subscribed(overrides) {
  const subscription = await controller.subscribe(input(overrides));
  sent.length = 0;
  return subscription;
}

const publish = (overrides) => alerts.publishAlert(alertInput(overrides), OFFICIAL, NOW);

beforeEach(() => {
  db = new Database(':memory:');
  db.sqlite.exec("INSERT INTO officials (id, username, password_hash) VALUES (1, 'officer', 'x')");
  repo = new SubscriptionRepository(db);
  sent = [];
  notifications = new NotificationService({
    channels: [channel('SMS'), channel('EMAIL')],
    subscriptionRepo: repo,
    logRepo: new NotificationLogRepository(db),
    publicBaseUrl: `${BASE_URL}/`,
  });
  controller = new SubscriptionController({
    subscriptionRepo: repo, notificationService: notifications,
  });
  alerts = new PublicAlertController({
    alertRepo: new PublicAlertRepository(db),
    listeners: [notifications],
    smsPreviewer: notifications,
  });
});

afterEach(() => db.close());

describe('UC15 messages to subscribers include a way to unsubscribe', () => {
  test("a published alert has the subscriber's own link on both channels", async () => {
    const s = await subscribed();
    await publish();

    expect(sent.map((m) => m.type)).toEqual(['SMS', 'EMAIL']);
    const link = `${BASE_URL}/unsubscribe/${s.unsubscribeToken}`;
    expect(sent[0].message.smsText).toContain(link);
    expect(sent[1].message.text).toContain(link);
    expect(sent[1].message.text).toContain('Remove stagnant water.');
  });

  test('each subscriber gets a different, unguessable link', async () => {
    const a = await subscribed();
    const b = await subscribed({ phone: '81234567', email: 'bob@example.com' });
    expect(a.unsubscribeToken).toMatch(/^[0-9a-f]{32}$/);
    expect(b.unsubscribeToken).not.toBe(a.unsubscribeToken);

    await publish();
    const tokens = sent.filter((m) => m.type === 'EMAIL').map((m) => tokenIn(m.message.text));
    expect(tokens).toEqual([a.unsubscribeToken, b.unsubscribeToken]);
  });

  test('a long alert SMS stays within 160 characters and keeps the whole link', async () => {
    const s = await subscribed();
    await publish({ body: 'x'.repeat(2000) });

    const { smsText } = sent.find((m) => m.type === 'SMS').message;
    expect(smsText.length).toBeLessThanOrEqual(PublicAlert.SMS_MAX_LENGTH);
    expect(smsText.endsWith(`/unsubscribe/${s.unsubscribeToken}`)).toBe(true);
    expect(smsText).toContain('…');
  });

  test('a short alert SMS is not cut short', async () => {
    await subscribed();
    await publish();
    const { smsText } = sent.find((m) => m.type === 'SMS').message;
    expect(smsText).toContain('[HIGH] Dengue cluster: Remove stagnant water. Unsubscribe: ');
    expect(smsText).not.toContain('…');
  });

  test("the official's SMS preview has the same length as the real message", async () => {
    const s = await subscribed();
    const long = alertInput({ body: 'x'.repeat(500) });
    const preview = alerts.previewAlert(long);
    await alerts.publishAlert(long, OFFICIAL, NOW);

    const real = sent.find((m) => m.type === 'SMS').message.smsText;
    expect(preview.smsText.length).toBe(real.length);
    expect(preview.smsText).not.toContain(s.unsubscribeToken);
  });

  test('the subscription confirmation has the link', async () => {
    const s = await controller.subscribe(input());
    expect(sent.find((m) => m.type === 'SMS').message.smsText).toContain(s.unsubscribeToken);
    expect(sent.find((m) => m.type === 'EMAIL').message.text).toContain(s.unsubscribeToken);
  });

  test('volunteer news has the link', async () => {
    const s = await subscribed({ wantsVolunteerNews: true });
    await notifications.notifyActivityPublished(activity());
    expect(sent.find((m) => m.type === 'SMS').message.smsText).toContain(s.unsubscribeToken);
    expect(sent.find((m) => m.type === 'EMAIL').message.text).toContain(s.unsubscribeToken);
  });

  test('messages to registered volunteers, who are not subscribers, have no link', async () => {
    await notifications.notifyActivityChanged(activity(), [
      { contact: { phone: '91112222', email: 'vol@example.com' } },
    ]);
    expect(sent).toHaveLength(2);
    for (const { message } of sent) {
      const all = `${message.text} ${message.smsText}`;
      expect(all).not.toContain('nsubscribe');
      expect(all).not.toContain('undefined');
    }
  });
});

describe('UC15 unsubscribing withdraws consent', () => {
  test('consent is withdrawn and the contact details are erased', async () => {
    const s = await subscribed({ wantsVolunteerNews: true });
    await controller.unsubscribe(s.unsubscribeToken, NOW);

    const stored = await repo.findById(s.id);
    expect(stored.consentGiven).toBe(false);
    expect(stored.withdrawnAt).toEqual(NOW);
    expect(stored.email).toBeNull();
    expect(stored.phone).toBeNull();
  });

  test('no more alerts are sent, for the region or for all regions', async () => {
    const s = await subscribed();
    await controller.unsubscribe(s.unsubscribeToken, NOW);

    const first = await publish();
    const second = await publish({ targetRegion: 'ALL' });

    expect(sent).toEqual([]);
    expect(first.dispatch).toEqual({ sent: 0, failed: 0 });
    expect(second.dispatch).toEqual({ sent: 0, failed: 0 });
  });

  test('no more volunteer news is sent', async () => {
    const s = await subscribed({ wantsVolunteerNews: true });
    await controller.unsubscribe(s.unsubscribeToken, NOW);

    const summary = await notifications.notifyActivityPublished(activity());

    expect(sent).toEqual([]);
    expect(summary).toEqual({ sent: 0, failed: 0 });
  });

  test('the repository no longer lists them as a recipient', async () => {
    const s = await subscribed({ wantsVolunteerNews: true });
    await controller.unsubscribe(s.unsubscribeToken, NOW);

    expect(await repo.findByRegion('East')).toEqual([]);
    expect(await repo.findVolunteerNewsSubscribers()).toEqual([]);
  });

  test('unsubscribing sends no message of its own', async () => {
    const s = await subscribed();
    await controller.unsubscribe(s.unsubscribeToken, NOW);
    expect(sent).toEqual([]);
  });

  test('other subscribers are not affected', async () => {
    const a = await subscribed();
    const b = await subscribed({ phone: '81234567', email: 'bob@example.com' });
    await controller.unsubscribe(a.unsubscribeToken, NOW);

    await publish();

    expect(sent.map((m) => m.recipient)).toEqual(['81234567', 'bob@example.com']);
    expect((await repo.findById(b.id)).consentGiven).toBe(true);
  });

  test('an invalid link is rejected and changes nothing', async () => {
    const s = await subscribed();
    await expect(controller.unsubscribe('not-a-real-token', NOW)).rejects.toBeInstanceOf(NotFoundError);
    await expect(controller.getUnsubscribeStatus('not-a-real-token')).rejects.toBeInstanceOf(NotFoundError);
    expect((await repo.findById(s.id)).consentGiven).toBe(true);
  });

  test('a used link is reported as used and keeps the first withdrawal time', async () => {
    const s = await subscribed();
    await controller.unsubscribe(s.unsubscribeToken, NOW);

    await expect(controller.unsubscribe(s.unsubscribeToken, new Date('2027-01-01T00:00:00.000Z')))
      .rejects.toBeInstanceOf(ConflictError);
    expect(await controller.getUnsubscribeStatus(s.unsubscribeToken)).toEqual({ alreadyUnsubscribed: true });
    expect((await repo.findById(s.id)).withdrawnAt).toEqual(NOW);
  });

  test('two simultaneous clicks: one succeeds and one is told the link was used', async () => {
    const s = await subscribed();
    const results = await Promise.allSettled([
      controller.unsubscribe(s.unsubscribeToken, NOW),
      controller.unsubscribe(s.unsubscribeToken, NOW),
    ]);
    expect(results.map((r) => r.status).sort()).toEqual(['fulfilled', 'rejected']);
  });

  test('checking the link does not withdraw anything', async () => {
    const s = await subscribed();
    expect(await controller.getUnsubscribeStatus(s.unsubscribeToken)).toEqual({ alreadyUnsubscribed: false });
    expect((await repo.findById(s.id)).consentGiven).toBe(true);
  });

  test('the same person can subscribe again, and the old link cannot cancel it', async () => {
    const old = await subscribed();
    await controller.unsubscribe(old.unsubscribeToken, NOW);

    const again = await subscribed();
    expect(again.unsubscribeToken).not.toBe(old.unsubscribeToken);

    await expect(controller.unsubscribe(old.unsubscribeToken, NOW)).rejects.toBeInstanceOf(ConflictError);
    await publish();
    expect(sent.map((m) => m.recipient)).toEqual(['91234567', 'ann@example.com']);
  });

  test('a contact that is still subscribed is still rejected as a duplicate', async () => {
    await subscribed();
    await expect(controller.subscribe(input())).rejects.toBeInstanceOf(ConflictError);
  });
});

describe('UC15 unsubscribe over HTTP', () => {
  let server;
  let url;

  beforeAll(async () => {
    const app = express();
    app.use(express.json());
    // The controller is rebuilt for each test, so the route looks it up per request.
    app.use('/api', publicRoutes({
      subscriptions: {
        getUnsubscribeStatus: (token) => controller.getUnsubscribeStatus(token),
        unsubscribe: (token, now) => controller.unsubscribe(token, now),
      },
    }));
    app.use(errorHandler);
    await new Promise((resolve) => { server = app.listen(0, resolve); });
    url = `http://127.0.0.1:${server.address().port}/api/subscriptions/unsubscribe`;
  });

  afterAll(() => new Promise((resolve) => { server.close(resolve); }));

  test('GET reads the status only, and POST withdraws', async () => {
    const s = await subscribed();

    const before = await fetch(`${url}/${s.unsubscribeToken}`);
    expect(before.status).toBe(200);
    expect(await before.json()).toEqual({ alreadyUnsubscribed: false });
    expect((await repo.findById(s.id)).consentGiven).toBe(true);

    const done = await fetch(`${url}/${s.unsubscribeToken}`, { method: 'POST' });
    expect(done.status).toBe(200);
    expect((await repo.findById(s.id)).consentGiven).toBe(false);
  });

  test('a used link gives 409 on POST and says so on GET', async () => {
    const s = await subscribed();
    await fetch(`${url}/${s.unsubscribeToken}`, { method: 'POST' });

    expect((await fetch(`${url}/${s.unsubscribeToken}`, { method: 'POST' })).status).toBe(409);
    expect(await (await fetch(`${url}/${s.unsubscribeToken}`)).json()).toEqual({ alreadyUnsubscribed: true });
  });

  test('an invalid link gives 404 on GET and POST', async () => {
    expect((await fetch(`${url}/nope`)).status).toBe(404);
    expect((await fetch(`${url}/nope`, { method: 'POST' })).status).toBe(404);
  });

  test('responses contain no personal data (NFR-02)', async () => {
    const s = await subscribed();
    const body = await (await fetch(`${url}/${s.unsubscribeToken}`)).text();
    expect(body).not.toContain('ann@example.com');
    expect(body).not.toContain('91234567');
  });
});

describe('UC15 database created before unsubscribing existed', () => {
  let dir;
  let file;

  beforeEach(() => {
    dir = mkdtempSync(path.join(tmpdir(), 'dps-migrate-'));
    file = path.join(dir, 'old.db');
    // The table exactly as it was before this feature.
    const old = new DatabaseSync(file);
    old.exec(`
      CREATE TABLE alert_subscriptions (
        id                   INTEGER PRIMARY KEY AUTOINCREMENT,
        email                TEXT    UNIQUE,
        phone                TEXT    UNIQUE,
        channels             TEXT    NOT NULL,
        region               TEXT    NOT NULL,
        wants_volunteer_news INTEGER NOT NULL DEFAULT 0,
        consent_given        INTEGER NOT NULL CHECK (consent_given = 1),
        created_at           TEXT    NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),
        CHECK (email IS NOT NULL OR phone IS NOT NULL)
      );
      INSERT INTO alert_subscriptions
        (id, email, phone, channels, region, wants_volunteer_news, consent_given, created_at)
      VALUES (5, 'old@example.com', NULL, 'EMAIL', 'ALL', 1, 1, '2026-01-01T00:00:00.000Z'),
             (9, NULL, '98887777', 'SMS', 'East', 0, 1, '2026-01-02T00:00:00.000Z');
    `);
    old.close();
  });

  afterEach(() => rmSync(dir, { recursive: true, force: true }));

  test('existing subscribers are kept, get their own link and can unsubscribe', async () => {
    const upgraded = new Database(file);
    const oldRepo = new SubscriptionRepository(upgraded);
    const [a, b] = await oldRepo.findAll();

    expect([a.id, a.email, a.region, a.wantsVolunteerNews, a.consentGiven])
      .toEqual([5, 'old@example.com', 'ALL', true, true]);
    expect(a.createdAt).toEqual(new Date('2026-01-01T00:00:00.000Z'));
    expect([b.id, b.phone]).toEqual([9, '98887777']);
    expect(a.unsubscribeToken).toMatch(/^[0-9a-f]{32}$/);
    expect(b.unsubscribeToken).not.toBe(a.unsubscribeToken);

    expect(await oldRepo.withdrawConsent(a.unsubscribeToken, NOW)).toBe(true);
    expect((await oldRepo.findByRegion('East')).map((s) => s.id)).toEqual([9]);

    const next = await oldRepo.save(new AlertSubscription({
      phone: '91110000', channels: ['SMS'], region: 'ALL', consentGiven: true,
    }));
    expect(next.id).toBe(10);
    await upgraded.close();
  });

  test('opening the database again keeps the same tokens', async () => {
    const first = new Database(file);
    const before = await new SubscriptionRepository(first).findAll();
    await first.close();

    const second = new Database(file);
    const after = await new SubscriptionRepository(second).findAll();
    await second.close();

    expect(after.map((s) => s.unsubscribeToken)).toEqual(before.map((s) => s.unsubscribeToken));
  });
});

describe('UC15 address used in unsubscribe links', () => {
  afterEach(() => vi.unstubAllEnvs());

  const configWith = (env) => {
    for (const name of ['PUBLIC_BASE_URL', 'DEV_CLIENT_URL', 'PORT']) vi.stubEnv(name, env[name] ?? '');
    return new Config();
  };

  test('PUBLIC_BASE_URL wins', () => {
    expect(configWith({ PUBLIC_BASE_URL: 'https://a.sg', DEV_CLIENT_URL: 'http://localhost:5173' }).publicBaseUrl)
      .toBe('https://a.sg');
  });

  test('npm run dev uses the separate website port', () => {
    expect(configWith({ DEV_CLIENT_URL: 'http://localhost:5173', PORT: '3000' }).publicBaseUrl)
      .toBe('http://localhost:5173');
  });

  test('otherwise the server serves the website itself', () => {
    expect(configWith({ PORT: '3000' }).publicBaseUrl).toBe('http://localhost:3000');
  });
});
