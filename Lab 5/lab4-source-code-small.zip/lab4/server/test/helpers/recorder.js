import { mkdirSync, writeFileSync } from 'node:fs';

/**
 * Collects each test case's input, expected and ACTUAL output, so the results table in the
 * Lab 4 documentation comes from a real run rather than being typed by hand.
 * Files are written to server/test-results/<suite>.json.
 */
export class ResultRecorder {
  /** @param {string} suite file name without extension */
  constructor(suite) {
    this.suite = suite;
    this.rows = [];
  }

  /** @param {{id: string, technique?: string, input: string, expected: string, actual: string}} row */
  add(row) {
    this.rows.push({ ...row, pass: row.expected === row.actual });
  }

  /** Writes the JSON file; call from afterAll. */
  save() {
    const dir = new URL('../../test-results/', import.meta.url);
    mkdirSync(dir, { recursive: true });
    writeFileSync(new URL(`${this.suite}.json`, dir), JSON.stringify(this.rows, null, 2));
  }
}
