-- Disease Prevention System - SQLite schema (Lab 3 design, see Lab 3 Documentation §3.3)
-- Applied automatically by Database.js every time the server starts (every statement is
-- idempotent), so there is no manual set-up step.
--
-- SQLite has no boolean or timestamp types:
--   booleans   are INTEGER 0/1
--   timestamps are TEXT in ISO-8601 UTC ('2026-10-20T03:00:39.283Z'), which sorts correctly

CREATE TABLE IF NOT EXISTS officials (
  id                    INTEGER PRIMARY KEY AUTOINCREMENT,
  username              TEXT    NOT NULL UNIQUE,
  password_hash         TEXT    NOT NULL,                -- bcrypt hash, never plain text (UC14)
  role                  TEXT    NOT NULL DEFAULT 'OFFICIAL' CHECK (role IN ('OFFICIAL')),
  failed_login_attempts INTEGER NOT NULL DEFAULT 0,
  locked_until          TEXT,
  created_at            TEXT    NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
);

CREATE TABLE IF NOT EXISTS disease_types (
  code  TEXT PRIMARY KEY,                                -- NFR-08: add a row, not code
  label TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS hotspot_reports (
  reference_id  TEXT    PRIMARY KEY,
  latitude      REAL    NOT NULL,
  longitude     REAL    NOT NULL,
  address       TEXT,
  postal_code   TEXT,
  site_type     TEXT    NOT NULL,
  description   TEXT    NOT NULL,
  photo_path    TEXT,
  contact_name  TEXT,
  contact_phone TEXT,
  contact_email TEXT,
  status        TEXT    NOT NULL DEFAULT 'UNVERIFIED'
                CHECK (status IN ('UNVERIFIED', 'VERIFIED_ACTIVE', 'RESOLVED', 'DISMISSED')),
  submitted_at  TEXT    NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),
  reviewed_by   INTEGER REFERENCES officials(id),
  reviewed_at   TEXT,
  version       INTEGER NOT NULL DEFAULT 1               -- optimistic locking (UC8 4a)
);

CREATE TABLE IF NOT EXISTS hotspots (
  id               INTEGER PRIMARY KEY AUTOINCREMENT,
  disease_type     TEXT    NOT NULL REFERENCES disease_types(code),
  latitude         REAL    NOT NULL,
  longitude        REAL    NOT NULL,
  address          TEXT,
  postal_code      TEXT,
  case_count       INTEGER NOT NULL DEFAULT 0 CHECK (case_count >= 0),
  risk_level       TEXT    NOT NULL CHECK (risk_level IN ('LOW', 'HIGH')),
  source           TEXT    NOT NULL CHECK (source IN ('OFFICIAL', 'VERIFIED_REPORT')),
  source_report_id TEXT    REFERENCES hotspot_reports(reference_id),
  is_active        INTEGER NOT NULL DEFAULT 1,           -- soft delete (UC17)
  created_by       INTEGER NOT NULL REFERENCES officials(id),
  created_at       TEXT    NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
);

CREATE TABLE IF NOT EXISTS cluster_snapshots (
  id        INTEGER PRIMARY KEY AUTOINCREMENT,
  clusters  TEXT NOT NULL,                               -- JSON: cached data.gov.sg clusters (UC1 2a)
  synced_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
);

CREATE TABLE IF NOT EXISTS public_alerts (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  title         TEXT    NOT NULL,
  body          TEXT    NOT NULL,
  category      TEXT    NOT NULL,
  severity      TEXT    NOT NULL CHECK (severity IN ('LOW', 'MEDIUM', 'HIGH', 'CRITICAL')),
  target_region TEXT    NOT NULL,
  published_at  TEXT    NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),
  published_by  INTEGER NOT NULL REFERENCES officials(id)
);

CREATE TABLE IF NOT EXISTS alert_subscriptions (
  id                   INTEGER PRIMARY KEY AUTOINCREMENT,
  email                TEXT    UNIQUE,
  phone                TEXT    UNIQUE,
  channels             TEXT    NOT NULL,                 -- 'SMS', 'EMAIL' or 'SMS,EMAIL'
  region               TEXT    NOT NULL,
  wants_volunteer_news INTEGER NOT NULL DEFAULT 0,
  consent_given        INTEGER NOT NULL CHECK (consent_given IN (0, 1)), -- 0 = withdrawn (UC15)
  unsubscribe_token    TEXT    NOT NULL UNIQUE,          -- secret in each unsubscribe link
  withdrawn_at         TEXT,
  created_at           TEXT    NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),
  CHECK (consent_given = 0 OR email IS NOT NULL OR phone IS NOT NULL),
  -- Withdrawing consent erases the contact details; the row only remembers the used link.
  CHECK (consent_given = 1 OR (email IS NULL AND phone IS NULL AND withdrawn_at IS NOT NULL))
);

CREATE TABLE IF NOT EXISTS volunteer_activities (
  id               INTEGER PRIMARY KEY AUTOINCREMENT,
  title            TEXT    NOT NULL,
  target_area      TEXT    NOT NULL,
  event_datetime   TEXT    NOT NULL,
  headcount_quota  INTEGER NOT NULL CHECK (headcount_quota > 0),
  registered_count INTEGER NOT NULL DEFAULT 0,
  priority         TEXT    NOT NULL DEFAULT 'NORMAL',
  description      TEXT,
  contact_name     TEXT,
  contact_phone    TEXT,
  status           TEXT    NOT NULL DEFAULT 'OPEN'
                   CHECK (status IN ('OPEN', 'FULL', 'COMPLETED', 'CANCELLED')),
  created_by       INTEGER NOT NULL REFERENCES officials(id),
  created_at       TEXT    NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),
  CHECK (registered_count BETWEEN 0 AND headcount_quota)   -- no overbooking
);

CREATE TABLE IF NOT EXISTS volunteer_registrations (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  activity_id   INTEGER NOT NULL REFERENCES volunteer_activities(id) ON DELETE CASCADE,
  name          TEXT    NOT NULL,
  phone         TEXT    NOT NULL,
  email         TEXT    NOT NULL,
  consent_given INTEGER NOT NULL CHECK (consent_given = 1),
  registered_at TEXT    NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),
  UNIQUE (activity_id, email),                            -- UC6 2a: no duplicates (NFR-03)
  UNIQUE (activity_id, phone)
);

CREATE TABLE IF NOT EXISTS notification_logs (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  subject_type  TEXT    NOT NULL,                         -- 'ALERT' | 'ACTIVITY' | 'SUBSCRIPTION'
  subject_id    INTEGER NOT NULL,
  channel       TEXT    NOT NULL CHECK (channel IN ('SMS', 'EMAIL')),
  recipient     TEXT    NOT NULL,
  status        TEXT    NOT NULL CHECK (status IN ('SENT', 'FAILED', 'PENDING_RETRY')),
  error_message TEXT,
  attempt_count INTEGER NOT NULL DEFAULT 1,
  created_at    TEXT    NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
);

INSERT OR IGNORE INTO disease_types (code, label) VALUES
  ('DENGUE', 'Dengue'), ('ZIKA', 'Zika'), ('CHIKUNGUNYA', 'Chikungunya');
