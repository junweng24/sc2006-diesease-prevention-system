import { defineConfig } from 'vitest/config';

const NODE_SQLITE = '\0node-sqlite';

/**
 * Vitest 2 removes the "node:" prefix from imports, but node:sqlite only exists with the prefix,
 * so tests that use the real {@link Database} would fail to load. This hands them Node's module.
 */
const nodeSqlite = {
  name: 'node-sqlite',
  enforce: 'pre',
  resolveId: (id) => (id === 'sqlite' || id === 'node:sqlite' ? NODE_SQLITE : null),
  load: (id) => (id === NODE_SQLITE
    ? "export const { DatabaseSync } = process.getBuiltinModule('node:sqlite');"
    : null),
};

export default defineConfig({ plugins: [nodeSqlite] });
