/**
 * «entity» Value object holding a person's optional contact details (UC5, UC6).
 * Personal data: only exposed through admin endpoints (NFR-02).
 */
export class ContactDetails {
  /** @param {{name?: string, phone?: string, email?: string}} props */
  constructor({ name = null, phone = null, email = null } = {}) {
    this.name = name;
    this.phone = phone;
    this.email = email;
  }

  /** @returns {boolean} true if no contact field was provided (anonymous report) */
  isEmpty() {
    return !this.name && !this.phone && !this.email;
  }
}
