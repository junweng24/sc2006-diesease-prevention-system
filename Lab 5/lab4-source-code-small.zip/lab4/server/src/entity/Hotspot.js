import { HotspotSource, RiskLevel } from './enums.js';

/**
 * «entity» A confirmed disease hotspot shown on the public map, managed by officials (UC8, UC17).
 */
export class Hotspot {
  /**
   * @param {{id?: number, diseaseType: string, location: import('./GeoLocation.js').GeoLocation,
   *          caseCount?: number, riskLevel?: string, source: string, sourceReportId?: string|null,
   *          isActive?: boolean, createdBy: number, createdAt?: Date}} props
   */
  constructor({ id = null, diseaseType, location, caseCount = 0, riskLevel = RiskLevel.LOW, source,
    sourceReportId = null, isActive = true, createdBy, createdAt = new Date() }) {
    this.id = id;
    this.diseaseType = diseaseType;
    this.location = location;
    this.caseCount = caseCount;
    this.riskLevel = riskLevel;
    this.source = source;
    this.sourceReportId = sourceReportId;
    this.isActive = isActive;
    this.createdBy = createdBy;
    this.createdAt = createdAt;
  }

  /** Soft-deletes the hotspot so it no longer appears on the public map (FR-21). */
  remove() {
    this.isActive = false;
  }

  /**
   * Creates a hotspot from a report that an official has verified (UC8).
   * @param {import('./HotspotReport.js').HotspotReport} report
   * @param {number} officialId
   * @param {string} [diseaseType='DENGUE']
   * @returns {Hotspot}
   */
  static fromVerifiedReport(report, officialId, diseaseType = 'DENGUE') {
    return new Hotspot({
      diseaseType,
      location: report.location,
      caseCount: 0,
      riskLevel: RiskLevel.LOW,
      source: HotspotSource.VERIFIED_REPORT,
      sourceReportId: report.referenceId,
      createdBy: officialId,
    });
  }
}
