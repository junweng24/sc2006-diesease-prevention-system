import { RiskLevel } from './enums.js';

/**
 * «entity» A dengue cluster published by NEA on data.gov.sg (UC1). Not edited by our system;
 * cached in `cluster_snapshots` so the map can still show the last known state (UC1 2a).
 */
export class DengueCluster {
  /** NEA marks clusters with 10 or more cases as high-risk ("red") clusters. */
  static HIGH_RISK_THRESHOLD = 10;

  /**
   * @param {{clusterId: string, locality: string, caseCount: number,
   *          boundary: import('./GeoLocation.js').GeoLocation[]}} props
   */
  constructor({ clusterId, locality, caseCount, boundary }) {
    this.clusterId = clusterId;
    this.locality = locality;
    this.caseCount = caseCount;
    this.boundary = boundary;
  }

  /** @returns {string} {@link RiskLevel.HIGH} if caseCount ≥ 10, else {@link RiskLevel.LOW} */
  riskLevel() {
    return this.caseCount >= DengueCluster.HIGH_RISK_THRESHOLD ? RiskLevel.HIGH : RiskLevel.LOW;
  }
}
