import { randomBytes } from 'node:crypto';

/**
 * «entity» A public user's opt-in to receive alerts by SMS and/or email (UC15, FR-24..27).
 */
export class AlertSubscription {
  /** Region value meaning "send me alerts for every region". */
  static ALL_REGIONS = 'ALL';

  /**
   * @param {{id?: number, email?: string|null, phone?: string|null, channels: string[],
   *          region: string, wantsVolunteerNews?: boolean, consentGiven: boolean,
   *          unsubscribeToken?: string, withdrawnAt?: Date|null, createdAt?: Date}} props
   */
  constructor({ id = null, email = null, phone = null, channels, region,
    wantsVolunteerNews = false, consentGiven, unsubscribeToken = randomBytes(16).toString('hex'),
    withdrawnAt = null, createdAt = new Date() }) {
    this.id = id;
    this.email = email;
    this.phone = phone;
    this.channels = channels;
    this.region = region;
    this.wantsVolunteerNews = wantsVolunteerNews;
    this.consentGiven = consentGiven;
    /** Unguessable secret that identifies this subscription in its unsubscribe link (UC15). */
    this.unsubscribeToken = unsubscribeToken;
    this.withdrawnAt = withdrawnAt;
    this.createdAt = createdAt;
  }

  /**
   * @param {string} alertRegion target region of an alert
   * @returns {boolean} true if this subscriber should receive an alert for that region
   */
  matchesRegion(alertRegion) {
    return (
      this.region === AlertSubscription.ALL_REGIONS ||
      alertRegion === AlertSubscription.ALL_REGIONS ||
      this.region === alertRegion
    );
  }
}
