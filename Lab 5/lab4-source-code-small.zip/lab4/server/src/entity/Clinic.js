/**
 * «entity» A CHAS clinic published by MOH on data.gov.sg (UC19). Read-only reference data:
 * our system never edits it, and it is kept in memory by {@link ClinicCache}.
 */
export class Clinic {
  /**
   * @param {{code: string, name: string, phone: string|null,
   *          location: import('./GeoLocation.js').GeoLocation}} props
   */
  constructor({ code, name, phone = null, location }) {
    this.code = code;
    this.name = name;
    this.phone = phone;
    this.location = location;
  }

  /**
   * @param {import('./GeoLocation.js').GeoLocation} from
   * @returns {number} straight-line distance in kilometres (UC19 step 2)
   */
  distanceKmFrom(from) {
    return this.location.distanceKmTo(from);
  }
}
