/**
 * «entity» Value object for a point in Singapore, as resolved by OneMap (UC2).
 */
export class GeoLocation {
  /** Rough bounding box of Singapore, used to reject obviously wrong pins. */
  static BOUNDS = Object.freeze({ minLat: 1.15, maxLat: 1.48, minLng: 103.6, maxLng: 104.1 });

  /**
   * @param {{latitude: number, longitude: number, address?: string, postalCode?: string}} props
   */
  constructor({ latitude, longitude, address = null, postalCode = null }) {
    this.latitude = Number(latitude);
    this.longitude = Number(longitude);
    this.address = address;
    this.postalCode = postalCode;
  }

  /**
   * Great-circle (haversine) distance; accurate enough for distances within Singapore.
   * @param {GeoLocation} other
   * @returns {number} distance in kilometres
   */
  distanceKmTo(other) {
    const EARTH_RADIUS_KM = 6371;
    const rad = (deg) => (deg * Math.PI) / 180;
    const dLat = rad(other.latitude - this.latitude);
    const dLng = rad(other.longitude - this.longitude);
    const a = Math.sin(dLat / 2) ** 2
      + Math.cos(rad(this.latitude)) * Math.cos(rad(other.latitude)) * Math.sin(dLng / 2) ** 2;
    return 2 * EARTH_RADIUS_KM * Math.asin(Math.sqrt(a));
  }

  /** @returns {boolean} true if the coordinates fall inside Singapore's bounding box */
  isWithinSingapore() {
    const b = GeoLocation.BOUNDS;
    return (
      this.latitude >= b.minLat && this.latitude <= b.maxLat &&
      this.longitude >= b.minLng && this.longitude <= b.maxLng
    );
  }
}
