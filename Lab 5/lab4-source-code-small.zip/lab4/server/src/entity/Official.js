import { OfficialRole } from './enums.js';

/**
 * «entity» A health / environmental official who can log in to the officials' portal (UC14).
 */
export class Official {
  /**
   * @param {{id?: number, username: string, passwordHash: string, role?: string,
   *          failedLoginAttempts?: number, lockedUntil?: Date|null}} props
   */
  constructor({ id = null, username, passwordHash, role = OfficialRole.OFFICIAL,
    failedLoginAttempts = 0, lockedUntil = null }) {
    this.id = id;
    this.username = username;
    this.passwordHash = passwordHash;
    this.role = role;
    this.failedLoginAttempts = failedLoginAttempts;
    this.lockedUntil = lockedUntil ? new Date(lockedUntil) : null;
  }

  /**
   * @param {Date} now
   * @returns {boolean} true while a temporary lock-out is in force (UC14 2b)
   */
  isLocked(now) {
    return this.lockedUntil !== null && now < this.lockedUntil;
  }

  /**
   * Records a failed login and locks the account once the limit is reached.
   * @param {Date} now
   * @param {number} maxAttempts number of failures allowed before locking
   * @param {number} lockoutMinutes how long the lock lasts
   */
  recordFailedLogin(now, maxAttempts, lockoutMinutes) {
    this.failedLoginAttempts += 1;
    if (this.failedLoginAttempts >= maxAttempts) {
      this.lockedUntil = new Date(now.getTime() + lockoutMinutes * 60_000);
      this.failedLoginAttempts = 0;
    }
  }

  /** Clears the failure counter after a successful login. */
  resetFailedLogins() {
    this.failedLoginAttempts = 0;
    this.lockedUntil = null;
  }
}
