/**
 * Enumerations used by the entity classes. Frozen objects act as Java-style enums.
 */

/** Lifecycle of a public hotspot report (UC3, UC8). */
export const ReportStatus = Object.freeze({
  UNVERIFIED: 'UNVERIFIED',
  VERIFIED_ACTIVE: 'VERIFIED_ACTIVE',
  RESOLVED: 'RESOLVED',
  DISMISSED: 'DISMISSED',
});

/** Lifecycle of a volunteer activity (UC9, UC10). */
export const ActivityStatus = Object.freeze({
  OPEN: 'OPEN',
  FULL: 'FULL',
  COMPLETED: 'COMPLETED',
  CANCELLED: 'CANCELLED',
});

export const Severity = Object.freeze({
  LOW: 'LOW',
  MEDIUM: 'MEDIUM',
  HIGH: 'HIGH',
  CRITICAL: 'CRITICAL',
});

export const RiskLevel = Object.freeze({ LOW: 'LOW', HIGH: 'HIGH' });

export const HotspotSource = Object.freeze({
  OFFICIAL: 'OFFICIAL',
  VERIFIED_REPORT: 'VERIFIED_REPORT',
});

export const BreedingSiteType = Object.freeze({
  STAGNANT_WATER: 'STAGNANT_WATER',
  CONTAINER: 'CONTAINER',
  DRAIN: 'DRAIN',
  PLANT_POT: 'PLANT_POT',
  CONSTRUCTION_SITE: 'CONSTRUCTION_SITE',
  OTHER: 'OTHER',
});

/** Only one role today; the field exists so new roles can be added without a schema change. */
export const OfficialRole = Object.freeze({ OFFICIAL: 'OFFICIAL' });

export const ChannelType = Object.freeze({ SMS: 'SMS', EMAIL: 'EMAIL' });

export const DeliveryStatus = Object.freeze({
  SENT: 'SENT',
  FAILED: 'FAILED',
  PENDING_RETRY: 'PENDING_RETRY',
});
