import { ActivityStatus } from './enums.js';

/**
 * «entity» A community outreach activity created by an official (UC9) that the public can
 * register for (UC6).
 */
export class VolunteerActivity {
  /**
   * @param {{id?: number, title: string, targetArea: string, eventDateTime: Date,
   *          headcountQuota: number, registeredCount?: number, priority?: string,
   *          description?: string, contactPerson?: import('./ContactDetails.js').ContactDetails|null,
   *          status?: string, createdBy: number}} props
   */
  constructor({ id = null, title, targetArea, eventDateTime, headcountQuota, registeredCount = 0,
    priority = 'NORMAL', description = '', contactPerson = null, status = ActivityStatus.OPEN,
    createdBy }) {
    this.id = id;
    this.title = title;
    this.targetArea = targetArea;
    this.eventDateTime = new Date(eventDateTime);
    this.headcountQuota = headcountQuota;
    this.registeredCount = registeredCount;
    this.priority = priority;
    this.description = description;
    this.contactPerson = contactPerson;
    this.status = status;
    this.createdBy = createdBy;
  }

  /** @returns {number} open slots left, never negative */
  remainingSlots() {
    return Math.max(0, this.headcountQuota - this.registeredCount);
  }

  /** @returns {boolean} true when no slots remain (UC6 2a) */
  isFull() {
    return this.remainingSlots() === 0;
  }

  /**
   * @param {Date} now
   * @returns {boolean} true if a new registration may be accepted right now
   */
  canAcceptRegistration(now) {
    this.refreshStatus(now);
    return this.status === ActivityStatus.OPEN;
  }

  /**
   * Recomputes the status: COMPLETED after the event date (UC9 special requirement),
   * FULL when no slots remain, otherwise OPEN. CANCELLED is never changed automatically.
   * @param {Date} now
   */
  refreshStatus(now) {
    if (this.status === ActivityStatus.CANCELLED) return;
    if (this.eventDateTime < now) this.status = ActivityStatus.COMPLETED;
    else if (this.isFull()) this.status = ActivityStatus.FULL;
    else this.status = ActivityStatus.OPEN;
  }
}
