/**
 * «entity» A public health alert published by an official (UC7) and shown on the home feed (UC16).
 */
export class PublicAlert {
  /** Standard single-segment SMS length (UC7 special requirement). */
  static SMS_MAX_LENGTH = 160;

  /**
   * @param {{id?: number, title: string, body: string, category: string, severity: string,
   *          targetRegion: string, publishedAt?: Date, publishedBy: number}} props
   */
  constructor({ id = null, title, body, category, severity, targetRegion,
    publishedAt = new Date(), publishedBy }) {
    this.id = id;
    this.title = title;
    this.body = body;
    this.category = category;
    this.severity = severity;
    this.targetRegion = targetRegion;
    this.publishedAt = publishedAt;
    this.publishedBy = publishedBy;
  }

  /**
   * Formats the alert as a single SMS, truncated to 160 characters with an ellipsis.
   * @param {number} [reservedLength=0] characters to leave free for text added after this one,
   *   such as the unsubscribe link (UC15), so that it is never cut off
   * @returns {string}
   */
  toSmsText(reservedLength = 0) {
    const limit = Math.max(1, PublicAlert.SMS_MAX_LENGTH - reservedLength);
    const text = `[${this.severity}] ${this.title}: ${this.body}`;
    if (text.length <= limit) return text;
    return `${text.slice(0, limit - 1)}…`;
  }
}
