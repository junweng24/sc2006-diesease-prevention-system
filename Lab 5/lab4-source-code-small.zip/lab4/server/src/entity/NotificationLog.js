/**
 * «entity» Outcome of sending one notification to one recipient. Failed entries are kept so
 * they can be retried (UC7 6a).
 */
export class NotificationLog {
  /**
   * @param {{id?: number, subjectType: 'ALERT'|'ACTIVITY'|'SUBSCRIPTION', subjectId: number,
   *          channel: string, recipient: string, status: string, errorMessage?: string|null,
   *          attemptCount?: number, createdAt?: Date}} props
   */
  constructor({ id = null, subjectType, subjectId, channel, recipient, status,
    errorMessage = null, attemptCount = 1, createdAt = new Date() }) {
    this.id = id;
    this.subjectType = subjectType;
    this.subjectId = subjectId;
    this.channel = channel;
    this.recipient = recipient;
    this.status = status;
    this.errorMessage = errorMessage;
    this.attemptCount = attemptCount;
    this.createdAt = createdAt;
  }
}
