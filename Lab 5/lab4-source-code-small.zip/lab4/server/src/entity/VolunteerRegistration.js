/**
 * «entity» One public user's registration for one volunteer activity (UC6).
 */
export class VolunteerRegistration {
  /**
   * @param {{id?: number, activityId: number,
   *          contact: import('./ContactDetails.js').ContactDetails,
   *          consentGiven: boolean, registeredAt?: Date}} props
   */
  constructor({ id = null, activityId, contact, consentGiven, registeredAt = new Date() }) {
    this.id = id;
    this.activityId = activityId;
    this.contact = contact;
    this.consentGiven = consentGiven;
    this.registeredAt = registeredAt;
  }
}
