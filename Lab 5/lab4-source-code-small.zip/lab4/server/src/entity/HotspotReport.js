import { ReportStatus } from './enums.js';

/**
 * Allowed status transitions for a report (UC8). Any other transition is rejected.
 * @type {Record<string, string[]>}
 */
const ALLOWED_TRANSITIONS = Object.freeze({
  [ReportStatus.UNVERIFIED]: [ReportStatus.VERIFIED_ACTIVE, ReportStatus.DISMISSED],
  [ReportStatus.VERIFIED_ACTIVE]: [ReportStatus.RESOLVED],
  [ReportStatus.RESOLVED]: [],
  [ReportStatus.DISMISSED]: [],
});

/**
 * «entity» A potential disease hotspot / breeding site reported by a public user (UC3–UC5).
 */
export class HotspotReport {
  /**
   * @param {{referenceId: string, location: import('./GeoLocation.js').GeoLocation,
   *          siteType: string, description: string, photoPath?: string|null,
   *          contact?: import('./ContactDetails.js').ContactDetails|null, status?: string,
   *          submittedAt?: Date, reviewedBy?: number|null, reviewedAt?: Date|null,
   *          version?: number}} props
   */
  constructor({ referenceId, location, siteType, description, photoPath = null, contact = null,
    status = ReportStatus.UNVERIFIED, submittedAt = new Date(), reviewedBy = null,
    reviewedAt = null, version = 1 }) {
    this.referenceId = referenceId;
    this.location = location;
    this.siteType = siteType;
    this.description = description;
    this.photoPath = photoPath;
    this.contact = contact;
    this.status = status;
    this.submittedAt = submittedAt;
    this.reviewedBy = reviewedBy;
    this.reviewedAt = reviewedAt;
    this.version = version;
  }

  /**
   * @param {string} next a {@link ReportStatus} value
   * @returns {boolean} true if moving from the current status to `next` is allowed
   */
  canTransitionTo(next) {
    return (ALLOWED_TRANSITIONS[this.status] ?? []).includes(next);
  }

  /**
   * Changes the status and records who reviewed it.
   * @param {string} next a {@link ReportStatus} value
   * @param {number} officialId reviewer
   * @param {Date} now
   * @throws {Error} if the transition is not allowed
   */
  transitionTo(next, officialId, now) {
    if (!this.canTransitionTo(next)) {
      throw new Error(`Cannot change report status from ${this.status} to ${next}`);
    }
    this.status = next;
    this.reviewedBy = officialId;
    this.reviewedAt = now;
  }

  /**
   * Generates a short human-readable reference ID shown to the user (UC3 step 7).
   * @param {Date} now
   * @returns {string} e.g. "HR-20261008-4F7K"
   */
  static generateReferenceId(now) {
    const date = now.toISOString().slice(0, 10).replaceAll('-', '');
    const suffix = Math.random().toString(36).slice(2, 6).toUpperCase().padEnd(4, '0');
    return `HR-${date}-${suffix}`;
  }
}
