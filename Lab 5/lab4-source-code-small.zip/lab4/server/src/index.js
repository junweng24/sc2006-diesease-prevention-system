/**
 * Process entry point. Delegates all initialisation to the start-up class {@link ServerApp}.
 */
import { ServerApp } from './ServerApp.js';

const app = new ServerApp();
app.start().catch((err) => {
  console.error('Failed to start server:', err);
  process.exit(1);
});
