import { ChannelType, DeliveryStatus } from '../entity/enums.js';
import { NotificationLog } from '../entity/NotificationLog.js';

/**
 * @typedef {{subject: string, text: string, smsText?: string}} NotificationMessage
 * @typedef {{sent: number, failed: number}} DispatchSummary
 */

/** Stands in for a real token in the SMS preview, so its length matches what is really sent. */
const PREVIEW_TOKEN = 'x'.repeat(32);

/**
 * «control» Sends notifications to subscribers through whichever channels they chose.
 *
 * - Strategy pattern: it depends only on the {@link NotificationChannel} interface, so SMS,
 *   email or a future WhatsApp channel are interchangeable (FR-26, FR-27).
 * - Observer pattern: it is registered as a listener on {@link PublicAlertController} and
 *   {@link VolunteerActivityController}, which call {@link notifyAlertPublished} /
 *   {@link notifyActivityPublished} when something is published (FR-24, FR-25).
 *
 * A failed delivery never undoes the publication; it is written to the notification log for
 * retry instead (UC7 6a).
 */
export class NotificationService {
  /**
   * @param {{channels: import('../boundary/channels/NotificationChannel.js').NotificationChannel[],
   *          subscriptionRepo: import('../repository/SubscriptionRepository.js').SubscriptionRepository,
   *          logRepo: import('../repository/NotificationLogRepository.js').NotificationLogRepository,
   *          publicBaseUrl: string}} deps `publicBaseUrl` is where the website is reachable, used
   *   to build unsubscribe links (UC15)
   */
  constructor({ channels, subscriptionRepo, logRepo, publicBaseUrl }) {
    /** @type {Map<string, import('../boundary/channels/NotificationChannel.js').NotificationChannel>} */
    this.channels = new Map(channels.map((c) => [c.type, c]));
    this.subscriptionRepo = subscriptionRepo;
    this.logRepo = logRepo;
    this.publicBaseUrl = publicBaseUrl.replace(/\/+$/, '');
  }

  /**
   * Observer callback: sends a newly published alert to subscribers in its region (UC7).
   * @param {import('../entity/PublicAlert.js').PublicAlert} alert
   * @returns {Promise<DispatchSummary>}
   */
  async notifyAlertPublished(alert) {
    const subscribers = await this.subscriptionRepo.findByRegion(alert.targetRegion);
    return this.#dispatch('ALERT', alert.id, subscribers, (sub) => ({
      subject: `[${alert.severity}] ${alert.title}`,
      text: `${alert.body}${this.#emailFooter(sub.unsubscribeToken)}`,
      smsText: this.#alertSms(alert, sub.unsubscribeToken),
    }));
  }

  /**
   * UC7 step 4: the SMS exactly as a subscriber would get it, including the unsubscribe link.
   * @param {import('../entity/PublicAlert.js').PublicAlert} alert
   * @returns {string}
   */
  previewAlertSms(alert) {
    return this.#alertSms(alert, PREVIEW_TOKEN);
  }

  /**
   * Observer callback: tells volunteer-news subscribers about a new activity (UC9, FR-25).
   * @param {import('../entity/VolunteerActivity.js').VolunteerActivity} activity
   * @returns {Promise<DispatchSummary>}
   */
  async notifyActivityPublished(activity) {
    const subscribers = await this.subscriptionRepo.findVolunteerNewsSubscribers();
    const when = activity.eventDateTime.toLocaleString('en-SG', { timeZone: 'Asia/Singapore' });
    const text = `${activity.title} at ${activity.targetArea} on ${when}. `
      + `${activity.remainingSlots()} slots available. Register on the "Become a volunteer" page.`;
    return this.#dispatch('ACTIVITY', activity.id, subscribers, (sub) => ({
      subject: `New volunteer activity: ${activity.title}`,
      text: `${text}${this.#emailFooter(sub.unsubscribeToken)}`,
      smsText: `${text}${this.#smsFooter(sub.unsubscribeToken)}`,
    }));
  }

  /**
   * Observer callback: tells everyone registered for an activity that its date or venue
   * changed (UC11, FR-25). Volunteers gave both a phone number and an email, so both are used.
   * These people registered for the activity rather than subscribed, so there is no unsubscribe
   * link in this message.
   * @param {import('../entity/VolunteerActivity.js').VolunteerActivity} activity
   * @param {import('../entity/VolunteerRegistration.js').VolunteerRegistration[]} roster
   * @returns {Promise<DispatchSummary>}
   */
  notifyActivityChanged(activity, roster) {
    const when = activity.eventDateTime.toLocaleString('en-SG', { timeZone: 'Asia/Singapore' });
    const recipients = roster.map((r) => ({
      channels: [ChannelType.SMS, ChannelType.EMAIL], phone: r.contact.phone, email: r.contact.email,
    }));
    const text = `Update: "${activity.title}" is now at ${activity.targetArea} on ${when}.`;
    return this.#dispatch('ACTIVITY', activity.id, recipients, () => ({
      subject: `Volunteer activity changed: ${activity.title}`,
      text: `${text} If you can no longer attend, please contact the organiser.`,
      smsText: text,
    }));
  }

  /**
   * Sends a "you are subscribed" message (UC15 step 4).
   * @param {import('../entity/AlertSubscription.js').AlertSubscription} subscription
   * @returns {Promise<DispatchSummary>}
   */
  sendSubscriptionConfirmation(subscription) {
    const text = `You will receive alerts for region: ${subscription.region}.`;
    return this.#dispatch('SUBSCRIPTION', subscription.id, [subscription], (sub) => ({
      subject: 'You are subscribed to public health alerts',
      text: `${text}${this.#emailFooter(sub.unsubscribeToken)}`,
      smsText: `${text}${this.#smsFooter(sub.unsubscribeToken)}`,
    }));
  }

  /** The alert cut short where needed so that alert + link still fit in one SMS (UC7, UC15). */
  #alertSms(alert, token) {
    const footer = this.#smsFooter(token);
    return `${alert.toSmsText(footer.length)}${footer}`;
  }

  /** The page the link opens is the client route /unsubscribe/:token (UC15). */
  #unsubscribeUrl(token) {
    return `${this.publicBaseUrl}/unsubscribe/${token}`;
  }

  #smsFooter(token) {
    return ` Unsubscribe: ${this.#unsubscribeUrl(token)}`;
  }

  #emailFooter(token) {
    return `\n\nTo stop these messages and withdraw your consent, open: ${this.#unsubscribeUrl(token)}`;
  }

  /**
   * Sends one message to every subscriber on each of their chosen channels and logs each
   * outcome.
   * @param {'ALERT'|'ACTIVITY'|'SUBSCRIPTION'} subjectType
   * @param {number} subjectId
   * @param {{channels: string[], phone?: string|null, email?: string|null}[]} subscribers
   * @param {(subscriber: object) => NotificationMessage} messageFor builds the message for one
   *   recipient, because each subscriber's unsubscribe link is different
   * @returns {Promise<DispatchSummary>}
   */
  async #dispatch(subjectType, subjectId, subscribers, messageFor) {
    const summary = { sent: 0, failed: 0 };
    for (const sub of subscribers) {
      const message = messageFor(sub);
      for (const type of sub.channels) {
        const channel = this.channels.get(type);
        const recipient = type === ChannelType.SMS ? sub.phone : sub.email;
        if (!channel || !recipient) continue;
        let status = DeliveryStatus.SENT;
        let errorMessage = null;
        try {
          await channel.send(recipient, message);
          summary.sent += 1;
        } catch (err) {
          status = DeliveryStatus.FAILED;
          errorMessage = err.message;
          summary.failed += 1;
        }
        await this.#log(new NotificationLog({
          subjectType, subjectId, channel: type, recipient, status, errorMessage,
        }));
      }
    }
    return summary;
  }

  /** Writes a log entry; a logging failure must not break the publish flow. */
  async #log(entry) {
    try {
      await this.logRepo.save(entry);
    } catch (err) {
      console.error('Could not write notification log:', err.message);
    }
  }
}
