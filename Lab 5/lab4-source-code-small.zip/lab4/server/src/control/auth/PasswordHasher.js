import bcrypt from 'bcryptjs';

/**
 * Hashes and checks official passwords with bcrypt (bcryptjs: pure JavaScript, so no native
 * build step on install). Plain-text passwords are never stored
 * (UC14 special requirement).
 */
export class PasswordHasher {
  /** @param {number} [rounds=12] bcrypt cost factor */
  constructor(rounds = 12) {
    this.rounds = rounds;
  }

  /**
   * @param {string} plain
   * @returns {Promise<string>} bcrypt hash
   */
  hash(plain) {
    return bcrypt.hash(plain, this.rounds);
  }

  /**
   * @param {string} plain
   * @param {string} hash
   * @returns {Promise<boolean>}
   */
  verify(plain, hash) {
    return bcrypt.compare(plain, hash);
  }
}
