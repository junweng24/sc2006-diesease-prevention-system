import jwt from 'jsonwebtoken';

/**
 * Issues and verifies signed session tokens (JWT) for officials (UC14, NFR-01).
 * Sessions are stateless: expiry is stored inside the token itself.
 */
export class TokenService {
  /**
   * @param {string} secret signing key from config
   * @param {number} expiresMinutes session length
   */
  constructor(secret, expiresMinutes) {
    this.secret = secret;
    this.expiresMinutes = expiresMinutes;
  }

  /**
   * @param {{officialId: number, role: string}} payload
   * @returns {string} signed token
   */
  issue(payload) {
    return jwt.sign(payload, this.secret, { expiresIn: `${this.expiresMinutes}m` });
  }

  /**
   * @param {string} token
   * @returns {{officialId: number, role: string}} the payload
   * @throws {Error} if the token is invalid or expired
   */
  verify(token) {
    const { officialId, role } = jwt.verify(token, this.secret);
    return { officialId, role };
  }
}
