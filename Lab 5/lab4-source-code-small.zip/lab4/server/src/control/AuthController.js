import { AccountLockedError, AuthError } from './errors.js';

/**
 * «control» Authenticates officials (UC14) and checks session tokens on every admin request
 * (NFR-01).
 */
export class AuthController {
  /**
   * @param {{officialRepo: import('../repository/OfficialRepository.js').OfficialRepository,
   *          hasher: import('./auth/PasswordHasher.js').PasswordHasher,
   *          tokens: import('./auth/TokenService.js').TokenService,
   *          maxFailedLogins: number, lockoutMinutes: number}} deps
   */
  constructor({ officialRepo, hasher, tokens, maxFailedLogins, lockoutMinutes }) {
    this.officialRepo = officialRepo;
    this.hasher = hasher;
    this.tokens = tokens;
    this.maxFailedLogins = maxFailedLogins;
    this.lockoutMinutes = lockoutMinutes;
  }

  /**
   * UC14: checks credentials and returns a session token.
   * The same "Invalid login" message is used for unknown usernames and wrong passwords so
   * attackers cannot discover which usernames exist.
   * @param {string} username
   * @param {string} password
   * @param {Date} now
   * @returns {Promise<{token: string, official: {id: number, username: string, role: string}}>}
   * @throws {AuthError} invalid credentials (UC14 2a)
   * @throws {AccountLockedError} too many failed attempts (UC14 2b)
   */
  async login(username, password, now) {
    if (!username || !password) throw new AuthError();
    const official = await this.officialRepo.findByUsername(username);
    if (!official) throw new AuthError();
    if (official.isLocked(now)) throw new AccountLockedError(this.lockoutMinutes);

    const ok = await this.hasher.verify(password, official.passwordHash);
    if (!ok) {
      official.recordFailedLogin(now, this.maxFailedLogins, this.lockoutMinutes);
      await this.officialRepo.updateLoginState(official);
      if (official.isLocked(now)) throw new AccountLockedError(this.lockoutMinutes);
      throw new AuthError();
    }

    official.resetFailedLogins();
    await this.officialRepo.updateLoginState(official);
    const token = this.tokens.issue({ officialId: official.id, role: official.role });
    return { token, official: { id: official.id, username: official.username, role: official.role } };
  }

  /**
   * UC18. Sessions are stateless JWTs, so logging out only requires the boundary to clear the
   * cookie. Kept as a method so a token blacklist can be added later without changing callers.
   * @param {string} _token
   */
  // eslint-disable-next-line no-unused-vars
  logout(_token) {
    // TODO(stretch): add the token to a short-lived blacklist until it expires.
  }

  /**
   * @param {string} token
   * @returns {{officialId: number, role: string}}
   * @throws {AuthError} missing, invalid or expired token
   */
  verifyToken(token) {
    if (!token) throw new AuthError('Please log in');
    try {
      return this.tokens.verify(token);
    } catch {
      throw new AuthError('Session expired, please log in again');
    }
  }
}
