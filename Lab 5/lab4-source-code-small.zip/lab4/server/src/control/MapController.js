import { GeoLocation } from '../entity/GeoLocation.js';
import { InputValidator } from './InputValidator.js';
import { ValidationError } from './errors.js';

/**
 * @typedef {object} MapData
 * @property {object[]} clusters dengue clusters (with riskLevel) from data.gov.sg
 * @property {import('../entity/Hotspot.js').Hotspot[]} hotspots official / verified hotspots
 * @property {Date|null} lastSyncedAt when the cluster data was last fetched successfully
 * @property {boolean} isStale true if live data was unavailable and the cache was used (UC1 2a)
 */

/**
 * «control» Façade that assembles everything the hotspot map needs (UC1) and resolves
 * addresses / coordinates through OneMap (UC2).
 */
export class MapController {
  /** Cluster data younger than this is served from the cache without calling data.gov.sg. */
  static CACHE_TTL_MS = 15 * 60 * 1000;

  /**
   * @param {{dataGov: import('../boundary/adapters/DataGovAdapter.js').DataGovAdapter,
   *          oneMap: import('../boundary/adapters/OneMapAdapter.js').OneMapAdapter,
   *          hotspotRepo: import('../repository/HotspotRepository.js').HotspotRepository,
   *          clusterCache: import('../repository/ClusterCacheRepository.js').ClusterCacheRepository}} deps
   */
  constructor({ dataGov, oneMap, hotspotRepo, clusterCache }) {
    this.dataGov = dataGov;
    this.oneMap = oneMap;
    this.hotspotRepo = hotspotRepo;
    this.clusterCache = clusterCache;
  }

  /**
   * Returns clusters and hotspots for the map, optionally filtered by disease type (UC1 step 3).
   * Falls back to the last cached snapshot if data.gov.sg cannot be reached (UC1 2a).
   * @param {{diseaseType?: string}} filter
   * @param {Date} now
   * @returns {Promise<MapData>}
   */
  async getMapData(filter, now) {
    const { clusters, syncedAt, isStale } = await this.#loadClusters(now);
    const showClusters = !filter.diseaseType || filter.diseaseType === 'DENGUE';
    const hotspots = await this.hotspotRepo.findActive(filter);
    return {
      clusters: showClusters
        ? clusters.map((c) => ({ ...c, riskLevel: c.riskLevel() }))
        : [],
      hotspots,
      lastSyncedAt: syncedAt,
      isStale,
    };
  }

  /**
   * UC2: turns a typed address or postal code into candidate locations.
   * @param {string} query
   * @returns {Promise<GeoLocation[]>} empty if not found
   */
  searchAddress(query) {
    return this.oneMap.search(query);
  }

  /**
   * UC2: turns GPS coordinates into an address. If OneMap cannot answer (no account set up, or
   * the service is down) the coordinates are returned without an address, so the user can
   * still submit a pin.
   * @param {number} lat
   * @param {number} lng
   * @returns {Promise<GeoLocation>}
   * @throws {ValidationError} coordinates missing or outside Singapore
   */
  async reverseGeocode(lat, lng) {
    const result = InputValidator.validateLocation({ latitude: lat, longitude: lng });
    if (!result.isValid) throw new ValidationError(result.errors);
    try {
      return await this.oneMap.reverseGeocode(lat, lng);
    } catch (err) {
      console.warn('Reverse geocode unavailable:', err.message);
      return new GeoLocation({ latitude: lat, longitude: lng });
    }
  }

  /**
   * Uses a fresh cache if available; otherwise fetches live data and refreshes the cache;
   * if that fails, falls back to whatever is cached.
   * @param {Date} now
   */
  async #loadClusters(now) {
    const cached = await this.clusterCache.getLatestSnapshot();
    if (cached && now - new Date(cached.syncedAt) < MapController.CACHE_TTL_MS) {
      return { clusters: cached.clusters, syncedAt: cached.syncedAt, isStale: false };
    }
    try {
      const clusters = await this.dataGov.fetchDengueClusters();
      await this.clusterCache.saveSnapshot(clusters, now);
      return { clusters, syncedAt: now, isStale: false };
    } catch (err) {
      console.warn('data.gov.sg unavailable, using cached clusters:', err.message);
      return {
        clusters: cached?.clusters ?? [],
        syncedAt: cached?.syncedAt ?? null,
        isStale: true,
      };
    }
  }
}
