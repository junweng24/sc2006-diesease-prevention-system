/**
 * Application errors thrown by control classes. The HTTP boundary (errorHandler middleware)
 * turns them into status codes, so control classes never deal with HTTP directly.
 */
export class AppError extends Error {
  /**
   * @param {string} message user-facing message
   * @param {number} status HTTP status code to use
   * @param {Record<string, string>} [details] per-field messages
   */
  constructor(message, status, details = undefined) {
    super(message);
    this.name = this.constructor.name;
    this.status = status;
    this.details = details;
  }
}

/** Input failed validation (NFR-04): nothing was stored. */
export class ValidationError extends AppError {
  /** @param {Record<string, string>} details field → message */
  constructor(details, message = 'Please correct the highlighted fields') {
    super(message, 422, details);
  }
}

export class NotFoundError extends AppError {
  constructor(message = 'Record not found') {
    super(message, 404);
  }
}

/** The request clashes with current state (duplicate, quota full, stale version...). */
export class ConflictError extends AppError {
  constructor(message) {
    super(message, 409);
  }
}

export class AuthError extends AppError {
  constructor(message = 'Invalid login') {
    super(message, 401);
  }
}

/** Too many failed logins (UC14 2b). The lock expires by itself after `lockoutMinutes`. */
export class AccountLockedError extends AppError {
  /** @param {number} lockoutMinutes */
  constructor(lockoutMinutes) {
    super(`Account locked after too many failed attempts. Please try again in ${lockoutMinutes} minutes.`, 423);
  }
}

/** An external system we depend on is down and there is no cached copy to fall back on. */
export class ServiceUnavailableError extends AppError {
  constructor(message = 'This service is temporarily unavailable. Please try again later.') {
    super(message, 503);
  }
}

export class ForbiddenError extends AppError {
  constructor(message = 'You do not have permission to do this') {
    super(message, 403);
  }
}
