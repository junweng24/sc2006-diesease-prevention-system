import { randomUUID } from 'node:crypto';
import { mkdir, writeFile } from 'node:fs/promises';
import path from 'node:path';

import { ContactDetails } from '../entity/ContactDetails.js';
import { GeoLocation } from '../entity/GeoLocation.js';
import { Hotspot } from '../entity/Hotspot.js';
import { HotspotReport } from '../entity/HotspotReport.js';
import { ReportStatus } from '../entity/enums.js';
import { InputValidator } from './InputValidator.js';
import { PhotoSanitizer } from './PhotoSanitizer.js';
import { ConflictError, NotFoundError, ValidationError } from './errors.js';

/**
 * «control» Handles public hotspot reports: submission by residents (UC3–UC5) and review by
 * officials (UC8).
 */
export class HotspotReportController {
  /**
   * @param {{db: import('../repository/Database.js').Database,
   *          reportRepo: import('../repository/HotspotReportRepository.js').HotspotReportRepository,
   *          hotspotRepo: import('../repository/HotspotRepository.js').HotspotRepository,
   *          uploadDir: string}} deps
   */
  constructor({ db, reportRepo, hotspotRepo, uploadDir }) {
    this.db = db;
    this.reportRepo = reportRepo;
    this.hotspotRepo = hotspotRepo;
    this.uploadDir = uploadDir;
  }

  /**
   * UC3: validates and stores a new report with status UNVERIFIED.
   * @param {{location: object, siteType: string, description: string,
   *          contact?: {name?: string, phone?: string, email?: string}}} input
   * @param {{mimeType: string, sizeBytes: number, buffer: Buffer}|null} photo optional (UC4)
   * @param {Date} now
   * @returns {Promise<string>} the reference ID shown to the user (UC3 step 7)
   * @throws {ValidationError} if any field is invalid; nothing is stored (NFR-04)
   */
  async submitReport(input, photo, now) {
    const result = InputValidator.validateReportInput(input);
    if (photo) result.merge(InputValidator.validatePhoto(photo));
    if (!result.isValid) throw new ValidationError(result.errors);

    const photoPath = photo ? await this.#storePhoto(photo) : null;
    const contact = input.contact ? new ContactDetails(input.contact) : null;
    const report = new HotspotReport({
      referenceId: HotspotReport.generateReferenceId(now),
      location: new GeoLocation(input.location),
      siteType: input.siteType,
      description: input.description.trim(),
      photoPath,
      contact: contact && !contact.isEmpty() ? contact : null,
      submittedAt: now,
    });
    await this.reportRepo.save(report);
    return report.referenceId;
  }

  /**
   * UC8 step 1: lists reports for the officials' table.
   * @param {{status?: string}} filter
   * @returns {Promise<HotspotReport[]>}
   */
  listReports(filter) {
    return this.reportRepo.findByStatus(filter);
  }

  /**
   * UC8 step 2.
   * @param {string} referenceId
   * @returns {Promise<HotspotReport>}
   * @throws {NotFoundError}
   */
  async getReport(referenceId) {
    const report = await this.reportRepo.findById(referenceId);
    if (!report) throw new NotFoundError('Report not found');
    return report;
  }

  /**
   * UC8 steps 3–4: changes a report's status. Verifying a report also puts a hotspot on the
   * public map. Both changes are saved in one transaction.
   * @param {string} referenceId
   * @param {string} newStatus a {@link ReportStatus} value
   * @param {number} officialId reviewer
   * @param {number} expectedVersion the version the official loaded (UC8 4a)
   * @param {Date} now
   * @returns {Promise<HotspotReport>} the updated report
   * @throws {NotFoundError} unknown reference ID
   * @throws {ConflictError} another official changed the report first
   * @throws {ValidationError} the status change is not allowed
   */
  async reviewReport(referenceId, newStatus, officialId, expectedVersion, now) {
    const report = await this.getReport(referenceId);
    if (report.version !== expectedVersion) {
      throw new ConflictError('This report was updated by someone else. Reloaded latest version.');
    }
    if (!report.canTransitionTo(newStatus)) {
      throw new ValidationError(
        { status: `Cannot change status from ${report.status} to ${newStatus}` });
    }
    report.transitionTo(newStatus, officialId, now);

    await this.db.transaction(async (client) => {
      const saved = await this.reportRepo.updateStatusWithVersion(report, expectedVersion, client);
      if (!saved) {
        throw new ConflictError('This report was updated by someone else. Reloaded latest version.');
      }
      if (newStatus === ReportStatus.VERIFIED_ACTIVE) {
        await this.hotspotRepo.save(Hotspot.fromVerifiedReport(report, officialId), client);
      }
      if (newStatus === ReportStatus.RESOLVED) {
        // The site has been cleared, so its hotspot leaves the public map (FR-21).
        const linked = await this.hotspotRepo.findActiveBySourceReport(referenceId, client);
        for (const hotspot of linked) {
          hotspot.remove();
          await this.hotspotRepo.save(hotspot, client);
        }
      }
    });
    return report;
  }

  /**
   * UC8 step 2: where the report's photo is stored, for streaming to officials only.
   * @param {string} referenceId
   * @returns {Promise<string>} absolute file path
   * @throws {NotFoundError} unknown report, or the report has no photo
   */
  async getPhotoFile(referenceId) {
    const report = await this.getReport(referenceId);
    if (!report.photoPath) throw new NotFoundError('This report has no photo');
    return path.resolve(this.uploadDir, path.basename(report.photoPath));
  }

  /**
   * Writes the validated photo to the upload folder under a random file name, after removing
   * EXIF data such as the GPS position (UC4, PDPA). The browser has already resized it.
   * @param {{buffer: Buffer}} photo
   * @returns {Promise<string>} relative path stored in the database
   */
  async #storePhoto(photo) {
    await mkdir(this.uploadDir, { recursive: true });
    const fileName = `${randomUUID()}.jpg`;
    await writeFile(path.join(this.uploadDir, fileName), PhotoSanitizer.stripMetadata(photo.buffer));
    return fileName;
  }
}
