import {
  BreedingSiteType, ChannelType, Severity,
} from '../entity/enums.js';
import { GeoLocation } from '../entity/GeoLocation.js';

/**
 * Collects field errors produced by {@link InputValidator}.
 */
export class ValidationResult {
  constructor() {
    /** @type {Record<string, string>} field name → error message */
    this.errors = {};
  }

  /** @returns {boolean} true if no errors were recorded */
  get isValid() {
    return Object.keys(this.errors).length === 0;
  }

  /**
   * Records an error for `field` (the first error for a field is kept).
   * @param {string} field
   * @param {string} message
   * @returns {ValidationResult} this, for chaining
   */
  add(field, message) {
    if (!this.errors[field]) this.errors[field] = message;
    return this;
  }

  /**
   * Copies all errors from another result into this one.
   * @param {ValidationResult} other
   * @returns {ValidationResult} this
   */
  merge(other) {
    Object.entries(other.errors).forEach(([f, m]) => this.add(f, m));
    return this;
  }
}

/** Largest accepted photo, exclusive: "JPEG format under 5MB" (UC4). */
export const MAX_PHOTO_BYTES = 5 * 1024 * 1024;
export const MAX_DESCRIPTION_LENGTH = 1000;
export const MAX_TITLE_LENGTH = 120;
export const MAX_ALERT_BODY_LENGTH = 2000;
export const MAX_HEADCOUNT_QUOTA = 500;

const EMAIL_PATTERN = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;

const isBlank = (v) => v === undefined || v === null || String(v).trim() === '';

/**
 * A required text field must really be text. JSON bodies can carry numbers or booleans, and the
 * controllers call `.trim()` on these fields (defect found by black-box tests BB-38, 45, 51, 52,
 * 70, 71).
 */
const isMissingText = (v) => typeof v !== 'string' || v.trim() === '';

/**
 * Only numbers and numeric strings count as a number: `Number(true)` is 1 (BB-63).
 * @returns {number} the value as a number, or NaN if it is any other type
 */
const toNumber = (v) => (typeof v === 'number' || typeof v === 'string' ? Number(v) : NaN);

/**
 * «control» Central place for all input validation rules, used by every control class.
 * Validation always runs on the server, even if the browser has already checked (NFR-04).
 *
 * All methods are static and pure (no I/O), which makes this class a good candidate for
 * black-box testing in Lab 4.
 */
export class InputValidator {
  /**
   * Singapore numbers have 8 digits. Mobiles start with 8 or 9; landlines start with 6.
   * An optional "+65" / "65" prefix and spaces are allowed.
   * @param {string} phone
   * @param {{mobileOnly?: boolean}} [options] set mobileOnly for SMS recipients
   * @returns {boolean}
   */
  static isValidSingaporePhone(phone, { mobileOnly = false } = {}) {
    if (typeof phone !== 'string') return false;
    const digits = phone.replace(/\s+/g, '').replace(/^\+?65(?=\d{8}$)/, '');
    const pattern = mobileOnly ? /^[89]\d{7}$/ : /^[689]\d{7}$/;
    return pattern.test(digits);
  }

  /**
   * @param {string} email
   * @returns {boolean}
   */
  static isValidEmail(email) {
    return typeof email === 'string' && email.length <= 254 && EMAIL_PATTERN.test(email.trim());
  }

  /**
   * UC4: only JPEG files strictly smaller than 5 MB are accepted.
   * @param {{mimeType: string, sizeBytes: number}} file
   * @returns {ValidationResult}
   */
  static validatePhoto(file) {
    const r = new ValidationResult();
    if (!file) return r;
    if (file.mimeType !== 'image/jpeg') r.add('photo', 'File must be JPEG format under 5MB');
    else if (!(file.sizeBytes > 0) || file.sizeBytes >= MAX_PHOTO_BYTES) {
      r.add('photo', 'File must be JPEG format under 5MB');
    }
    return r;
  }

  /**
   * @param {{latitude?: number, longitude?: number}} location
   * @param {string} [field='location']
   * @returns {ValidationResult}
   */
  static validateLocation(location, field = 'location') {
    const r = new ValidationResult();
    if (!location || isBlank(location.latitude) || isBlank(location.longitude)) {
      return r.add(field, 'Please select a location');
    }
    if (!new GeoLocation(location).isWithinSingapore()) {
      r.add(field, 'Location must be in Singapore');
    }
    return r;
  }

  /**
   * Optional contact block for a hotspot report (UC5): each field is optional, but any field
   * that is filled in must be valid.
   * @param {{name?: string, phone?: string, email?: string}} [contact]
   * @returns {ValidationResult}
   */
  static validateOptionalContact(contact) {
    const r = new ValidationResult();
    if (!contact) return r;
    if (!isBlank(contact.name) && String(contact.name).length > 100) {
      r.add('contact.name', 'Name must be at most 100 characters');
    }
    if (!isBlank(contact.phone) && !InputValidator.isValidSingaporePhone(contact.phone)) {
      r.add('contact.phone', 'Enter a valid 8-digit Singapore number');
    }
    if (!isBlank(contact.email) && !InputValidator.isValidEmail(contact.email)) {
      r.add('contact.email', 'Enter a valid email address');
    }
    return r;
  }

  /**
   * UC3: location, site type and description are required; photo and contact are optional.
   * @param {object} input
   * @returns {ValidationResult}
   */
  static validateReportInput(input) {
    const r = new ValidationResult();
    r.merge(InputValidator.validateLocation(input?.location));
    if (!Object.values(BreedingSiteType).includes(input?.siteType)) {
      r.add('siteType', 'Select the type of breeding site');
    }
    if (isMissingText(input?.description)) r.add('description', 'Description is required');
    else if (String(input.description).length > MAX_DESCRIPTION_LENGTH) {
      r.add('description', `Description must be at most ${MAX_DESCRIPTION_LENGTH} characters`);
    }
    r.merge(InputValidator.validateOptionalContact(input?.contact));
    return r;
  }

  /**
   * UC6: name, phone, email and privacy consent are all required.
   * @param {object} input
   * @returns {ValidationResult}
   */
  static validateRegistrationInput(input) {
    const r = new ValidationResult();
    if (isMissingText(input?.name)) r.add('name', 'Name is required');
    else if (String(input.name).length > 100) r.add('name', 'Name must be at most 100 characters');
    if (!InputValidator.isValidSingaporePhone(input?.phone)) {
      r.add('phone', 'Enter a valid 8-digit Singapore number');
    }
    if (!InputValidator.isValidEmail(input?.email)) r.add('email', 'Enter a valid email address');
    if (input?.consentGiven !== true) r.add('consentGiven', 'Please agree to the privacy terms');
    return r;
  }

  /**
   * UC9 / UC11: event must be in the future; quota must be a whole number between 1 and
   * {@link MAX_HEADCOUNT_QUOTA} and not below the number already registered.
   * @param {object} input
   * @param {Date} now
   * @param {number} [registeredCount=0] current registrations (when editing)
   * @returns {ValidationResult}
   */
  static validateActivityInput(input, now, registeredCount = 0) {
    const r = new ValidationResult();
    if (isMissingText(input?.title)) r.add('title', 'Title is required');
    else if (String(input.title).length > MAX_TITLE_LENGTH) {
      r.add('title', `Title must be at most ${MAX_TITLE_LENGTH} characters`);
    }
    if (isMissingText(input?.targetArea)) r.add('targetArea', 'Target area is required');

    const when = new Date(input?.eventDateTime);
    if (isBlank(input?.eventDateTime) || Number.isNaN(when.getTime())) {
      r.add('eventDateTime', 'Enter a valid date and time');
    } else if (when <= now) {
      r.add('eventDateTime', 'Please enter valid future date');
    }

    const quota = toNumber(input?.headcountQuota);
    if (!Number.isInteger(quota) || quota < 1 || quota > MAX_HEADCOUNT_QUOTA) {
      r.add('headcountQuota', `Headcount must be a whole number from 1 to ${MAX_HEADCOUNT_QUOTA}`);
    } else if (quota < registeredCount) {
      r.add('headcountQuota', `Headcount cannot be below the ${registeredCount} already registered`);
    }

    if (!isBlank(input?.contactPhone) && !InputValidator.isValidSingaporePhone(input.contactPhone)) {
      r.add('contactPhone', 'Enter a valid 8-digit Singapore number');
    }
    return r;
  }

  /**
   * UC7: title, body, category, severity and target region are required.
   * @param {object} input
   * @returns {ValidationResult}
   */
  static validateAlertInput(input) {
    const r = new ValidationResult();
    if (isMissingText(input?.title)) r.add('title', 'Title is required');
    else if (String(input.title).length > MAX_TITLE_LENGTH) {
      r.add('title', `Title must be at most ${MAX_TITLE_LENGTH} characters`);
    }
    if (isMissingText(input?.body)) r.add('body', 'Message is required');
    else if (String(input.body).length > MAX_ALERT_BODY_LENGTH) {
      r.add('body', `Message must be at most ${MAX_ALERT_BODY_LENGTH} characters`);
    }
    if (isBlank(input?.category)) r.add('category', 'Category is required');
    if (!Object.values(Severity).includes(input?.severity)) r.add('severity', 'Select a severity');
    if (isBlank(input?.targetRegion)) r.add('targetRegion', 'Target region is required');
    return r;
  }

  /**
   * UC15: at least one channel; each chosen channel needs a matching valid contact
   * (SMS → mobile number, EMAIL → email); consent is required.
   * @param {object} input
   * @returns {ValidationResult}
   */
  static validateSubscriptionInput(input) {
    const r = new ValidationResult();
    const channels = Array.isArray(input?.channels) ? input.channels : [];
    const known = Object.values(ChannelType);
    if (channels.length === 0 || channels.some((c) => !known.includes(c))) {
      r.add('channels', 'Choose SMS and/or email');
    }
    if (channels.includes(ChannelType.SMS)
      && !InputValidator.isValidSingaporePhone(input?.phone, { mobileOnly: true })) {
      r.add('phone', 'Enter a valid Singapore mobile number for SMS alerts');
    }
    if (channels.includes(ChannelType.EMAIL) && !InputValidator.isValidEmail(input?.email)) {
      r.add('email', 'Enter a valid email address for email alerts');
    }
    if (isBlank(input?.region)) r.add('region', 'Select a region');
    if (input?.consentGiven !== true) r.add('consentGiven', 'Please agree to the privacy terms');
    return r;
  }

  /**
   * UC17: disease type and location are required; case count is a non-negative integer.
   * @param {object} input
   * @param {string[]} knownDiseaseTypes codes from the disease_types table (NFR-08)
   * @returns {ValidationResult}
   */
  static validateHotspotInput(input, knownDiseaseTypes) {
    const r = new ValidationResult();
    if (!knownDiseaseTypes.includes(input?.diseaseType)) r.add('diseaseType', 'Select a disease type');
    r.merge(InputValidator.validateLocation(input?.location));
    const count = toNumber(input?.caseCount ?? 0);
    if (!Number.isInteger(count) || count < 0) r.add('caseCount', 'Case count must be 0 or more');
    return r;
  }
}
