/**
 * JPEG segments that only carry metadata: APP1 (EXIF incl. GPS position, XMP), APP13 (IPTC)
 * and COM (comments). Dropping them never changes the picture itself.
 */
const METADATA_MARKERS = new Set([0xe1, 0xed, 0xfe]);
const START_OF_SCAN = 0xda;

/**
 * «control» Removes metadata from uploaded photos before they are stored (UC4 special
 * requirement, PDPA). A phone photo's EXIF block usually contains the exact GPS position and
 * the device model, which officials do not need and which should not be kept.
 *
 * Pure function on a Buffer (no I/O), so it is easy to unit-test in Lab 4.
 */
export class PhotoSanitizer {
  /**
   * @param {Buffer} jpeg file contents
   * @returns {Buffer} the same image without metadata segments. If the file is not a JPEG
   *   this class understands, it is returned unchanged (it was already validated as JPEG).
   */
  static stripMetadata(jpeg) {
    if (jpeg.length < 4 || jpeg[0] !== 0xff || jpeg[1] !== 0xd8) return jpeg;
    const kept = [jpeg.subarray(0, 2)]; // SOI marker
    let i = 2;
    while (i + 4 <= jpeg.length) {
      if (jpeg[i] !== 0xff) return jpeg;
      const marker = jpeg[i + 1];
      // From the start-of-scan marker on, the rest of the file is compressed image data.
      if (marker === START_OF_SCAN) {
        kept.push(jpeg.subarray(i));
        return Buffer.concat(kept);
      }
      const end = i + 2 + jpeg.readUInt16BE(i + 2);
      if (end > jpeg.length) return jpeg;
      if (!METADATA_MARKERS.has(marker)) kept.push(jpeg.subarray(i, end));
      i = end;
    }
    return jpeg;
  }
}
