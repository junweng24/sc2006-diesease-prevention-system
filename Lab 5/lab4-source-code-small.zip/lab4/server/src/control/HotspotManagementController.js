import { DengueCluster } from '../entity/DengueCluster.js';
import { GeoLocation } from '../entity/GeoLocation.js';
import { Hotspot } from '../entity/Hotspot.js';
import { HotspotSource, RiskLevel } from '../entity/enums.js';
import { InputValidator } from './InputValidator.js';
import { NotFoundError, ValidationError } from './errors.js';

/**
 * «control» Lets officials view, add and remove hotspots directly (UC17, FR-19..21).
 */
export class HotspotManagementController {
  /**
   * @param {{hotspotRepo: import('../repository/HotspotRepository.js').HotspotRepository}} deps
   */
  constructor({ hotspotRepo }) {
    this.hotspotRepo = hotspotRepo;
  }

  /**
   * @param {{diseaseType?: string}} [filter]
   * @returns {Promise<Hotspot[]>} active hotspots (FR-19)
   */
  listHotspots(filter = {}) {
    return this.hotspotRepo.findActive(filter);
  }

  /** @returns {Promise<{code: string, label: string}[]>} choices for the add form (NFR-08) */
  listDiseaseTypes() {
    return this.hotspotRepo.findDiseaseTypes();
  }

  /**
   * UC17 steps 2–4: adds a hotspot created by an official (FR-20).
   * @param {{diseaseType: string, location: object, caseCount?: number}} input
   * @param {number} officialId
   * @returns {Promise<Hotspot>}
   * @throws {ValidationError}
   */
  async addHotspot(input, officialId) {
    const diseaseTypes = await this.hotspotRepo.findDiseaseTypeCodes();
    const result = InputValidator.validateHotspotInput(input, diseaseTypes);
    if (!result.isValid) throw new ValidationError(result.errors);

    const caseCount = Number(input.caseCount ?? 0);
    const hotspot = new Hotspot({
      diseaseType: input.diseaseType,
      location: new GeoLocation(input.location),
      caseCount,
      riskLevel: caseCount >= DengueCluster.HIGH_RISK_THRESHOLD ? RiskLevel.HIGH : RiskLevel.LOW,
      source: HotspotSource.OFFICIAL,
      createdBy: officialId,
    });
    return this.hotspotRepo.save(hotspot);
  }

  /**
   * UC17 alternative 2a: removes a hotspot from the public map (soft delete, FR-21).
   * @param {number} hotspotId
   * @returns {Promise<void>}
   * @throws {NotFoundError}
   */
  async removeHotspot(hotspotId) {
    const hotspot = await this.hotspotRepo.findById(hotspotId);
    if (!hotspot || !hotspot.isActive) throw new NotFoundError('Hotspot not found');
    hotspot.remove();
    await this.hotspotRepo.save(hotspot);
  }
}
