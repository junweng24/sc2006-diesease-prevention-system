import { AlertSubscription } from '../entity/AlertSubscription.js';
import { InputValidator } from './InputValidator.js';
import { ConflictError, NotFoundError, ValidationError } from './errors.js';

/**
 * «control» Lets the public opt in to SMS / email alerts and withdraw that consent (UC15).
 */
export class SubscriptionController {
  /**
   * @param {{subscriptionRepo: import('../repository/SubscriptionRepository.js').SubscriptionRepository,
   *          notificationService: import('./NotificationService.js').NotificationService}} deps
   */
  constructor({ subscriptionRepo, notificationService }) {
    this.subscriptionRepo = subscriptionRepo;
    this.notificationService = notificationService;
  }

  /**
   * UC15 steps 2–5.
   * @param {{email?: string, phone?: string, channels: string[], region: string,
   *          wantsVolunteerNews?: boolean, consentGiven: boolean}} input
   * @returns {Promise<AlertSubscription>}
   * @throws {ValidationError} invalid contact details (UC15 2a)
   * @throws {ConflictError} email or phone already subscribed
   */
  async subscribe(input) {
    const result = InputValidator.validateSubscriptionInput(input);
    if (!result.isValid) throw new ValidationError(result.errors);

    const email = input.channels.includes('EMAIL') ? input.email.trim() : null;
    const phone = input.channels.includes('SMS') ? input.phone.replace(/\s+/g, '') : null;
    if (await this.subscriptionRepo.existsByContact(email, phone)) {
      throw new ConflictError('This email or phone number is already subscribed');
    }

    const subscription = await this.subscriptionRepo.save(new AlertSubscription({
      email,
      phone,
      channels: input.channels,
      region: input.region,
      wantsVolunteerNews: Boolean(input.wantsVolunteerNews),
      consentGiven: true,
    }));
    await this.notificationService.sendSubscriptionConfirmation(subscription);
    return subscription;
  }

  /**
   * UC15 unsubscribe link, read only: says what the link can still do, so that opening it (which
   * mail scanners do automatically) never withdraws anything by itself.
   * @param {string} token
   * @returns {Promise<{alreadyUnsubscribed: boolean}>}
   * @throws {NotFoundError} the link is invalid
   */
  async getUnsubscribeStatus(token) {
    const subscription = await this.subscriptionRepo.findByUnsubscribeToken(token);
    if (!subscription) throw new NotFoundError('This unsubscribe link is not valid');
    return { alreadyUnsubscribed: !subscription.consentGiven };
  }

  /**
   * UC15 unsubscribe: withdraws the subscriber's consent (PDPA) on all channels and erases their
   * contact details, so they get no more notifications. No message is sent to confirm it.
   * @param {string} token
   * @param {Date} now
   * @returns {Promise<void>}
   * @throws {NotFoundError} the link is invalid
   * @throws {ConflictError} the link was already used
   */
  async unsubscribe(token, now) {
    await this.getUnsubscribeStatus(token);
    const withdrawn = await this.subscriptionRepo.withdrawConsent(token, now);
    if (!withdrawn) throw new ConflictError('This unsubscribe link has already been used');
  }
}
