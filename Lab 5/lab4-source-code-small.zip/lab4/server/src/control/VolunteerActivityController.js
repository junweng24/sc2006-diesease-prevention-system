import { ContactDetails } from '../entity/ContactDetails.js';
import { VolunteerActivity } from '../entity/VolunteerActivity.js';
import { InputValidator } from './InputValidator.js';
import { NotFoundError, ValidationError } from './errors.js';

/**
 * @typedef {{notifyActivityPublished(a: VolunteerActivity): Promise<{sent: number, failed: number}>,
 *            notifyActivityChanged?(a: VolunteerActivity,
 *              roster: import('../entity/VolunteerRegistration.js').VolunteerRegistration[]):
 *              Promise<{sent: number, failed: number}>}} ActivityListener
 * @typedef {{activity: VolunteerActivity, registeredCount: number, headcountQuota: number,
 *            remainingSlots: number, occupancyPercent: number}} ActivityStatusSummary
 */

/**
 * «control» Officials' management of volunteer activities: create (UC9), check status (UC10)
 * and edit (UC11). Observer subject for "activity published" (FR-25).
 */
export class VolunteerActivityController {
  /**
   * @param {{activityRepo: import('../repository/VolunteerActivityRepository.js').VolunteerActivityRepository,
   *          registrationRepo: import('../repository/VolunteerRegistrationRepository.js').VolunteerRegistrationRepository,
   *          listeners?: ActivityListener[]}} deps
   */
  constructor({ activityRepo, registrationRepo, listeners = [] }) {
    this.activityRepo = activityRepo;
    this.registrationRepo = registrationRepo;
    this.listeners = listeners;
  }

  /**
   * UC9 step 1 / UC10 1a: lists activities, optionally filtered by status.
   * @param {{status?: string}} filter
   * @param {Date} now
   * @returns {Promise<VolunteerActivity[]>}
   */
  async listActivities(filter, now) {
    const all = await this.activityRepo.findAll();
    all.forEach((a) => a.refreshStatus(now));
    return filter.status ? all.filter((a) => a.status === filter.status) : all;
  }

  /**
   * UC9 steps 3–6: validates and stores a new activity, then notifies subscribers (FR-25).
   * @param {object} input title, targetArea, eventDateTime, headcountQuota, priority,
   *   description, contactName, contactPhone
   * @param {number} officialId
   * @param {Date} now
   * @returns {Promise<VolunteerActivity>}
   * @throws {ValidationError} past date or invalid headcount (UC9 3a)
   */
  async createActivity(input, officialId, now) {
    const result = InputValidator.validateActivityInput(input, now);
    if (!result.isValid) throw new ValidationError(result.errors);

    const activity = await this.activityRepo.save(new VolunteerActivity({
      title: input.title.trim(),
      targetArea: input.targetArea.trim(),
      eventDateTime: new Date(input.eventDateTime),
      headcountQuota: Number(input.headcountQuota),
      priority: input.priority ?? 'NORMAL',
      description: input.description ?? '',
      contactPerson: new ContactDetails({ name: input.contactName, phone: input.contactPhone }),
      createdBy: officialId,
    }));

    for (const listener of this.listeners) {
      try {
        await listener.notifyActivityPublished(activity);
      } catch (err) {
        console.error('Activity listener failed:', err.message);
      }
    }
    return activity;
  }

  /**
   * UC11: updates an activity. The quota cannot drop below the number already registered
   * (UC11 2a). If the date or venue changes, registered volunteers are told (FR-25).
   * @param {number} id
   * @param {object} changes any subset of the fields accepted by {@link createActivity}
   * @param {Date} now
   * @returns {Promise<VolunteerActivity>}
   * @throws {NotFoundError}
   * @throws {ValidationError}
   */
  async editActivity(id, changes, now) {
    const activity = await this.#getActivity(id);
    const merged = {
      title: activity.title,
      targetArea: activity.targetArea,
      eventDateTime: activity.eventDateTime,
      headcountQuota: activity.headcountQuota,
      priority: activity.priority,
      description: activity.description,
      contactName: activity.contactPerson?.name,
      contactPhone: activity.contactPerson?.phone,
      ...changes,
    };
    const result = InputValidator.validateActivityInput(merged, now, activity.registeredCount);
    if (!result.isValid) throw new ValidationError(result.errors);

    const before = { when: activity.eventDateTime.getTime(), where: activity.targetArea };

    Object.assign(activity, {
      title: merged.title.trim(),
      targetArea: merged.targetArea.trim(),
      eventDateTime: new Date(merged.eventDateTime),
      headcountQuota: Number(merged.headcountQuota),
      priority: merged.priority,
      description: merged.description,
      contactPerson: new ContactDetails({ name: merged.contactName, phone: merged.contactPhone }),
    });
    activity.refreshStatus(now);
    const saved = await this.activityRepo.save(activity);

    const moved = before.when !== saved.eventDateTime.getTime() || before.where !== saved.targetArea;
    if (moved && saved.registeredCount > 0) {
      const roster = await this.registrationRepo.findByActivity(id);
      for (const listener of this.listeners) {
        try {
          await listener.notifyActivityChanged?.(saved, roster);
        } catch (err) {
          console.error('Activity listener failed:', err.message);
        }
      }
    }
    return saved;
  }

  /**
   * UC10 steps 1–2: occupancy summary for the progress bar.
   * @param {number} id
   * @param {Date} now
   * @returns {Promise<ActivityStatusSummary>}
   */
  async getActivityStatus(id, now) {
    const activity = await this.#getActivity(id);
    activity.refreshStatus(now);
    return {
      activity,
      registeredCount: activity.registeredCount,
      headcountQuota: activity.headcountQuota,
      remainingSlots: activity.remainingSlots(),
      occupancyPercent: Math.round((activity.registeredCount / activity.headcountQuota) * 100),
    };
  }

  /**
   * UC10 step 3: roster with contact details. Officials only (NFR-02).
   * @param {number} id
   * @returns {Promise<import('../entity/VolunteerRegistration.js').VolunteerRegistration[]>}
   */
  async getRoster(id) {
    await this.#getActivity(id);
    return this.registrationRepo.findByActivity(id);
  }

  /** @throws {NotFoundError} "Activity record unavailable" (UC10 exception 1a) */
  async #getActivity(id) {
    const activity = await this.activityRepo.findById(id);
    if (!activity) throw new NotFoundError('Activity record unavailable');
    return activity;
  }
}
