import { ContactDetails } from '../entity/ContactDetails.js';
import { ActivityStatus } from '../entity/enums.js';
import { VolunteerRegistration } from '../entity/VolunteerRegistration.js';
import { InputValidator } from './InputValidator.js';
import { ConflictError, NotFoundError, ValidationError } from './errors.js';

/**
 * «control» Public registration for volunteer activities (UC6).
 * Guarantees no overbooking and no duplicate registrations (NFR-03) by doing the checks and
 * the insert inside one database transaction with the activity row locked.
 */
export class VolunteerEnrollmentController {
  /**
   * @param {{db: import('../repository/Database.js').Database,
   *          activityRepo: import('../repository/VolunteerActivityRepository.js').VolunteerActivityRepository,
   *          registrationRepo: import('../repository/VolunteerRegistrationRepository.js').VolunteerRegistrationRepository}} deps
   */
  constructor({ db, activityRepo, registrationRepo }) {
    this.db = db;
    this.activityRepo = activityRepo;
    this.registrationRepo = registrationRepo;
  }

  /**
   * UC6 step 1: upcoming activities with their remaining slots.
   * @param {Date} now
   * @returns {Promise<import('../entity/VolunteerActivity.js').VolunteerActivity[]>}
   */
  async listOpenActivities(now) {
    const activities = await this.activityRepo.findUpcoming(now);
    activities.forEach((a) => a.refreshStatus(now));
    return activities;
  }

  /**
   * UC6 steps 2–5: registers a member of the public for an activity.
   * @param {number} activityId
   * @param {{name: string, phone: string, email: string, consentGiven: boolean}} input
   * @param {Date} now
   * @returns {Promise<{registration: VolunteerRegistration,
   *                    activity: import('../entity/VolunteerActivity.js').VolunteerActivity}>}
   * @throws {ValidationError} invalid details (UC6 3a)
   * @throws {NotFoundError} activity does not exist
   * @throws {ConflictError} quota full (UC6 2a), activity closed, or already registered
   */
  async register(activityId, input, now) {
    const result = InputValidator.validateRegistrationInput(input);
    if (!result.isValid) throw new ValidationError(result.errors);

    const contact = new ContactDetails({
      name: input.name.trim(),
      phone: input.phone.replace(/\s+/g, ''),
      email: input.email.trim().toLowerCase(),
    });

    return this.db.transaction(async (client) => {
      const activity = await this.activityRepo.findByIdForUpdate(activityId, client);
      if (!activity) throw new NotFoundError('Activity not found');

      if (!activity.canAcceptRegistration(now)) {
        throw new ConflictError(activity.status === ActivityStatus.FULL
          ? 'Activity quota full'
          : 'This activity is no longer open for registration');
      }
      if (await this.registrationRepo.existsByActivityAndContact(
        activityId, contact.email, contact.phone, client)) {
        throw new ConflictError('You have already registered for this activity');
      }

      const registration = await this.registrationRepo.save(
        new VolunteerRegistration({ activityId, contact, consentGiven: true, registeredAt: now }),
        client);
      activity.registeredCount += 1;
      activity.refreshStatus(now);
      await this.activityRepo.save(activity, client);
      return { registration, activity };
    });
  }
}
