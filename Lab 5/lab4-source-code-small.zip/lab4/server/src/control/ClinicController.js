import { GeoLocation } from '../entity/GeoLocation.js';
import { InputValidator } from './InputValidator.js';
import { ServiceUnavailableError, ValidationError } from './errors.js';

/**
 * @typedef {object} NearbyClinics
 * @property {{code: string, name: string, phone: string|null, location: GeoLocation,
 *             distanceKm: number}[]} clinics nearest first
 * @property {number} radiusKm search radius that was finally used
 * @property {Date|null} updatedAt when the clinic list was last downloaded
 * @property {boolean} isStale true if data.gov.sg was unavailable and an old copy was used
 */

/**
 * «control» Finds the CHAS clinics nearest to a location (UC19 Locate Nearest Clinic).
 * The location itself comes from UC2 (GPS or an address resolved through OneMap).
 */
export class ClinicController {
  /** Search radii tried in turn until at least one clinic is found (UC19 3a). */
  static RADII_KM = [2, 5, 10, 50];

  /** At most this many clinics are returned. */
  static MAX_RESULTS = 10;

  /** @param {{clinicCache: import('../repository/ClinicCache.js').ClinicCache}} deps */
  constructor({ clinicCache }) {
    this.clinicCache = clinicCache;
  }

  /**
   * UC19 steps 2–3: nearest clinics to `location`, sorted by distance. If none is within the
   * first radius, the radius is widened (UC19 3a).
   * @param {{latitude: number, longitude: number}} location
   * @param {Date} now
   * @returns {Promise<NearbyClinics>}
   * @throws {ValidationError} location missing or outside Singapore
   * @throws {ServiceUnavailableError} data.gov.sg is down and nothing is cached (UC19 2a)
   */
  async findNearest(location, now) {
    const result = InputValidator.validateLocation(location);
    if (!result.isValid) throw new ValidationError(result.errors);
    const from = new GeoLocation(location);

    let list;
    try {
      list = await this.clinicCache.getClinics(now);
    } catch {
      throw new ServiceUnavailableError('The clinic list is unavailable right now. Please try again later.');
    }

    const byDistance = list.clinics
      .map((c) => ({ ...c, distanceKm: Math.round(c.distanceKmFrom(from) * 100) / 100 }))
      .sort((a, b) => a.distanceKm - b.distanceKm);

    const radii = ClinicController.RADII_KM;
    const radiusKm = radii.find((r) => byDistance.some((c) => c.distanceKm <= r)) ?? radii.at(-1);
    return {
      clinics: byDistance.filter((c) => c.distanceKm <= radiusKm).slice(0, ClinicController.MAX_RESULTS),
      radiusKm,
      updatedAt: list.updatedAt,
      isStale: list.isStale,
    };
  }
}
