import { PublicAlert } from '../entity/PublicAlert.js';
import { InputValidator } from './InputValidator.js';
import { NotFoundError, ValidationError } from './errors.js';

/**
 * @typedef {{notifyAlertPublished(alert: PublicAlert): Promise<{sent: number, failed: number}>}} AlertListener
 */

/**
 * «control» Publishes public health alerts (UC7) and serves the public alert feed (UC16).
 * Acts as the *subject* in the Observer pattern: registered listeners (e.g. NotificationService)
 * are told about every newly published alert.
 */
export class PublicAlertController {
  /**
   * @param {{alertRepo: import('../repository/PublicAlertRepository.js').PublicAlertRepository,
   *          listeners?: AlertListener[],
   *          smsPreviewer?: {previewAlertSms(alert: PublicAlert): string}}} deps
   *   `smsPreviewer` shows the SMS as it is really sent, unsubscribe link included (UC15)
   */
  constructor({ alertRepo, listeners = [], smsPreviewer = null }) {
    this.alertRepo = alertRepo;
    this.listeners = listeners;
    this.smsPreviewer = smsPreviewer;
  }

  /** @returns {Promise<PublicAlert[]>} newest first (UC16 step 1, FR-02) */
  listPublishedAlerts() {
    return this.alertRepo.findLatest();
  }

  /**
   * UC16 step 2 (FR-03).
   * @param {number} id
   * @returns {Promise<PublicAlert>}
   * @throws {NotFoundError}
   */
  async getAlert(id) {
    const alert = await this.alertRepo.findById(id);
    if (!alert) throw new NotFoundError('Alert not found');
    return alert;
  }

  /**
   * UC7 steps 3–6: validates, saves the alert (so it appears on the home feed), then notifies
   * listeners. A notification failure does not undo the publication (UC7 6a).
   * @param {{title: string, body: string, category: string, severity: string,
   *          targetRegion: string}} input
   * @param {number} officialId
   * @param {Date} now
   * @returns {Promise<{alert: PublicAlert, dispatch: {sent: number, failed: number}}>}
   * @throws {ValidationError}
   */
  async publishAlert(input, officialId, now) {
    const result = InputValidator.validateAlertInput(input);
    if (!result.isValid) throw new ValidationError(result.errors);

    const alert = await this.alertRepo.save(new PublicAlert({
      title: input.title.trim(),
      body: input.body.trim(),
      category: input.category,
      severity: input.severity,
      targetRegion: input.targetRegion,
      publishedAt: now,
      publishedBy: officialId,
    }));

    const dispatch = { sent: 0, failed: 0 };
    for (const listener of this.listeners) {
      try {
        const summary = await listener.notifyAlertPublished(alert);
        dispatch.sent += summary.sent;
        dispatch.failed += summary.failed;
      } catch (err) {
        console.error('Alert listener failed:', err.message);
      }
    }
    return { alert, dispatch };
  }

  /**
   * UC7 step 4: builds the preview shown before publishing, without saving anything.
   * @param {object} input
   * @returns {{card: object, smsText: string}}
   */
  previewAlert(input) {
    const draft = new PublicAlert({ ...input, publishedBy: null });
    return {
      card: draft,
      smsText: this.smsPreviewer ? this.smsPreviewer.previewAlertSms(draft) : draft.toSmsText(),
    };
  }
}
