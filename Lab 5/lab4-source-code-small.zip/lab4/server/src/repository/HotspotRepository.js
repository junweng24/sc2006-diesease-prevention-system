import { Repository } from './Repository.js';
import { Hotspot } from '../entity/Hotspot.js';
import { GeoLocation } from '../entity/GeoLocation.js';
import { toBool, toDate } from './Database.js';

/** «container» Persistent collection of official {@link Hotspot}s (UC1, UC8, UC17). */
export class HotspotRepository extends Repository {
  /** @param {import('./Database.js').Database} db */
  constructor(db) {
    super(db, 'hotspots');
  }

  /** @override */
  toEntity(row) {
    return new Hotspot({
      id: row.id,
      diseaseType: row.disease_type,
      location: new GeoLocation({
        latitude: row.latitude, longitude: row.longitude,
        address: row.address, postalCode: row.postal_code,
      }),
      caseCount: row.case_count,
      riskLevel: row.risk_level,
      source: row.source,
      sourceReportId: row.source_report_id,
      isActive: toBool(row.is_active),
      createdBy: row.created_by,
      createdAt: toDate(row.created_at),
    });
  }

  /**
   * @param {{diseaseType?: string}} [filter]
   * @returns {Promise<Hotspot[]>} active hotspots only (removed ones are hidden, FR-21)
   */
  async findActive(filter = {}) {
    const { rows } = filter.diseaseType
      ? await this.db.query(
        'SELECT * FROM hotspots WHERE is_active AND disease_type = $1', [filter.diseaseType])
      : await this.db.query('SELECT * FROM hotspots WHERE is_active');
    return rows.map((r) => this.toEntity(r));
  }

  /**
   * @param {string} referenceId a hotspot report's reference ID
   * @param {object} [client]
   * @returns {Promise<Hotspot[]>} active hotspots created from that report (UC8)
   */
  async findActiveBySourceReport(referenceId, client) {
    const { rows } = await this.db.query(
      'SELECT * FROM hotspots WHERE is_active AND source_report_id = $1', [referenceId], client);
    return rows.map((r) => this.toEntity(r));
  }

  /** @returns {Promise<{code: string, label: string}[]>} all disease types (NFR-08) */
  async findDiseaseTypes() {
    const { rows } = await this.db.query('SELECT code, label FROM disease_types ORDER BY label');
    return rows;
  }

  /** @returns {Promise<string[]>} codes from the configurable disease_types table (NFR-08) */
  async findDiseaseTypeCodes() {
    const { rows } = await this.db.query('SELECT code FROM disease_types ORDER BY code');
    return rows.map((r) => r.code);
  }

  /**
   * Inserts a new hotspot, or updates `is_active` / counts of an existing one.
   * @override
   * @param {Hotspot} h
   */
  async save(h, client) {
    if (h.id) {
      await this.db.query(
        'UPDATE hotspots SET case_count = $2, risk_level = $3, is_active = $4 WHERE id = $1',
        [h.id, h.caseCount, h.riskLevel, h.isActive], client);
      return h;
    }
    const { rows } = await this.db.query(
      `INSERT INTO hotspots (disease_type, latitude, longitude, address, postal_code, case_count,
         risk_level, source, source_report_id, is_active, created_by)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11) RETURNING id`,
      [h.diseaseType, h.location.latitude, h.location.longitude, h.location.address,
        h.location.postalCode, h.caseCount, h.riskLevel, h.source, h.sourceReportId, h.isActive,
        h.createdBy],
      client);
    h.id = rows[0].id;
    return h;
  }
}
