import { Repository } from './Repository.js';
import { VolunteerRegistration } from '../entity/VolunteerRegistration.js';
import { ContactDetails } from '../entity/ContactDetails.js';
import { toBool, toDate } from './Database.js';

/** «container» Persistent collection of {@link VolunteerRegistration}s (UC6, UC10). */
export class VolunteerRegistrationRepository extends Repository {
  /** @param {import('./Database.js').Database} db */
  constructor(db) {
    super(db, 'volunteer_registrations');
  }

  /** @override */
  toEntity(row) {
    return new VolunteerRegistration({
      id: row.id,
      activityId: row.activity_id,
      contact: new ContactDetails({ name: row.name, phone: row.phone, email: row.email }),
      consentGiven: toBool(row.consent_given),
      registeredAt: toDate(row.registered_at),
    });
  }

  /**
   * @param {number} activityId
   * @returns {Promise<VolunteerRegistration[]>} the roster for one activity (UC10)
   */
  async findByActivity(activityId) {
    const { rows } = await this.db.query(
      'SELECT * FROM volunteer_registrations WHERE activity_id = $1 ORDER BY registered_at',
      [activityId]);
    return rows.map((r) => this.toEntity(r));
  }

  /**
   * @param {number} activityId
   * @param {string} email
   * @param {string} phone
   * @param {object} [client]
   * @returns {Promise<boolean>} true if this email or phone is already registered (UC6 2a)
   */
  async existsByActivityAndContact(activityId, email, phone, client) {
    const { rows } = await this.db.query(
      `SELECT 1 FROM volunteer_registrations
        WHERE activity_id = $1 AND (email = $2 OR phone = $3) LIMIT 1`,
      [activityId, email, phone], client);
    return rows.length > 0;
  }

  /**
   * @override
   * @param {VolunteerRegistration} r
   */
  async save(r, client) {
    const { rows } = await this.db.query(
      `INSERT INTO volunteer_registrations (activity_id, name, phone, email, consent_given)
       VALUES ($1,$2,$3,$4,$5) RETURNING id, registered_at`,
      [r.activityId, r.contact.name, r.contact.phone, r.contact.email, r.consentGiven], client);
    r.id = rows[0].id;
    r.registeredAt = toDate(rows[0].registered_at);
    return r;
  }
}
