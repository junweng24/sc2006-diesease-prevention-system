import { DengueCluster } from '../entity/DengueCluster.js';
import { GeoLocation } from '../entity/GeoLocation.js';
import { toDate } from './Database.js';

/**
 * «container» Stores the latest snapshot of data.gov.sg dengue clusters so the map can show the
 * "last known state" when the external API is unavailable (UC1 2a).
 */
export class ClusterCacheRepository {
  /** Older snapshots than the newest few are deleted; only the latest one is ever read. */
  static KEEP_SNAPSHOTS = 5;

  /** @param {import('./Database.js').Database} db */
  constructor(db) {
    this.db = db;
  }

  /**
   * @param {DengueCluster[]} clusters
   * @param {Date} syncedAt
   */
  async saveSnapshot(clusters, syncedAt) {
    await this.db.query(
      'INSERT INTO cluster_snapshots (clusters, synced_at) VALUES ($1, $2)',
      [JSON.stringify(clusters), syncedAt]);
    await this.db.query(
      `DELETE FROM cluster_snapshots WHERE id NOT IN (
         SELECT id FROM cluster_snapshots ORDER BY synced_at DESC LIMIT $1)`,
      [ClusterCacheRepository.KEEP_SNAPSHOTS]);
  }

  /** @returns {Promise<{clusters: DengueCluster[], syncedAt: Date}|null>} */
  async getLatestSnapshot() {
    const { rows } = await this.db.query(
      'SELECT clusters, synced_at FROM cluster_snapshots ORDER BY synced_at DESC LIMIT 1');
    if (!rows[0]) return null;
    const clusters = JSON.parse(rows[0].clusters).map((c) => new DengueCluster({
      ...c,
      boundary: c.boundary.map((p) => new GeoLocation(p)),
    }));
    return { clusters, syncedAt: toDate(rows[0].synced_at) };
  }
}
