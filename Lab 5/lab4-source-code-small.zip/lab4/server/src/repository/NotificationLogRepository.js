import { Repository } from './Repository.js';
import { NotificationLog } from '../entity/NotificationLog.js';
import { toDate } from './Database.js';

/** «container» Persistent collection of {@link NotificationLog} entries (UC7 6a). */
export class NotificationLogRepository extends Repository {
  /** @param {import('./Database.js').Database} db */
  constructor(db) {
    super(db, 'notification_logs');
  }

  /** @override */
  toEntity(row) {
    return new NotificationLog({
      id: row.id,
      subjectType: row.subject_type,
      subjectId: row.subject_id,
      channel: row.channel,
      recipient: row.recipient,
      status: row.status,
      errorMessage: row.error_message,
      attemptCount: row.attempt_count,
      createdAt: toDate(row.created_at),
    });
  }

  /**
   * @override
   * @param {NotificationLog} log
   */
  async save(log, client) {
    const { rows } = await this.db.query(
      `INSERT INTO notification_logs (subject_type, subject_id, channel, recipient, status,
         error_message, attempt_count)
       VALUES ($1,$2,$3,$4,$5,$6,$7) RETURNING id`,
      [log.subjectType, log.subjectId, log.channel, log.recipient, log.status, log.errorMessage,
        log.attemptCount], client);
    log.id = rows[0].id;
    return log;
  }

  // TODO(UC7 6a): findPendingRetry() + a scheduled job that re-sends FAILED entries.
}
