import { Repository } from './Repository.js';
import { PublicAlert } from '../entity/PublicAlert.js';
import { toDate } from './Database.js';

/** «container» Persistent collection of {@link PublicAlert}s (UC7, UC16). */
export class PublicAlertRepository extends Repository {
  /** @param {import('./Database.js').Database} db */
  constructor(db) {
    super(db, 'public_alerts');
  }

  /** @override */
  toEntity(row) {
    return new PublicAlert({
      id: row.id,
      title: row.title,
      body: row.body,
      category: row.category,
      severity: row.severity,
      targetRegion: row.target_region,
      publishedAt: toDate(row.published_at),
      publishedBy: row.published_by,
    });
  }

  /**
   * @param {number} [limit=50]
   * @returns {Promise<PublicAlert[]>} newest first (FR-02)
   */
  async findLatest(limit = 50) {
    const { rows } = await this.db.query(
      'SELECT * FROM public_alerts ORDER BY published_at DESC LIMIT $1', [limit]);
    return rows.map((r) => this.toEntity(r));
  }

  /**
   * @override
   * @param {PublicAlert} a
   */
  async save(a, client) {
    const { rows } = await this.db.query(
      `INSERT INTO public_alerts (title, body, category, severity, target_region, published_at,
         published_by)
       VALUES ($1,$2,$3,$4,$5,$6,$7) RETURNING id`,
      [a.title, a.body, a.category, a.severity, a.targetRegion, a.publishedAt, a.publishedBy],
      client);
    a.id = rows[0].id;
    return a;
  }
}
