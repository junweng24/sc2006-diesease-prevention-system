import { Repository } from './Repository.js';
import { Official } from '../entity/Official.js';

/** «container» Persistent collection of {@link Official} accounts. */
export class OfficialRepository extends Repository {
  /** @param {import('./Database.js').Database} db */
  constructor(db) {
    super(db, 'officials');
  }

  /** @override */
  toEntity(row) {
    return new Official({
      id: row.id,
      username: row.username,
      passwordHash: row.password_hash,
      role: row.role,
      failedLoginAttempts: row.failed_login_attempts,
      lockedUntil: row.locked_until,
    });
  }

  /**
   * @param {string} username
   * @returns {Promise<Official|null>}
   */
  async findByUsername(username) {
    const { rows } = await this.db.query('SELECT * FROM officials WHERE username = $1', [username]);
    return rows[0] ? this.toEntity(rows[0]) : null;
  }

  /**
   * Persists the lock-out fields after a login attempt (UC14).
   * @param {Official} official
   */
  async updateLoginState(official) {
    await this.db.query(
      'UPDATE officials SET failed_login_attempts = $2, locked_until = $3 WHERE id = $1',
      [official.id, official.failedLoginAttempts, official.lockedUntil]);
  }

  // Official accounts are created by the system administrator with scripts/createOfficial.js
  // (outside the use case model); locked accounts unlock themselves after the lock-out period.
}
