import { AsyncLocalStorage } from 'node:async_hooks';
import { mkdirSync, readFileSync } from 'node:fs';
import path from 'node:path';
import { DatabaseSync } from 'node:sqlite';
import { fileURLToPath } from 'node:url';

const SCHEMA_FILE = fileURLToPath(new URL('../../db/schema.sql', import.meta.url));

/**
 * «singleton» Shared SQLite database (one file, built into Node.js 22.13+, nothing to install).
 * All repositories go through this class; no other class talks to the database directly.
 *
 * Repositories write PostgreSQL-style numbered placeholders ($1, $2, ...). {@link query}
 * converts them to SQLite's `?` and converts booleans / Dates to values SQLite can store.
 */
export class Database {
  static #instance = null;

  /** Serialises transactions: SQLite has one connection, so only one may be open at a time. */
  #queue = Promise.resolve();

  /** Marks code that is running inside the currently open transaction. */
  #txContext = new AsyncLocalStorage();

  /**
   * Opens (or creates) the database file and applies db/schema.sql, so a fresh checkout needs
   * no manual set-up.
   * @param {string} filePath database file, or ':memory:' for tests
   */
  constructor(filePath) {
    if (filePath !== ':memory:') mkdirSync(path.dirname(filePath), { recursive: true });
    this.sqlite = new DatabaseSync(filePath);
    this.sqlite.exec('PRAGMA foreign_keys = ON; PRAGMA journal_mode = WAL;');
    const schema = readFileSync(SCHEMA_FILE, 'utf8');
    this.#migrateSubscriptions(schema);
    this.sqlite.exec(schema);
  }

  /**
   * Upgrades a database created before unsubscribing existed (UC15). CREATE TABLE IF NOT EXISTS
   * leaves an old table as it is, and SQLite cannot change a CHECK constraint in place, so the
   * table is rebuilt from db/schema.sql. Existing subscribers keep their ids and get a token.
   * @param {string} schema contents of db/schema.sql
   */
  #migrateSubscriptions(schema) {
    const table = this.sqlite.prepare(
      "SELECT sql FROM sqlite_master WHERE type = 'table' AND name = 'alert_subscriptions'").get();
    if (!table || table.sql.includes('unsubscribe_token')) return;
    this.sqlite.exec('BEGIN IMMEDIATE');
    try {
      this.sqlite.exec('ALTER TABLE alert_subscriptions RENAME TO alert_subscriptions_old');
      this.sqlite.exec(schema);
      this.sqlite.exec(
        `INSERT INTO alert_subscriptions (id, email, phone, channels, region, wants_volunteer_news,
           consent_given, unsubscribe_token, created_at)
         SELECT id, email, phone, channels, region, wants_volunteer_news,
           consent_given, lower(hex(randomblob(16))), created_at
         FROM alert_subscriptions_old`);
      this.sqlite.exec('DROP TABLE alert_subscriptions_old');
      this.sqlite.exec('COMMIT');
    } catch (err) {
      this.sqlite.exec('ROLLBACK');
      throw err;
    }
  }

  /**
   * Creates the instance on first call; later calls return the same database.
   * @param {string} [filePath] required on the first call only
   * @returns {Database}
   */
  static getInstance(filePath) {
    if (!Database.#instance) Database.#instance = new Database(filePath);
    return Database.#instance;
  }

  /**
   * Runs a parameterised query (never build SQL by string concatenation).
   * Outside a transaction it waits until any open transaction has finished.
   * @param {string} sql may use $1, $2, ... placeholders
   * @param {unknown[]} [params]
   * @param {object} [client] the handle given by {@link transaction}; kept for readability,
   *   queries inside a transaction join it automatically
   * @returns {Promise<{rows: Record<string, any>[], rowCount: number}>}
   */
  query(sql, params = [], client = undefined) { // eslint-disable-line no-unused-vars
    if (this.#txContext.getStore()) return Promise.resolve(this.#execute(sql, params));
    return this.#exclusive(() => this.#execute(sql, params));
  }

  /**
   * Runs `work` inside a transaction: COMMIT if it resolves, ROLLBACK if it throws (NFR-04).
   * BEGIN IMMEDIATE takes the write lock at the start, so two requests cannot both take the
   * last volunteer slot (UC6, NFR-03).
   * @template R
   * @param {(client: object) => Promise<R>} work
   * @returns {Promise<R>}
   */
  transaction(work) {
    return this.#exclusive(() => this.#txContext.run(true, async () => {
      this.sqlite.exec('BEGIN IMMEDIATE');
      try {
        const result = await work({});
        this.sqlite.exec('COMMIT');
        return result;
      } catch (err) {
        this.sqlite.exec('ROLLBACK');
        throw err;
      }
    }));
  }

  /** Verifies the database can be read at start-up so the server fails fast. */
  async ping() {
    await this.query('SELECT 1');
  }

  /** Closes the database file (graceful shutdown). */
  async close() {
    await this.#queue;
    this.sqlite.close();
  }

  /** Runs `fn` after everything already queued, without letting a failure block the queue. */
  #exclusive(fn) {
    const run = this.#queue.then(fn);
    this.#queue = run.catch(() => {});
    return run;
  }

  #execute(sql, params) {
    const values = [];
    const text = sql.replace(/\$(\d+)/g, (_, n) => {
      values.push(Database.#toSqlValue(params[Number(n) - 1]));
      return '?';
    });
    const stmt = this.sqlite.prepare(text);
    if (/^\s*(SELECT|WITH)\b|\bRETURNING\b/i.test(text)) {
      const rows = stmt.all(...values);
      return { rows, rowCount: rows.length };
    }
    return { rows: [], rowCount: stmt.run(...values).changes };
  }

  /** SQLite has no boolean or date type: booleans are stored as 1/0, dates as ISO-8601 text. */
  static #toSqlValue(value) {
    if (value === undefined) return null;
    if (typeof value === 'boolean') return value ? 1 : 0;
    if (value instanceof Date) return value.toISOString();
    return value;
  }
}

/**
 * Reads an ISO-8601 text column back as a Date.
 * @param {string|null} value
 * @returns {Date|null}
 */
export function toDate(value) {
  return value == null ? null : new Date(value);
}

/**
 * Reads a 0/1 column back as a boolean.
 * @param {number|null} value
 * @returns {boolean}
 */
export function toBool(value) {
  return Boolean(value);
}
