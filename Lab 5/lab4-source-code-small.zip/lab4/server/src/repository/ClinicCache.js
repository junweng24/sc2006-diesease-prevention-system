/**
 * «container» In-memory collection of CHAS {@link Clinic}s (UC19). The list is public reference
 * data that is cheap to re-download, so it is not stored in the database; it is refreshed once
 * a day and the last good copy is kept if data.gov.sg is unavailable (UC19 2a).
 */
export class ClinicCache {
  /** Refresh the clinic list after this long. */
  static TTL_MS = 24 * 60 * 60 * 1000;

  /** @type {import('../entity/Clinic.js').Clinic[]} */
  #clinics = [];

  /** @type {Date|null} when the list was last downloaded successfully */
  #updatedAt = null;

  /** @param {import('../boundary/adapters/DataGovAdapter.js').DataGovAdapter} dataGov */
  constructor(dataGov) {
    this.dataGov = dataGov;
  }

  /**
   * @param {Date} now
   * @returns {Promise<{clinics: import('../entity/Clinic.js').Clinic[], updatedAt: Date|null,
   *          isStale: boolean}>} isStale is true if a refresh failed and an old copy is returned
   * @throws {Error} only if data.gov.sg is unavailable and nothing has been cached yet
   */
  async getClinics(now) {
    if (this.#updatedAt && now - this.#updatedAt < ClinicCache.TTL_MS) {
      return { clinics: this.#clinics, updatedAt: this.#updatedAt, isStale: false };
    }
    try {
      this.#clinics = await this.dataGov.fetchClinics();
      this.#updatedAt = now;
      return { clinics: this.#clinics, updatedAt: now, isStale: false };
    } catch (err) {
      if (!this.#updatedAt) throw err;
      console.warn('data.gov.sg unavailable, using cached clinics:', err.message);
      return { clinics: this.#clinics, updatedAt: this.#updatedAt, isStale: true };
    }
  }
}
