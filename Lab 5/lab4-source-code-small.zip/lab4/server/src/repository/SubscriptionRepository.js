import { Repository } from './Repository.js';
import { AlertSubscription } from '../entity/AlertSubscription.js';
import { toBool, toDate } from './Database.js';

/** «container» Persistent collection of {@link AlertSubscription}s (UC15). */
export class SubscriptionRepository extends Repository {
  /** @param {import('./Database.js').Database} db */
  constructor(db) {
    super(db, 'alert_subscriptions');
  }

  /** @override */
  toEntity(row) {
    return new AlertSubscription({
      id: row.id,
      email: row.email,
      phone: row.phone,
      channels: row.channels.split(','),
      region: row.region,
      wantsVolunteerNews: toBool(row.wants_volunteer_news),
      consentGiven: toBool(row.consent_given),
      unsubscribeToken: row.unsubscribe_token,
      withdrawnAt: toDate(row.withdrawn_at),
      createdAt: toDate(row.created_at),
    });
  }

  /**
   * @param {string} region alert target region
   * @returns {Promise<AlertSubscription[]>} subscribers who should get an alert for `region`;
   *   anyone who withdrew consent is left out (UC15)
   */
  async findByRegion(region) {
    const { rows } = await this.db.query(
      'SELECT * FROM alert_subscriptions WHERE consent_given');
    return rows.map((r) => this.toEntity(r)).filter((s) => s.matchesRegion(region));
  }

  /**
   * @returns {Promise<AlertSubscription[]>} subscribers who opted in to volunteer news (FR-25)
   *   and have not withdrawn consent (UC15)
   */
  async findVolunteerNewsSubscribers() {
    const { rows } = await this.db.query(
      'SELECT * FROM alert_subscriptions WHERE wants_volunteer_news AND consent_given');
    return rows.map((r) => this.toEntity(r));
  }

  /**
   * @param {string|null} email
   * @param {string|null} phone
   * @returns {Promise<boolean>} true if either contact is already subscribed
   */
  async existsByContact(email, phone) {
    const { rows } = await this.db.query(
      'SELECT 1 FROM alert_subscriptions WHERE email = $1 OR phone = $2 LIMIT 1', [email, phone]);
    return rows.length > 0;
  }

  /**
   * @param {string} token
   * @returns {Promise<AlertSubscription|null>} the subscription this unsubscribe link belongs to
   */
  async findByUnsubscribeToken(token) {
    const { rows } = await this.db.query(
      'SELECT * FROM alert_subscriptions WHERE unsubscribe_token = $1', [token]);
    return rows[0] ? this.toEntity(rows[0]) : null;
  }

  /**
   * Withdraws consent and erases the contact details (UC15), which also lets the person
   * subscribe again later. One conditional UPDATE, so two simultaneous clicks cannot both win.
   * @param {string} token
   * @param {Date} now
   * @returns {Promise<boolean>} false if nothing changed (consent was already withdrawn)
   */
  async withdrawConsent(token, now) {
    const { rowCount } = await this.db.query(
      `UPDATE alert_subscriptions
       SET consent_given = 0, email = NULL, phone = NULL, withdrawn_at = $2
       WHERE unsubscribe_token = $1 AND consent_given`, [token, now]);
    return rowCount > 0;
  }

  /**
   * @override
   * @param {AlertSubscription} s
   */
  async save(s, client) {
    const { rows } = await this.db.query(
      `INSERT INTO alert_subscriptions (email, phone, channels, region, wants_volunteer_news,
         consent_given, unsubscribe_token)
       VALUES ($1,$2,$3,$4,$5,$6,$7) RETURNING id`,
      [s.email, s.phone, s.channels.join(','), s.region, s.wantsVolunteerNews, s.consentGiven,
        s.unsubscribeToken],
      client);
    s.id = rows[0].id;
    return s;
  }
}
