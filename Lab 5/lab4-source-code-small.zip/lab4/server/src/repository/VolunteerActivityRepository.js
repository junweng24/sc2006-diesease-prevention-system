import { Repository } from './Repository.js';
import { VolunteerActivity } from '../entity/VolunteerActivity.js';
import { ContactDetails } from '../entity/ContactDetails.js';

/** «container» Persistent collection of {@link VolunteerActivity}s (UC6, UC9–UC11). */
export class VolunteerActivityRepository extends Repository {
  /** @param {import('./Database.js').Database} db */
  constructor(db) {
    super(db, 'volunteer_activities');
  }

  /** @override */
  toEntity(row) {
    return new VolunteerActivity({
      id: row.id,
      title: row.title,
      targetArea: row.target_area,
      eventDateTime: row.event_datetime,
      headcountQuota: row.headcount_quota,
      registeredCount: row.registered_count,
      priority: row.priority,
      description: row.description,
      contactPerson: new ContactDetails({ name: row.contact_name, phone: row.contact_phone }),
      status: row.status,
      createdBy: row.created_by,
    });
  }

  /**
   * Reads an activity that is about to be changed. Must be called inside a transaction:
   * {@link Database#transaction} holds the database write lock until it ends, so two people
   * cannot take the last slot at the same time (UC6, NFR-03).
   * @param {number} id
   * @param {object} client must be inside a transaction
   * @returns {Promise<VolunteerActivity|null>}
   */
  async findByIdForUpdate(id, client) {
    return this.findById(id, client);
  }

  /**
   * @param {Date} now
   * @returns {Promise<VolunteerActivity[]>} upcoming activities that are not cancelled
   */
  async findUpcoming(now) {
    const { rows } = await this.db.query(
      `SELECT * FROM volunteer_activities
        WHERE event_datetime >= $1 AND status <> 'CANCELLED'
        ORDER BY event_datetime`, [now]);
    return rows.map((r) => this.toEntity(r));
  }

  /**
   * Inserts or updates an activity.
   * @override
   * @param {VolunteerActivity} a
   */
  async save(a, client) {
    const params = [a.title, a.targetArea, a.eventDateTime, a.headcountQuota, a.registeredCount,
      a.priority, a.description, a.contactPerson?.name ?? null, a.contactPerson?.phone ?? null,
      a.status];
    if (a.id) {
      await this.db.query(
        `UPDATE volunteer_activities SET title=$2, target_area=$3, event_datetime=$4,
           headcount_quota=$5, registered_count=$6, priority=$7, description=$8,
           contact_name=$9, contact_phone=$10, status=$11
         WHERE id = $1`, [a.id, ...params], client);
      return a;
    }
    const { rows } = await this.db.query(
      `INSERT INTO volunteer_activities (title, target_area, event_datetime, headcount_quota,
         registered_count, priority, description, contact_name, contact_phone, status, created_by)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11) RETURNING id`,
      [...params, a.createdBy], client);
    a.id = rows[0].id;
    return a;
  }
}
