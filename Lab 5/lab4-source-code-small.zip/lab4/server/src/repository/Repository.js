/**
 * «container» Base class for repositories (Repository / DAO pattern).
 * A repository holds the collection of one entity type and hides all SQL from control classes.
 *
 * Subclasses implement {@link toEntity} and the queries they need. Every method takes an
 * optional `client` so it can take part in a {@link Database#transaction}.
 *
 * @template T entity type
 */
export class Repository {
  /**
   * @param {import('./Database.js').Database} db
   * @param {string} table table name
   * @param {string} [idColumn='id'] primary key column
   */
  constructor(db, table, idColumn = 'id') {
    this.db = db;
    this.table = table;
    this.idColumn = idColumn;
  }

  /**
   * Maps a database row to an entity object.
   * @abstract
   * @param {Record<string, any>} row
   * @returns {T}
   */
  // eslint-disable-next-line no-unused-vars
  toEntity(row) {
    throw new Error(`${this.constructor.name}.toEntity() not implemented`);
  }

  /**
   * @param {string|number} id
   * @param {object} [client]
   * @returns {Promise<T|null>}
   */
  async findById(id, client) {
    const { rows } = await this.db.query(
      `SELECT * FROM ${this.table} WHERE ${this.idColumn} = $1`, [id], client);
    return rows[0] ? this.toEntity(rows[0]) : null;
  }

  /**
   * @param {object} [client]
   * @returns {Promise<T[]>}
   */
  async findAll(client) {
    const { rows } = await this.db.query(`SELECT * FROM ${this.table}`, [], client);
    return rows.map((r) => this.toEntity(r));
  }

  /**
   * Inserts a new entity, or updates it if it already has an id (UC12 rule from Lab 2).
   * @abstract
   * @param {T} entity
   * @param {object} [client]
   * @returns {Promise<T>} the saved entity (with generated id)
   */
  // eslint-disable-next-line no-unused-vars
  async save(entity, client) {
    throw new Error(`${this.constructor.name}.save() not implemented`);
  }
}
