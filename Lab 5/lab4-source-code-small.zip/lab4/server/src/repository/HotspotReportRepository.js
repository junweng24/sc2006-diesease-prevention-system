import { Repository } from './Repository.js';
import { HotspotReport } from '../entity/HotspotReport.js';
import { GeoLocation } from '../entity/GeoLocation.js';
import { ContactDetails } from '../entity/ContactDetails.js';
import { toDate } from './Database.js';

/** «container» Persistent collection of {@link HotspotReport}s (UC3, UC8). */
export class HotspotReportRepository extends Repository {
  /** @param {import('./Database.js').Database} db */
  constructor(db) {
    super(db, 'hotspot_reports', 'reference_id');
  }

  /** @override */
  toEntity(row) {
    return new HotspotReport({
      referenceId: row.reference_id,
      location: new GeoLocation({
        latitude: row.latitude, longitude: row.longitude,
        address: row.address, postalCode: row.postal_code,
      }),
      siteType: row.site_type,
      description: row.description,
      photoPath: row.photo_path,
      contact: new ContactDetails({
        name: row.contact_name, phone: row.contact_phone, email: row.contact_email,
      }),
      status: row.status,
      submittedAt: toDate(row.submitted_at),
      reviewedBy: row.reviewed_by,
      reviewedAt: toDate(row.reviewed_at),
      version: row.version,
    });
  }

  /**
   * Inserts a new report (reports are created once and then only change status).
   * @override
   * @param {HotspotReport} report
   */
  async save(report, client) {
    const c = report.contact ?? new ContactDetails();
    await this.db.query(
      `INSERT INTO hotspot_reports (reference_id, latitude, longitude, address, postal_code,
         site_type, description, photo_path, contact_name, contact_phone, contact_email,
         status, submitted_at)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13)`,
      [report.referenceId, report.location.latitude, report.location.longitude,
        report.location.address, report.location.postalCode, report.siteType, report.description,
        report.photoPath, c.name, c.phone, c.email, report.status, report.submittedAt],
      client);
    return report;
  }

  /**
   * @param {{status?: string}} [filter]
   * @returns {Promise<HotspotReport[]>} newest first
   */
  async findByStatus(filter = {}) {
    const { rows } = filter.status
      ? await this.db.query(
        'SELECT * FROM hotspot_reports WHERE status = $1 ORDER BY submitted_at DESC', [filter.status])
      : await this.db.query('SELECT * FROM hotspot_reports ORDER BY submitted_at DESC');
    return rows.map((r) => this.toEntity(r));
  }

  /**
   * Saves a status change only if nobody else changed the report since it was read
   * (optimistic locking, UC8 4a).
   * @param {HotspotReport} report report with the new status already applied
   * @param {number} expectedVersion version the official was looking at
   * @param {object} [client]
   * @returns {Promise<boolean>} false if another official saved first
   */
  async updateStatusWithVersion(report, expectedVersion, client) {
    const { rowCount } = await this.db.query(
      `UPDATE hotspot_reports
          SET status = $2, reviewed_by = $3, reviewed_at = $4, version = version + 1
        WHERE reference_id = $1 AND version = $5`,
      [report.referenceId, report.status, report.reviewedBy, report.reviewedAt, expectedVersion],
      client);
    if (rowCount === 1) report.version = expectedVersion + 1;
    return rowCount === 1;
  }
}
