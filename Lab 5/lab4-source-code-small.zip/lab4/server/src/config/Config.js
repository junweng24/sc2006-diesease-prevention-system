import 'dotenv/config';

/**
 * «singleton» Read-only application configuration loaded from environment variables.
 * Use {@link Config.getInstance} instead of `new`.
 */
export class Config {
  static #instance = null;

  constructor() {
    this.port = Number(process.env.PORT ?? 3000);
    /** SQLite file, relative to the server/ folder. Created on first start. */
    this.databaseFile = process.env.DATABASE_FILE ?? 'data/disease_prevention.db';
    this.jwtSecret = process.env.JWT_SECRET || 'dev-secret';
    this.jwtExpiresMinutes = Number(process.env.JWT_EXPIRES_MINUTES ?? 30);
    this.uploadDir = process.env.UPLOAD_DIR ?? 'uploads';
    this.oneMap = {
      baseUrl: process.env.ONEMAP_BASE_URL ?? 'https://www.onemap.gov.sg',
      email: process.env.ONEMAP_EMAIL,
      password: process.env.ONEMAP_PASSWORD,
    };
    /** NEA "Dengue Clusters" GeoJSON on data.gov.sg (UC1). */
    this.dataGovDengueDatasetId = process.env.DATAGOV_DENGUE_DATASET_ID ?? 'd_dbfabf16158d1b0e1c420627c0819168';
    /** MOH "CHAS Clinics" GeoJSON on data.gov.sg (UC19). */
    this.dataGovChasDatasetId = process.env.DATAGOV_CHAS_DATASET_ID ?? 'd_548c33ea2d99e29ec63a7cc9edcccedc';
    this.smtp = {
      host: process.env.SMTP_HOST,
      port: Number(process.env.SMTP_PORT ?? 587),
      user: process.env.SMTP_USER,
      pass: process.env.SMTP_PASS,
      from: process.env.EMAIL_FROM,
    };
    this.smsProvider = process.env.SMS_PROVIDER ?? 'console';
    /**
     * Where people open the website; unsubscribe links in notifications point here (UC15).
     * DEV_CLIENT_URL is set by scripts/dev.js, where the website runs on its own port.
     */
    this.publicBaseUrl = process.env.PUBLIC_BASE_URL || process.env.DEV_CLIENT_URL
      || `http://localhost:${this.port}`;
    /** Login lock-out policy (UC14 2b). */
    this.maxFailedLogins = 5;
    this.lockoutMinutes = 15;
    Object.freeze(this);
  }

  /** @returns {Config} the single shared configuration object */
  static getInstance() {
    if (!Config.#instance) Config.#instance = new Config();
    return Config.#instance;
  }
}
