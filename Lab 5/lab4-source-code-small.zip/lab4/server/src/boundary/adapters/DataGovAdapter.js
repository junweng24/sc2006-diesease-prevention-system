import { Clinic } from '../../entity/Clinic.js';
import { DengueCluster } from '../../entity/DengueCluster.js';
import { GeoLocation } from '../../entity/GeoLocation.js';

/**
 * «boundary» Adapter for data.gov.sg. Downloads NEA's dengue cluster GeoJSON (UC1) and MOH's
 * CHAS clinic GeoJSON (UC19) and converts them into entities.
 *
 * data.gov.sg datasets are downloaded in two steps: "poll-download" returns a temporary URL,
 * then that URL returns the GeoJSON file.
 */
export class DataGovAdapter {
  static API_BASE = 'https://api-open.data.gov.sg/v1/public/api/datasets';

  /**
   * @param {{dengueDatasetId: string, chasDatasetId: string}} options
   * @param {typeof fetch} [fetchFn] injectable for tests
   */
  constructor({ dengueDatasetId, chasDatasetId }, fetchFn = fetch) {
    this.dengueDatasetId = dengueDatasetId;
    this.chasDatasetId = chasDatasetId;
    this.fetch = fetchFn;
  }

  /**
   * @returns {Promise<DengueCluster[]>}
   * @throws {Error} if data.gov.sg is unreachable; the caller falls back to the cache (UC1 2a)
   */
  async fetchDengueClusters() {
    const geojson = await this.#download(this.dengueDatasetId);
    return (geojson.features ?? []).map((f, i) => DataGovAdapter.toCluster(f, i));
  }

  /**
   * @returns {Promise<Clinic[]>}
   * @throws {Error} if data.gov.sg is unreachable; the caller falls back to the cache (UC19 2a)
   */
  async fetchClinics() {
    const geojson = await this.#download(this.chasDatasetId);
    return (geojson.features ?? [])
      .map((f, i) => DataGovAdapter.toClinic(f, i))
      .filter((c) => c.location.isWithinSingapore());
  }

  /**
   * Converts one GeoJSON feature into a cluster. Field names checked against the dengue
   * dataset (d_dbfabf16158d1b0e1c420627c0819168) in October 2026: LOCALITY, CASE_SIZE and
   * OBJECTID are plain properties. Older KML-style exports kept them in an HTML "Description"
   * table, which is still accepted as a fallback.
   * @param {object} feature GeoJSON Feature (Polygon or MultiPolygon)
   * @param {number} index fallback id
   * @returns {DengueCluster}
   */
  static toCluster(feature, index) {
    const props = feature.properties ?? {};
    const cell = (name) => DataGovAdapter.descriptionCell(props, name);
    const coords = feature.geometry?.coordinates ?? [];
    // A MultiPolygon is drawn using its first polygon's outer ring.
    const ring = (feature.geometry?.type === 'MultiPolygon' ? coords[0]?.[0] : coords[0]) ?? [];
    return new DengueCluster({
      clusterId: String(props.OBJECTID ?? props.Name ?? `cluster-${index}`),
      locality: props.LOCALITY ?? cell('LOCALITY') ?? 'Unknown',
      caseCount: Number(props.CASE_SIZE ?? cell('CASE_SIZE') ?? 0),
      // GeoJSON order is [longitude, latitude(, altitude)]
      boundary: ring.map(([lng, lat]) => new GeoLocation({ latitude: lat, longitude: lng })),
    });
  }

  /**
   * Converts one GeoJSON feature into a clinic. Field names checked against the CHAS dataset
   * (d_548c33ea2d99e29ec63a7cc9edcccedc) in October 2026.
   * @param {object} feature GeoJSON Feature (Point)
   * @param {number} index fallback id
   * @returns {Clinic}
   */
  static toClinic(feature, index) {
    const props = feature.properties ?? {};
    const cell = (name) => DataGovAdapter.descriptionCell(props, name);
    const [lng, lat] = feature.geometry?.coordinates ?? [];
    const street = [cell('BLK_HSE_NO'), cell('STREET_NAME')].filter(Boolean).join(' ');
    const unit = cell('FLOOR_NO') && cell('UNIT_NO') ? `#${cell('FLOOR_NO')}-${cell('UNIT_NO')}` : '';
    const address = [street, unit, cell('BUILDING_NAME'), cell('POSTAL_CD') && `Singapore ${cell('POSTAL_CD')}`]
      .filter(Boolean).join(', ');
    return new Clinic({
      code: cell('HCI_CODE') ?? `clinic-${index}`,
      name: cell('HCI_NAME') ?? 'Unnamed clinic',
      phone: cell('HCI_TEL') ?? null,
      location: new GeoLocation({
        latitude: lat, longitude: lng, address, postalCode: cell('POSTAL_CD') ?? null,
      }),
    });
  }

  /**
   * data.gov.sg KML-style exports keep attributes in an HTML table in `Description`:
   * `<th>NAME</th> <td>value</td>`.
   * @param {object} props GeoJSON feature properties
   * @param {string} name attribute name
   * @returns {string|undefined} trimmed value, or undefined if missing or empty
   */
  static descriptionCell(props, name) {
    const html = String(props.Description ?? '');
    const value = html.match(new RegExp(`<th>${name}</th>\\s*<td>([^<]*)</td>`, 'i'))?.[1]?.trim();
    return value || undefined;
  }

  /** Two-step download: poll-download gives a temporary URL, which returns the GeoJSON. */
  async #download(datasetId) {
    const poll = await this.#getJson(`${DataGovAdapter.API_BASE}/${datasetId}/poll-download`);
    const downloadUrl = poll?.data?.url;
    if (!downloadUrl) throw new Error('data.gov.sg did not return a download URL');
    return this.#getJson(downloadUrl);
  }

  async #getJson(url) {
    const res = await this.fetch(url, { signal: AbortSignal.timeout(15000) });
    if (!res.ok) throw new Error(`data.gov.sg request failed: HTTP ${res.status}`);
    return res.json();
  }
}
