import { GeoLocation } from '../../entity/GeoLocation.js';

/**
 * «boundary» Adapter for the OneMap API (Singapore Land Authority), used for address search
 * and reverse geocoding (UC2). Converts OneMap's JSON into {@link GeoLocation} objects so no
 * other class depends on OneMap's response format.
 *
 * Docs: https://www.onemap.gov.sg/apidocs/ (check endpoint paths and auth before the demo).
 */
export class OneMapAdapter {
  /**
   * @param {{baseUrl: string, email?: string, password?: string}} options
   * @param {typeof fetch} [fetchFn] injectable for tests
   */
  constructor({ baseUrl, email, password }, fetchFn = fetch) {
    this.baseUrl = baseUrl;
    this.email = email;
    this.password = password;
    this.fetch = fetchFn;
    /** @type {{value: string, expiresAt: number}|null} */
    this.token = null;
  }

  /**
   * Searches for an address, building name or postal code. OneMap answers this without an
   * account; a token is sent anyway when one is configured.
   * @param {string} query
   * @returns {Promise<GeoLocation[]>} best matches; empty array if nothing matched (UC2 exception)
   */
  async search(query) {
    if (!query.trim()) return [];
    const url = new URL('/api/common/elastic/search', this.baseUrl);
    url.search = new URLSearchParams({
      searchVal: query, returnGeom: 'Y', getAddrDetails: 'Y', pageNum: '1',
    }).toString();
    const token = this.hasAccount() ? await this.#getToken().catch(() => null) : null;
    const res = await this.fetch(url, {
      headers: token ? { Authorization: token } : {},
      signal: AbortSignal.timeout(5000),
    });
    if (!res.ok) throw new Error(`OneMap search failed: HTTP ${res.status}`);
    const body = await res.json();
    return (body.results ?? []).map((r) => new GeoLocation({
      latitude: Number(r.LATITUDE),
      longitude: Number(r.LONGITUDE),
      address: r.ADDRESS,
      postalCode: r.POSTAL !== 'NIL' ? r.POSTAL : null,
    }));
  }

  /** @returns {boolean} true if a OneMap account is configured in .env */
  hasAccount() {
    return Boolean(this.email && this.password);
  }

  /**
   * Finds the nearest address for a GPS position (requires a OneMap account token).
   * Endpoint and fields as in https://www.onemap.gov.sg/apidocs/ ("Reverse Geocode WGS84").
   * @param {number} lat
   * @param {number} lng
   * @returns {Promise<GeoLocation>}
   * @throws {Error} no account configured or OneMap unavailable
   */
  async reverseGeocode(lat, lng) {
    const token = await this.#getToken();
    const url = new URL('/api/public/revgeocode', this.baseUrl);
    url.search = new URLSearchParams({
      location: `${lat},${lng}`, buffer: '40', addressType: 'All',
    }).toString();
    const res = await this.fetch(url, {
      headers: { Authorization: token },
      signal: AbortSignal.timeout(5000),
    });
    if (!res.ok) throw new Error(`OneMap reverse geocode failed: HTTP ${res.status}`);
    const body = await res.json();
    const first = body.GeocodeInfo?.[0];
    const known = (v) => v && v !== 'NIL';
    const address = first
      ? [first.BLOCK, first.ROAD, first.BUILDINGNAME].filter(known).join(' ') || null
      : null;
    const postalCode = known(first?.POSTALCODE) ? first.POSTALCODE : null;
    return new GeoLocation({ latitude: lat, longitude: lng, address, postalCode });
  }

  /** Gets (and caches) an access token using the account in .env. */
  async #getToken() {
    if (this.token && Date.now() < this.token.expiresAt) return this.token.value;
    if (!this.hasAccount()) {
      throw new Error('ONEMAP_EMAIL / ONEMAP_PASSWORD not configured');
    }
    const res = await this.fetch(new URL('/api/auth/post/getToken', this.baseUrl), {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email: this.email, password: this.password }),
    });
    if (!res.ok) throw new Error(`OneMap token request failed: HTTP ${res.status}`);
    const body = await res.json();
    this.token = {
      value: body.access_token,
      expiresAt: Number(body.expiry_timestamp) * 1000 - 60_000,
    };
    return this.token.value;
  }
}
