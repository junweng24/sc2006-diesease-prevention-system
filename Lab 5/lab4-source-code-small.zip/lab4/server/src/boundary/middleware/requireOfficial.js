/** Name of the httpOnly cookie that holds the session token. */
export const SESSION_COOKIE = 'session';

/**
 * Access-control middleware (NFR-01): only lets the request through if it carries a valid,
 * unexpired official session token. Sets `req.official = {officialId, role}`.
 * @param {import('../../control/AuthController.js').AuthController} authController
 */
export function requireOfficial(authController) {
  return (req, res, next) => {
    try {
      req.official = authController.verifyToken(req.cookies?.[SESSION_COOKIE]);
      next();
    } catch (err) {
      next(err);
    }
  };
}

