import { AppError } from '../../control/errors.js';

/**
 * Wraps an async route handler so rejected promises reach {@link errorHandler}
 * (Express 4 does not do this by itself).
 * @param {(req, res, next) => Promise<void>} handler
 */
export const wrap = (handler) => (req, res, next) => {
  handler(req, res, next).catch(next);
};

/**
 * Last middleware in the chain: turns {@link AppError}s into JSON responses with the right
 * status code. Unexpected errors become a generic 500 without leaking internals.
 */
// eslint-disable-next-line no-unused-vars
export function errorHandler(err, req, res, next) {
  if (err instanceof AppError) {
    res.status(err.status).json({ error: err.message, details: err.details });
    return;
  }
  if (err?.code === 'LIMIT_FILE_SIZE') {
    res.status(422).json({ error: 'File must be JPEG format under 5MB', details: { photo: 'Too large' } });
    return;
  }
  console.error(err);
  res.status(500).json({ error: 'Something went wrong. Please try again.' });
}
