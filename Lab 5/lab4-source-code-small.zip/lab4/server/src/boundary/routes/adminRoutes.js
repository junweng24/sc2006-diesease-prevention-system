import { Router } from 'express';

import { ActivityStatus, ReportStatus } from '../../entity/enums.js';
import { wrap } from '../middleware/errorHandler.js';
import { requireOfficial } from '../middleware/requireOfficial.js';

/**
 * «boundary» REST endpoints for the officials' portal. Every route is behind
 * {@link requireOfficial} (NFR-01), and only these routes return personal data (NFR-02).
 * @param {{auth: import('../../control/AuthController.js').AuthController,
 *          reports: import('../../control/HotspotReportController.js').HotspotReportController,
 *          hotspots: import('../../control/HotspotManagementController.js').HotspotManagementController,
 *          alerts: import('../../control/PublicAlertController.js').PublicAlertController,
 *          activities: import('../../control/VolunteerActivityController.js').VolunteerActivityController}} controllers
 * @returns {Router}
 */
export function adminRoutes({ auth, reports, hotspots, alerts, activities }) {
  const router = Router();
  router.use(requireOfficial(auth));

  // FR-18 Dashboard overview
  router.get('/dashboard', wrap(async (req, res) => {
    const now = new Date();
    const [pending, active, latestAlerts, openActivities] = await Promise.all([
      reports.listReports({ status: ReportStatus.UNVERIFIED }),
      hotspots.listHotspots(),
      alerts.listPublishedAlerts(),
      activities.listActivities({ status: ActivityStatus.OPEN }, now),
    ]);
    res.json({
      pendingReports: pending.length,
      activeHotspots: active.length,
      recentAlerts: latestAlerts.slice(0, 5),
      openActivities: openActivities.length,
    });
  }));

  // UC8 Review hotspot reports
  router.get('/reports', wrap(async (req, res) => {
    res.json(await reports.listReports({ status: req.query.status }));
  }));
  router.get('/reports/:referenceId', wrap(async (req, res) => {
    res.json(await reports.getReport(req.params.referenceId));
  }));
  router.patch('/reports/:referenceId', wrap(async (req, res) => {
    const updated = await reports.reviewReport(
      req.params.referenceId, req.body.status, req.official.officialId,
      Number(req.body.version), new Date());
    res.json(updated);
  }));
  router.get('/reports/:referenceId/photo', wrap(async (req, res) => {
    // Behind requireOfficial like every admin route: photos are never public (NFR-02).
    res.set('Cache-Control', 'private, no-store');
    res.sendFile(await reports.getPhotoFile(req.params.referenceId));
  }));

  // UC17 Add / remove hotspots
  router.get('/disease-types', wrap(async (req, res) => {
    res.json(await hotspots.listDiseaseTypes());
  }));
  router.get('/hotspots', wrap(async (req, res) => {
    res.json(await hotspots.listHotspots({ diseaseType: req.query.diseaseType }));
  }));
  router.post('/hotspots', wrap(async (req, res) => {
    res.status(201).json(await hotspots.addHotspot(req.body, req.official.officialId));
  }));
  router.delete('/hotspots/:id', wrap(async (req, res) => {
    await hotspots.removeHotspot(Number(req.params.id));
    res.status(204).end();
  }));

  // UC7 Publish public alert
  router.get('/alerts', wrap(async (req, res) => {
    res.json(await alerts.listPublishedAlerts());
  }));
  router.post('/alerts/preview', (req, res) => {
    res.json(alerts.previewAlert(req.body));
  });
  router.post('/alerts', wrap(async (req, res) => {
    res.status(201).json(await alerts.publishAlert(req.body, req.official.officialId, new Date()));
  }));

  // UC9 / UC10 / UC11 Volunteer activities
  router.get('/activities', wrap(async (req, res) => {
    res.json(await activities.listActivities({ status: req.query.status }, new Date()));
  }));
  router.post('/activities', wrap(async (req, res) => {
    res.status(201).json(
      await activities.createActivity(req.body, req.official.officialId, new Date()));
  }));
  router.put('/activities/:id', wrap(async (req, res) => {
    res.json(await activities.editActivity(Number(req.params.id), req.body, new Date()));
  }));
  router.get('/activities/:id/status', wrap(async (req, res) => {
    res.json(await activities.getActivityStatus(Number(req.params.id), new Date()));
  }));
  router.get('/activities/:id/roster', wrap(async (req, res) => {
    res.json(await activities.getRoster(Number(req.params.id)));
  }));

  return router;
}
