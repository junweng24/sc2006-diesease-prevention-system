import { Router } from 'express';

import { wrap } from '../middleware/errorHandler.js';
import { SESSION_COOKIE } from '../middleware/requireOfficial.js';

/**
 * «boundary» Login / logout endpoints for officials (UC14, UC18).
 * The session token is put in an httpOnly cookie so page scripts cannot read it (XSS) and
 * SameSite=Strict so other sites cannot send it (CSRF).
 * @param {{auth: import('../../control/AuthController.js').AuthController,
 *          sessionMinutes: number, secureCookies: boolean}} options
 * @returns {Router}
 */
export function authRoutes({ auth, sessionMinutes, secureCookies }) {
  const router = Router();
  const cookieOptions = {
    httpOnly: true,
    sameSite: 'strict',
    secure: secureCookies,
    maxAge: sessionMinutes * 60_000,
  };

  router.post('/login', wrap(async (req, res) => {
    const { token, official } = await auth.login(req.body?.username, req.body?.password, new Date());
    res.cookie(SESSION_COOKIE, token, cookieOptions).json({ official });
  }));

  router.post('/logout', (req, res) => {
    auth.logout(req.cookies?.[SESSION_COOKIE]);
    res.clearCookie(SESSION_COOKIE, { ...cookieOptions, maxAge: undefined }).status(204).end();
  });

  /** Lets the SPA check on page load whether the session is still valid. */
  router.get('/me', (req, res, next) => {
    try {
      res.json(auth.verifyToken(req.cookies?.[SESSION_COOKIE]));
    } catch (err) {
      next(err);
    }
  });

  return router;
}
