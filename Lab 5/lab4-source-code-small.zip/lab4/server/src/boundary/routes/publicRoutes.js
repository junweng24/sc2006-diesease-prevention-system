import { Router } from 'express';
import multer from 'multer';

import { ValidationError } from '../../control/errors.js';
import { wrap } from '../middleware/errorHandler.js';

/** Photos are kept in memory until the controller has validated them (UC4). */
const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 10 * 1024 * 1024 } });

/**
 * Activity fields that are safe to show the public (no registrant data).
 * @param {import('../../entity/VolunteerActivity.js').VolunteerActivity} a
 */
const publicActivity = (a) => ({
  id: a.id,
  title: a.title,
  targetArea: a.targetArea,
  eventDateTime: a.eventDateTime,
  description: a.description,
  priority: a.priority,
  status: a.status,
  remainingSlots: a.remainingSlots(),
  headcountQuota: a.headcountQuota,
});

/**
 * «boundary» REST endpoints for the public website. None of them return other people's
 * personal data (NFR-02).
 * @param {{map: import('../../control/MapController.js').MapController,
 *          reports: import('../../control/HotspotReportController.js').HotspotReportController,
 *          alerts: import('../../control/PublicAlertController.js').PublicAlertController,
 *          enrollment: import('../../control/VolunteerEnrollmentController.js').VolunteerEnrollmentController,
 *          subscriptions: import('../../control/SubscriptionController.js').SubscriptionController,
 *          clinics: import('../../control/ClinicController.js').ClinicController}} controllers
 * @returns {Router}
 */
export function publicRoutes({ map, reports, alerts, enrollment, subscriptions, clinics }) {
  const router = Router();

  // UC16 View public health alerts
  router.get('/alerts', wrap(async (req, res) => {
    res.json(await alerts.listPublishedAlerts());
  }));
  router.get('/alerts/:id', wrap(async (req, res) => {
    res.json(await alerts.getAlert(Number(req.params.id)));
  }));

  // UC1 / UC2 Hotspot map + geolocation
  router.get('/map', wrap(async (req, res) => {
    res.json(await map.getMapData({ diseaseType: req.query.diseaseType }, new Date()));
  }));
  router.get('/map/search', wrap(async (req, res) => {
    res.json(await map.searchAddress(String(req.query.q ?? '')));
  }));
  router.get('/map/reverse', wrap(async (req, res) => {
    res.json(await map.reverseGeocode(Number(req.query.lat), Number(req.query.lng)));
  }));

  // UC3–UC5 Report a hotspot. Multipart form: field "report" (JSON) + optional file "photo".
  router.post('/reports', upload.single('photo'), wrap(async (req, res) => {
    let input;
    try {
      input = JSON.parse(req.body.report ?? '{}');
    } catch {
      throw new ValidationError({ report: 'Malformed report data' });
    }
    const photo = req.file
      ? { mimeType: req.file.mimetype, sizeBytes: req.file.size, buffer: req.file.buffer }
      : null;
    const referenceId = await reports.submitReport(input, photo, new Date());
    res.status(201).json({ referenceId });
  }));
  router.get('/reports/:referenceId/status', wrap(async (req, res) => {
    const r = await reports.getReport(req.params.referenceId);
    res.json({ referenceId: r.referenceId, status: r.status, submittedAt: r.submittedAt });
  }));

  // UC6 Register for a volunteer activity
  router.get('/volunteer-activities', wrap(async (req, res) => {
    const list = await enrollment.listOpenActivities(new Date());
    res.json(list.map(publicActivity));
  }));
  router.post('/volunteer-activities/:id/registrations', wrap(async (req, res) => {
    const { registration, activity } = await enrollment.register(
      Number(req.params.id), req.body, new Date());
    res.status(201).json({ registrationId: registration.id, activity: publicActivity(activity) });
  }));

  // UC15 Subscribe to public alerts
  router.post('/subscriptions', wrap(async (req, res) => {
    const s = await subscriptions.subscribe(req.body);
    res.status(201).json({ id: s.id, channels: s.channels, region: s.region });
  }));

  // UC15 Unsubscribe link. GET only reads; withdrawing consent needs the POST.
  router.get('/subscriptions/unsubscribe/:token', wrap(async (req, res) => {
    res.json(await subscriptions.getUnsubscribeStatus(req.params.token));
  }));
  router.post('/subscriptions/unsubscribe/:token', wrap(async (req, res) => {
    await subscriptions.unsubscribe(req.params.token, new Date());
    res.json({ unsubscribed: true });
  }));

  // UC19 Locate nearest clinic. ?lat=&lng= comes from UC2 (GPS or address search).
  router.get('/clinics', wrap(async (req, res) => {
    res.json(await clinics.findNearest(
      { latitude: req.query.lat, longitude: req.query.lng }, new Date()));
  }));

  return router;
}
