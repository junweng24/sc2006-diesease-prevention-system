/**
 * «interface» A way of delivering a message to a person (Strategy pattern, FR-26/27).
 * {@link NotificationService} only depends on this interface. To add e.g. WhatsApp, write a new
 * subclass and register it in ServerApp; nothing else changes.
 */
export class NotificationChannel {
  /** @param {string} type a ChannelType value */
  constructor(type) {
    if (new.target === NotificationChannel) {
      throw new Error('NotificationChannel is an interface; use a subclass');
    }
    this.type = type;
  }

  /**
   * Delivers one message.
   * @abstract
   * @param {string} recipient phone number or email address
   * @param {{subject: string, text: string, smsText?: string}} message
   * @returns {Promise<void>}
   * @throws {Error} if the gateway rejects the message
   */
  // eslint-disable-next-line no-unused-vars
  async send(recipient, message) {
    throw new Error(`${this.constructor.name}.send() not implemented`);
  }
}
