import nodemailer from 'nodemailer';

import { ChannelType } from '../../entity/enums.js';
import { NotificationChannel } from './NotificationChannel.js';

/**
 * «boundary» Sends email through an SMTP server using Nodemailer (FR-26).
 *
 * If no SMTP account is configured in .env, a throw-away Ethereal (https://ethereal.email)
 * inbox is created on first use. Ethereal captures mail without delivering it, and the server
 * terminal prints a link to view each message, so the demo needs no set-up. If even that is
 * not possible (offline), the email is printed to the terminal like the console SMS.
 */
export class EmailChannel extends NotificationChannel {
  /** @param {{host: string, port: number, user?: string, pass?: string, from: string}} smtp */
  constructor(smtp) {
    super(ChannelType.EMAIL);
    this.smtp = smtp;
    this.from = smtp.from ?? 'Disease Prevention System <no-reply@example.com>';
    /** @type {Promise<{transporter: import('nodemailer').Transporter|null, isTest: boolean}>|null} */
    this.ready = null;
  }

  /** @override */
  async send(recipient, message) {
    const { transporter, isTest } = await this.#getTransporter();
    if (!transporter) {
      console.log(`[EMAIL → ${recipient}] ${message.subject}\n  ${message.text}`);
      return;
    }
    const info = await transporter.sendMail({
      from: this.from,
      to: recipient,
      subject: message.subject,
      text: message.text,
    });
    if (isTest) {
      console.log(`[EMAIL → ${recipient}] ${message.subject}\n  view: ${nodemailer.getTestMessageUrl(info)}`);
    }
  }

  /** Builds the SMTP transport once: the configured account, else an Ethereal test inbox. */
  #getTransporter() {
    this.ready ??= (async () => {
      if (this.smtp.user) {
        return {
          transporter: nodemailer.createTransport({
            host: this.smtp.host,
            port: this.smtp.port,
            auth: { user: this.smtp.user, pass: this.smtp.pass },
          }),
          isTest: false,
        };
      }
      try {
        const account = await nodemailer.createTestAccount();
        console.log(`No SMTP account in .env: emails go to a test inbox (${account.user}).`);
        return {
          transporter: nodemailer.createTransport({
            host: account.smtp.host,
            port: account.smtp.port,
            secure: account.smtp.secure,
            auth: { user: account.user, pass: account.pass },
          }),
          isTest: true,
        };
      } catch (err) {
        console.warn('Could not create a test email inbox, printing emails instead:', err.message);
        return { transporter: null, isTest: false };
      }
    })();
    return this.ready;
  }
}
