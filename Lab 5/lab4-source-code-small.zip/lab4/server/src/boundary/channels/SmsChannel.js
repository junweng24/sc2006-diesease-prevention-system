import { ChannelType } from '../../entity/enums.js';
import { NotificationChannel } from './NotificationChannel.js';

/**
 * «boundary» Sends SMS through an SMS gateway (FR-27).
 * With `provider: 'console'` (the default) messages are printed to the terminal instead of
 * being sent, so development and the demo cost nothing.
 */
export class SmsChannel extends NotificationChannel {
  /** @param {{provider: string}} options */
  constructor({ provider }) {
    super(ChannelType.SMS);
    this.provider = provider;
  }

  /** @override */
  async send(recipient, message) {
    const text = message.smsText ?? message.text;
    if (this.provider === 'console') {
      console.log(`[SMS → ${recipient}] ${text}`);
      return;
    }
    // TODO(FR-27): call a real gateway (e.g. Twilio trial) here and throw on failure.
    throw new Error(`SMS provider "${this.provider}" is not implemented`);
  }
}
