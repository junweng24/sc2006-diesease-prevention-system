import { existsSync } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

import cookieParser from 'cookie-parser';
import express from 'express';

import { DataGovAdapter } from './boundary/adapters/DataGovAdapter.js';
import { OneMapAdapter } from './boundary/adapters/OneMapAdapter.js';
import { EmailChannel } from './boundary/channels/EmailChannel.js';
import { SmsChannel } from './boundary/channels/SmsChannel.js';
import { errorHandler } from './boundary/middleware/errorHandler.js';
import { adminRoutes } from './boundary/routes/adminRoutes.js';
import { authRoutes } from './boundary/routes/authRoutes.js';
import { publicRoutes } from './boundary/routes/publicRoutes.js';
import { Config } from './config/Config.js';
import { AuthController } from './control/AuthController.js';
import { ClinicController } from './control/ClinicController.js';
import { PasswordHasher } from './control/auth/PasswordHasher.js';
import { TokenService } from './control/auth/TokenService.js';
import { HotspotManagementController } from './control/HotspotManagementController.js';
import { HotspotReportController } from './control/HotspotReportController.js';
import { MapController } from './control/MapController.js';
import { NotificationService } from './control/NotificationService.js';
import { PublicAlertController } from './control/PublicAlertController.js';
import { SubscriptionController } from './control/SubscriptionController.js';
import { VolunteerActivityController } from './control/VolunteerActivityController.js';
import { VolunteerEnrollmentController } from './control/VolunteerEnrollmentController.js';
import { ClinicCache } from './repository/ClinicCache.js';
import { ClusterCacheRepository } from './repository/ClusterCacheRepository.js';
import { Database } from './repository/Database.js';
import { HotspotReportRepository } from './repository/HotspotReportRepository.js';
import { HotspotRepository } from './repository/HotspotRepository.js';
import { NotificationLogRepository } from './repository/NotificationLogRepository.js';
import { OfficialRepository } from './repository/OfficialRepository.js';
import { PublicAlertRepository } from './repository/PublicAlertRepository.js';
import { SubscriptionRepository } from './repository/SubscriptionRepository.js';
import { VolunteerActivityRepository } from './repository/VolunteerActivityRepository.js';
import { VolunteerRegistrationRepository } from './repository/VolunteerRegistrationRepository.js';

/** Production build of the React client (`npm run build` in client/). */
const CLIENT_DIST = fileURLToPath(new URL('../../client/dist', import.meta.url));

/**
 * «startup» Performs system initialisation (Fox p. 341): creates every object, connects them
 * through their constructors (composition root / dependency injection) and starts the HTTP
 * server. This is the only class that knows the concrete classes of every layer.
 */
export class ServerApp {
  constructor() {
    this.config = Config.getInstance();
    this.expressApp = express();
    this.repos = {};
    this.controllers = {};
  }

  /**
   * Start-up sequence (see docs/05-design-issues.md §5.3).
   * @returns {Promise<void>}
   */
  async start() {
    this.db = Database.getInstance(this.config.databaseFile); // also applies db/schema.sql
    await this.db.ping(); // fail fast if the database cannot be read
    this.buildRepositories();
    this.buildControllers();
    this.registerRoutes();
    this.httpServer = this.expressApp.listen(this.config.port, () => {
      const site = existsSync(CLIENT_DIST) ? ' (website + API)' : ' (API only; run the client with npm run dev)';
      console.log(`Server listening on http://localhost:${this.config.port}${site}`);
    });
    this.registerShutdownHooks();
  }

  /** Creates one repository (container) per persistent entity. */
  buildRepositories() {
    const db = this.db;
    this.repos = {
      officials: new OfficialRepository(db),
      reports: new HotspotReportRepository(db),
      hotspots: new HotspotRepository(db),
      clusterCache: new ClusterCacheRepository(db),
      alerts: new PublicAlertRepository(db),
      subscriptions: new SubscriptionRepository(db),
      activities: new VolunteerActivityRepository(db),
      registrations: new VolunteerRegistrationRepository(db),
      notificationLogs: new NotificationLogRepository(db),
    };
  }

  /** Creates boundary adapters and control objects and wires the Observer listeners. */
  buildControllers() {
    const { config, db, repos } = this;

    const oneMap = new OneMapAdapter(config.oneMap);
    const dataGov = new DataGovAdapter({
      dengueDatasetId: config.dataGovDengueDatasetId,
      chasDatasetId: config.dataGovChasDatasetId,
    });
    const notificationService = new NotificationService({
      channels: [new SmsChannel({ provider: config.smsProvider }), new EmailChannel(config.smtp)],
      subscriptionRepo: repos.subscriptions,
      logRepo: repos.notificationLogs,
      publicBaseUrl: config.publicBaseUrl,
    });

    this.controllers = {
      auth: new AuthController({
        officialRepo: repos.officials,
        hasher: new PasswordHasher(),
        tokens: new TokenService(config.jwtSecret, config.jwtExpiresMinutes),
        maxFailedLogins: config.maxFailedLogins,
        lockoutMinutes: config.lockoutMinutes,
      }),
      map: new MapController({
        dataGov, oneMap, hotspotRepo: repos.hotspots, clusterCache: repos.clusterCache,
      }),
      reports: new HotspotReportController({
        db, reportRepo: repos.reports, hotspotRepo: repos.hotspots, uploadDir: config.uploadDir,
      }),
      hotspots: new HotspotManagementController({ hotspotRepo: repos.hotspots }),
      alerts: new PublicAlertController({
        alertRepo: repos.alerts, listeners: [notificationService], smsPreviewer: notificationService,
      }),
      subscriptions: new SubscriptionController({
        subscriptionRepo: repos.subscriptions, notificationService,
      }),
      activities: new VolunteerActivityController({
        activityRepo: repos.activities,
        registrationRepo: repos.registrations,
        listeners: [notificationService],
      }),
      enrollment: new VolunteerEnrollmentController({
        db, activityRepo: repos.activities, registrationRepo: repos.registrations,
      }),
      clinics: new ClinicController({ clinicCache: new ClinicCache(dataGov) }),
    };
  }

  /**
   * Mounts the HTTP boundary: public, auth and admin route modules (NFR-07). If the client has
   * been built, the same server also serves the website, so the whole system runs on one port.
   */
  registerRoutes() {
    const app = this.expressApp;
    const c = this.controllers;
    app.use(express.json({ limit: '100kb' }));
    app.use(cookieParser());
    app.use('/api', publicRoutes(c));
    app.use('/api/auth', authRoutes({
      auth: c.auth,
      sessionMinutes: this.config.jwtExpiresMinutes,
      secureCookies: process.env.NODE_ENV === 'production',
    }));
    app.use('/api/admin', adminRoutes(c));
    app.use('/api', (req, res) => res.status(404).json({ error: 'Not found' }));
    if (existsSync(CLIENT_DIST)) {
      app.use(express.static(CLIENT_DIST));
      // Client-side routes (e.g. /hotspots, /admin/reports) all load the single-page app.
      app.get('*', (req, res) => res.sendFile(path.join(CLIENT_DIST, 'index.html')));
    }
    app.use(errorHandler);
  }

  /** Graceful shutdown: stop accepting requests, then close the DB pool. */
  registerShutdownHooks() {
    const shutdown = () => {
      console.log('Shutting down...');
      this.httpServer.close(() => this.db.close().finally(() => process.exit(0)));
    };
    process.on('SIGINT', shutdown);
    process.on('SIGTERM', shutdown);
  }
}
