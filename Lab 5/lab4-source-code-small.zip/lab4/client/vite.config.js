import react from '@vitejs/plugin-react';
import { defineConfig } from 'vite';

// During development the React app runs on :5173 and forwards /api calls to the Express API.
export default defineConfig({
  plugins: [react()],
  server: {
    port: 5173,
    proxy: { '/api': 'http://localhost:3000' },
  },
});
