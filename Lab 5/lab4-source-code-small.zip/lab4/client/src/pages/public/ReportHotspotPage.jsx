/**
 * «boundary» Report a Hotspot form (UC3), with optional photo (UC4) and contact details (UC5).
 * Required fields are marked with * and optional sections are labelled (NFR-10).
 */
import { useState } from 'react';
import { useNavigate } from 'react-router-dom';

import { api } from '../../api/ApiClient.js';
import AddressSearch from '../../components/AddressSearch.jsx';
import ContactDetailsSection from '../../components/ContactDetailsSection.jsx';
import HotspotMap, { SINGAPORE_CENTER, STREET_ZOOM } from '../../components/HotspotMap.jsx';
import PhotoUploader from '../../components/PhotoUploader.jsx';
import { SITE_TYPES } from '../../constants.js';
import { describeLocation } from '../../utils/format.js';

const MAX_DESCRIPTION = 1000;

export default function ReportHotspotPage() {
  const navigate = useNavigate();
  const [location, setLocation] = useState(null);
  const [view, setView] = useState({ center: SINGAPORE_CENTER, zoom: undefined });
  const [siteType, setSiteType] = useState('');
  const [description, setDescription] = useState('');
  const [photo, setPhoto] = useState(null);
  const [contact, setContact] = useState({});
  const [errors, setErrors] = useState({});
  const [submitting, setSubmitting] = useState(false);

  const clearError = (field) => setErrors((e) => ({ ...e, [field]: undefined, form: undefined }));

  // UC2: a point without an address (GPS or map click) is turned into one through OneMap.
  const placePin = async (loc, recentre) => {
    setLocation(loc);
    clearError('location');
    if (recentre) setView({ center: [loc.latitude, loc.longitude], zoom: STREET_ZOOM });
    if (loc.address) return;
    try {
      const found = await api.reverseGeocode(loc.latitude, loc.longitude);
      if (found.address) setLocation((cur) => (cur?.latitude === loc.latitude ? found : cur));
    } catch (err) {
      if (err.details?.location) setErrors((e) => ({ ...e, location: err.details.location }));
    }
  };

  // UC3 steps 6–7
  const submit = async (e) => {
    e.preventDefault();
    setSubmitting(true);
    try {
      const { referenceId } = await api.submitReport(
        { location, siteType, description, contact }, photo);
      navigate(`/report/confirmation/${referenceId}`);
    } catch (err) {
      // UC3 3a: highlight the fields; nothing is stored
      setErrors(err.details && Object.keys(err.details).length ? err.details : { form: err.message });
      window.scrollTo({ top: 0, behavior: 'smooth' });
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="page">
      <div className="page-header">
        <div>
          <h1>Report a hotspot</h1>
          <p>Report stagnant water or a possible mosquito breeding site to NEA officials.</p>
        </div>
      </div>

      <form onSubmit={submit} noValidate className="form">
        {errors.form && <p className="banner-error">{errors.form}</p>}
        {Object.keys(errors).some((k) => errors[k]) && !errors.form && (
          <p className="banner-error">Please correct the highlighted fields.</p>
        )}

        <div className="report-layout">
        <section className="card form">
          <h2>1. Location <span className="req">*</span></h2>
          <AddressSearch onSelect={(loc) => placePin(loc, true)} />
          <p className="small muted" style={{ margin: 0 }}>…or click the exact spot on the map.</p>
          <HotspotMap
            pin={location} pinLabel="Reported location" onPick={(lat, lng) => placePin({ latitude: lat, longitude: lng, address: null }, false)}
            center={view.center} zoom={view.zoom}
          />
          {location && <p className="banner banner-info" style={{ margin: 0 }}>Selected: {describeLocation(location)}</p>}
          {errors.location && <p className="field-error">{errors.location}</p>}
        </section>

        <div className="form">
        <section className="card form">
          <h2>2. Details</h2>
          <label className="field">
            <span>Type of breeding site <span className="req">*</span></span>
            <select
              value={siteType} className={errors.siteType ? 'input-error' : ''}
              onChange={(e) => { setSiteType(e.target.value); clearError('siteType'); }}
            >
              <option value="">Select…</option>
              {SITE_TYPES.map(([value, label]) => <option key={value} value={value}>{label}</option>)}
            </select>
            {errors.siteType && <p className="field-error">{errors.siteType}</p>}
          </label>
          <label className="field">
            <span>Description <span className="req">*</span></span>
            <textarea
              value={description} maxLength={MAX_DESCRIPTION}
              className={errors.description ? 'input-error' : ''}
              placeholder="e.g. Pails of water left at the void deck of Blk 123, lots of mosquitoes in the evening"
              onChange={(e) => { setDescription(e.target.value); clearError('description'); }}
            />
            <span className="field-hint">{description.length}/{MAX_DESCRIPTION}</span>
            {errors.description && <p className="field-error">{errors.description}</p>}
          </label>
        </section>

        <section className="card form">
          <h2>3. Photo <span className="muted small">(optional)</span></h2>
          <PhotoUploader photo={photo} onChange={(f) => { setPhoto(f); clearError('photo'); }} error={errors.photo} />
        </section>

        <section className="card form">
          <h2>4. Contact details <span className="muted small">(optional)</span></h2>
          <ContactDetailsSection value={contact} onChange={setContact} errors={errors} />
        </section>

        <div className="form-actions">
          <button type="submit" className="btn btn-primary" disabled={submitting}>
            {submitting ? 'Submitting…' : 'Submit report'}
          </button>
          <span className="small muted">Reports are reviewed by officials before appearing on the map.</span>
        </div>
        </div>
        </div>
      </form>
    </div>
  );
}
