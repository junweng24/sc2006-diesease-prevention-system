/**
 * «boundary» Unsubscribe page, opened from the link in a notification (UC15, PDPA).
 * Opening the link changes nothing, because mail scanners also open links; the person confirms
 * with one button. Every outcome has its own result, and only a successful request says
 * "unsubscribed".
 */
import { useCallback, useEffect, useState } from 'react';
import { Link, useParams } from 'react-router-dom';

import { api } from '../../api/ApiClient.js';

/** Result pages for each final state of the link. */
const RESULTS = {
  done: {
    title: 'You have been unsubscribed',
    text: 'Your consent is withdrawn and your contact details are removed from our subscriber list. You will not receive any more alerts or volunteer news.',
  },
  already: {
    title: 'Already unsubscribed',
    text: 'This link has already been used, so there is nothing more to do. You will not receive any more alerts or volunteer news from that subscription.',
  },
  invalid: {
    title: 'This link is not valid',
    text: 'We could not find a subscription for this link, so nothing has changed. Please check that you opened the whole link from your message.',
  },
};

export default function UnsubscribePage() {
  const { token } = useParams();
  const [state, setState] = useState('loading'); // loading | confirm | error | a key of RESULTS
  const [submitting, setSubmitting] = useState(false);

  /** Maps an API failure to the page to show; anything unexpected can be tried again. */
  const showFailure = (err) => {
    if (err.status === 404) setState('invalid');
    else if (err.status === 409) setState('already');
    else setState('error');
  };

  const load = useCallback(() => {
    setState('loading');
    return api.getUnsubscribeStatus(token)
      .then(({ alreadyUnsubscribed }) => setState(alreadyUnsubscribed ? 'already' : 'confirm'))
      .catch(showFailure);
  }, [token]);

  useEffect(() => { load(); }, [load]);

  const confirm = async () => {
    setSubmitting(true);
    try {
      await api.unsubscribe(token);
      setState('done');
    } catch (err) {
      showFailure(err);
    } finally {
      setSubmitting(false);
    }
  };

  const result = RESULTS[state];
  return (
    <div className="page">
      <section className="card center">
        {state === 'loading' && <p className="muted">Checking your link…</p>}

        {state === 'confirm' && (
          <>
            <h1>Unsubscribe from health alerts?</h1>
            <p>
              You will stop receiving alerts and volunteer news, and your contact details will be
              removed from our subscriber list.
            </p>
            <p className="muted small">
              If you registered for a volunteer activity, we will still tell you about changes to it.
            </p>
            <div className="row" style={{ justifyContent: 'center' }}>
              <button type="button" className="btn btn-danger" onClick={confirm} disabled={submitting}>
                {submitting ? 'Unsubscribing…' : 'Unsubscribe'}
              </button>
              <Link to="/" className="btn btn-ghost">Keep my subscription</Link>
            </div>
          </>
        )}

        {state === 'error' && (
          <>
            <h1>We could not complete this</h1>
            <p className="banner-error">
              Something went wrong, so you may still be subscribed. Please try again.
            </p>
            <button type="button" className="btn btn-primary" onClick={load}>Try again</button>
          </>
        )}

        {result && (
          <>
            <h1>{result.title}</h1>
            <p>{result.text}</p>
            <div className="row" style={{ justifyContent: 'center' }}>
              <Link to="/" className="btn btn-primary">Back to alerts</Link>
              <Link to="/subscribe" className="btn">Subscribe again</Link>
            </div>
          </>
        )}
      </section>
    </div>
  );
}
