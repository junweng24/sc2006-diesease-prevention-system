/**
 * «boundary» Clinic Locator page (UC19 Locate Nearest Clinic, includes UC2 geolocation lookup).
 * Shows the nearest CHAS clinics on the map and in a list sorted by distance.
 */
import { useEffect, useState } from 'react';

import { api } from '../../api/ApiClient.js';
import AddressSearch from '../../components/AddressSearch.jsx';
import HotspotMap, { SINGAPORE_CENTER } from '../../components/HotspotMap.jsx';
import { describeLocation, formatDateTime } from '../../utils/format.js';

export default function ClinicLocatorPage() {
  const [origin, setOrigin] = useState(null);
  const [result, setResult] = useState(null);
  const [notice, setNotice] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  // UC19 step 1 → UC2 step 1: ask for GPS; fall back to an address search if denied (UC2 2a).
  useEffect(() => {
    navigator.geolocation?.getCurrentPosition(
      (pos) => setOrigin({ latitude: pos.coords.latitude, longitude: pos.coords.longitude }),
      () => setNotice('Automatic location detection is disabled. Search for an address instead.'),
    );
  }, []);

  // UC19 steps 2–4: reload the nearest clinics whenever the location changes.
  useEffect(() => {
    if (!origin) return;
    setLoading(true);
    api.getNearestClinics(origin.latitude, origin.longitude)
      .then((r) => { setResult(r); setError(''); })
      .catch((err) => { setResult(null); setError(err.message); }) // UC19 2a, or outside Singapore
      .finally(() => setLoading(false));
  }, [origin]);

  const center = origin ? [origin.latitude, origin.longitude] : SINGAPORE_CENTER;
  const zoom = !origin ? undefined : (result?.radiusKm ?? 2) <= 2 ? 15 : (result?.radiusKm ?? 2) <= 5 ? 13 : 12;

  return (
    <div className="page">
      <div className="page-header">
        <div>
          <h1>Nearby CHAS clinics</h1>
          <p>Feeling unwell with a fever? Find the nearest CHAS GP clinic (MOH data from data.gov.sg).</p>
        </div>
      </div>
      {notice && !origin && <p className="banner banner-info">{notice}</p>}
      {error && <p className="banner-error">{error}</p>}
      {result?.isStale && result.updatedAt && (
        <p className="banner banner-warning">
          Live clinic data unavailable. Showing the list from {formatDateTime(result.updatedAt)}.
        </p>
      )}

      <div className="card card-tight" style={{ marginBottom: 12 }}>
        <AddressSearch onSelect={setOrigin} />
      </div>

      <div className="split">
        <div className="card" style={{ maxHeight: '62vh', overflowY: 'auto' }}>
          {!origin && <p className="muted">Search for an address or use your location to see clinics.</p>}
          {loading && <p className="muted">Finding clinics…</p>}
          {result && !loading && (
            <>
              <p className="small muted">
                {result.clinics.length} clinic(s) within {result.radiusKm} km of{' '}
                {origin?.address ? describeLocation(origin) : 'your location'}
                {result.radiusKm > 2 && ' (search widened because none were closer)'}.
              </p>
              <ol className="list-plain">
                {result.clinics.map((c, i) => (
                  <li key={c.code}>
                    <div className="row" style={{ justifyContent: 'space-between', alignItems: 'flex-start' }}>
                      <strong>{i + 1}. {c.name}</strong>
                      <span className="badge">{c.distanceKm} km</span>
                    </div>
                    <div className="small muted">{c.location.address}</div>
                    <div className="row small" style={{ marginTop: 4 }}>
                      {c.phone && <a href={`tel:${c.phone}`}>Tel: {c.phone}</a>}
                      <a
                        href={`https://www.google.com/maps/dir/?api=1&destination=${c.location.latitude},${c.location.longitude}`}
                        target="_blank" rel="noopener noreferrer"
                      >
                        Directions
                      </a>
                    </div>
                  </li>
                ))}
              </ol>
            </>
          )}
        </div>
        <HotspotMap
          clinics={result?.clinics ?? []} center={center} zoom={zoom}
          pin={origin} pinLabel="Search location" legend
        />
      </div>
    </div>
  );
}
