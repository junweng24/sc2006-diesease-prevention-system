/**
 * «boundary» Public Alerts (Home) page: latest public health alerts coloured by severity
 * (UC16, FR-02), with links to the other public use cases.
 */
import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';

import { api } from '../../api/ApiClient.js';
import Badge from '../../components/Badge.jsx';
import { REGIONS, regionLabel } from '../../constants.js';
import { formatDateTime } from '../../utils/format.js';

const QUICK_LINKS = [
  ['View hotspot map', '/hotspots'],
  ['Report a hotspot', '/report'],
  ['Volunteer for an activity', '/volunteer'],
  ['Find a nearby clinic', '/clinics'],
  ['Subscribe to alerts', '/subscribe'],
];

export default function HomePage() {
  const [alerts, setAlerts] = useState(null);
  const [region, setRegion] = useState('ALL');
  const [error, setError] = useState('');

  const load = () => {
    setError('');
    api.getAlerts().then(setAlerts).catch(() => setError('Could not load alerts.'));
  };
  useEffect(load, []);

  // An alert for "ALL" regions is relevant to everyone.
  const shown = (alerts ?? []).filter(
    (a) => region === 'ALL' || a.targetRegion === 'ALL' || a.targetRegion === region);

  return (
    <div className="page">
      <div className="home-layout">
        <section>
          <div className="page-header">
            <div>
              <h1>Public Health Alerts</h1>
              <p>Latest alerts published by health officials.</p>
            </div>
            <label className="row small">
              <span>Region:</span>
              <select value={region} onChange={(e) => setRegion(e.target.value)} style={{ width: 'auto' }}>
                {REGIONS.map((r) => <option key={r} value={r}>{regionLabel(r)}</option>)}
              </select>
            </label>
          </div>

          {error && (
            <p className="banner-error">
              {error} <button type="button" className="btn btn-sm" onClick={load}>Retry</button>
            </p>
          )}
          {!alerts && !error && <p className="muted">Loading alerts…</p>}
          {alerts && shown.length === 0 && <div className="card empty">No active alerts in your area.</div>}
          <div className="stack">
            {shown.map((a) => (
              <Link key={a.id} to={`/alerts/${a.id}`} className={`card card-link alert-card sev-${a.severity}`}>
                <div className="row" style={{ marginBottom: 4 }}>
                  <Badge value={a.severity} />
                  <span className="small muted">
                    {a.category} | {regionLabel(a.targetRegion)} | {formatDateTime(a.publishedAt)}
                  </span>
                </div>
                <h3>{a.title}</h3>
                <p className="muted" style={{ margin: 0 }}>
                  {a.body.length > 220 ? `${a.body.slice(0, 220)}…` : a.body}
                </p>
              </Link>
            ))}
          </div>
        </section>

        <aside className="stack">
          <div className="card">
            <h3>Quick links</h3>
            <ul className="link-list">
              {QUICK_LINKS.map(([label, to]) => <li key={to}><Link to={to}>{label}</Link></li>)}
            </ul>
          </div>
          <div className="card">
            <h3>Prevention tips</h3>
            <ul className="tips">
              <li>Remove stagnant water at home every week.</li>
              <li>Turn over pails and clear blocked gutters.</li>
              <li>Use insect repellent when outdoors.</li>
              <li>See a doctor if you have a sudden high fever.</li>
            </ul>
          </div>
        </aside>
      </div>
    </div>
  );
}
