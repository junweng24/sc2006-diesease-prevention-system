/**
 * «boundary» Volunteer registration form (UC6 steps 2–5, FR-14..16).
 */
import { useEffect, useState } from 'react';
import { Link, useLocation, useParams } from 'react-router-dom';

import { api } from '../../api/ApiClient.js';
import { formatDateTime } from '../../utils/format.js';

export default function VolunteerRegistrationForm() {
  const { activityId } = useParams();
  const passed = useLocation().state?.activity; // passed from VolunteerPage when available
  const [activity, setActivity] = useState(passed ?? null);
  const [form, setForm] = useState({ name: '', phone: '', email: '', consentGiven: false });
  const [errors, setErrors] = useState({});
  const [result, setResult] = useState(null);
  const [submitting, setSubmitting] = useState(false);

  // Opened from a link or bookmark: look the activity up.
  useEffect(() => {
    if (passed) return;
    api.getVolunteerActivities()
      .then((list) => setActivity(list.find((a) => String(a.id) === activityId) ?? null))
      .catch(() => {});
  }, [activityId, passed]);

  const set = (field) => (e) => {
    setForm({ ...form, [field]: e.target.type === 'checkbox' ? e.target.checked : e.target.value });
    setErrors((er) => ({ ...er, [field]: undefined, form: undefined }));
  };

  const submit = async (e) => {
    e.preventDefault();
    setSubmitting(true);
    try {
      setResult(await api.registerVolunteer(activityId, form));
    } catch (err) {
      // UC6 3a field errors, or 2a "Activity quota full" / already registered
      setErrors(err.details && Object.keys(err.details).length ? err.details : { form: err.message });
    } finally {
      setSubmitting(false);
    }
  };

  if (result) {
    const a = result.activity;
    return (
      <div className="page">
        <section className="card center">
          <h1>You&apos;re registered!</h1>
          <p><strong>{a.title}</strong></p>
          <p>Area: {a.targetArea}<br />Date: {formatDateTime(a.eventDateTime)}</p>
          <p className="small muted">Activity ID {a.id} · registration no. {result.registrationId}. We will contact you if anything changes.</p>
          <Link to="/volunteer" className="btn btn-primary">Back to activities</Link>
        </section>
      </div>
    );
  }

  const input = (field, label, props = {}) => (
    <label className="field">
      <span>{label} <span className="req">*</span></span>
      <input value={form[field]} onChange={set(field)} className={errors[field] ? 'input-error' : ''} {...props} />
      {errors[field] && <p className="field-error">{errors[field]}</p>}
    </label>
  );

  return (
    <div className="page">
      <Link to="/volunteer" className="back-link">&lt; All activities</Link>
      <form onSubmit={submit} noValidate className="card form">
        <div>
          <h1>Register{activity ? ` for ${activity.title}` : ''}</h1>
          {activity && (
            <p className="muted">
              Area: {activity.targetArea} | Date: {formatDateTime(activity.eventDateTime)} | {activity.remainingSlots} slot(s) left
            </p>
          )}
        </div>
        {errors.form && <p className="banner-error">{errors.form}</p>}
        {input('name', 'Full name', { autoComplete: 'name' })}
        <div className="grid grid-2">
          {input('phone', 'Phone', { inputMode: 'tel', placeholder: '8 digits', autoComplete: 'tel' })}
          {input('email', 'Email', { type: 'email', autoComplete: 'email' })}
        </div>
        <label className="check">
          <input type="checkbox" checked={form.consentGiven} onChange={set('consentGiven')} />
          <span>I agree to my details being used to coordinate this activity (PDPA) <span className="req">*</span></span>
        </label>
        {errors.consentGiven && <p className="field-error">{errors.consentGiven}</p>}
        <div className="form-actions">
          <button type="submit" className="btn btn-primary" disabled={submitting}>
            {submitting ? 'Submitting…' : 'Submit registration'}
          </button>
          <Link to="/volunteer" className="btn btn-ghost">Cancel</Link>
        </div>
      </form>
    </div>
  );
}
