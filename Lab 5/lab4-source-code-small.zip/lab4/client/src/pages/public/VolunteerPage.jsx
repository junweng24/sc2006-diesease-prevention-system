/**
 * «boundary» Become a Volunteer page: lists upcoming activities and open slots (UC6 step 1).
 */
import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';

import { api } from '../../api/ApiClient.js';
import Badge from '../../components/Badge.jsx';
import { formatDateTime } from '../../utils/format.js';

export default function VolunteerPage() {
  const [activities, setActivities] = useState(null);
  const [error, setError] = useState('');

  useEffect(() => {
    api.getVolunteerActivities().then(setActivities).catch((e) => setError(e.message));
  }, []);

  return (
    <div className="page">
      <div className="page-header">
        <div>
          <h1>Become a volunteer</h1>
          <p>Help NEA officers inspect estates and clear breeding sites. No experience needed.</p>
        </div>
      </div>
      {error && <p className="banner-error">{error}</p>}
      {!activities && !error && <p className="muted">Loading activities…</p>}
      {activities?.length === 0 && <div className="card empty">No upcoming activities right now. Check back soon!</div>}

      <div className="grid grid-3">
        {activities?.map((a) => {
          const taken = a.headcountQuota - a.remainingSlots;
          const percent = Math.round((taken / a.headcountQuota) * 100);
          return (
            <article key={a.id} className="card" style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
              <div className="row">
                <Badge value={a.status} label={a.status === 'OPEN' ? 'Open' : 'Full'} />
                {a.priority === 'HIGH' && <Badge value="HIGH" label="High priority" />}
              </div>
              <h3 style={{ margin: 0 }}>{a.title}</h3>
              <div className="small">
                <div><b>Area:</b> {a.targetArea}</div>
                <div><b>Date:</b> {formatDateTime(a.eventDateTime)}</div>
              </div>
              {a.description && <p className="small muted" style={{ margin: 0 }}>{a.description}</p>}
              <div className="spacer" />
              <div>
                <div className="row small" style={{ justifyContent: 'space-between', marginBottom: 4 }}>
                  <span>{a.remainingSlots} of {a.headcountQuota} slots left</span>
                  <span className="muted">{percent}% filled</span>
                </div>
                <div className={`meter${a.remainingSlots === 0 ? ' meter-full' : ''}`}><span style={{ width: `${percent}%` }} /></div>
              </div>
              {a.status === 'OPEN'
                ? <Link to={`/volunteer/${a.id}/register`} state={{ activity: a }} className="btn btn-primary btn-block">Register</Link>
                : <button type="button" className="btn btn-block" disabled>Activity quota full</button>}
            </article>
          );
        })}
      </div>
    </div>
  );
}
