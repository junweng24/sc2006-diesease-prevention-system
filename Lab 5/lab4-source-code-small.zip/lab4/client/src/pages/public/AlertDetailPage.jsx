/**
 * «boundary» Alert Detail page: full content of one alert (UC16 step 2, FR-03).
 */
import { useEffect, useState } from 'react';
import { Link, useParams } from 'react-router-dom';

import { api } from '../../api/ApiClient.js';
import Badge from '../../components/Badge.jsx';
import { regionLabel } from '../../constants.js';
import { formatDateTime } from '../../utils/format.js';

export default function AlertDetailPage() {
  const { id } = useParams();
  const [alert, setAlert] = useState(null);
  const [error, setError] = useState('');

  useEffect(() => {
    api.getAlert(id).then(setAlert).catch((e) => setError(e.message));
  }, [id]);

  return (
    <div className="page">
      <Link to="/" className="back-link">&lt; Back to alerts</Link>
      {error && <p className="banner-error">{error}</p>}
      {!alert && !error && <p className="muted">Loading…</p>}
      {alert && (
        <article className={`card alert-card sev-${alert.severity}`}>
          <div className="row" style={{ marginBottom: 10 }}>
            <Badge value={alert.severity} />
            <span className="badge">{alert.category}</span>
            <span className="badge">{regionLabel(alert.targetRegion)}</span>
          </div>
          <h1>{alert.title}</h1>
          <p className="small muted">Published {formatDateTime(alert.publishedAt)}</p>
          <p style={{ whiteSpace: 'pre-wrap' }}>{alert.body}</p>
          <hr style={{ border: 0, borderTop: '1px solid var(--line)', margin: '20px 0' }} />
          <div className="row">
            <Link to="/clinics" className="btn">Find a nearby clinic</Link>
            <Link to="/hotspots" className="btn">View hotspot map</Link>
            <Link to="/subscribe" className="btn btn-ghost">Get alerts like this</Link>
          </div>
        </article>
      )}
    </div>
  );
}
