/**
 * «boundary» Subscribe to Alerts page (UC15, FR-24/26/27).
 */
import { useState } from 'react';
import { Link } from 'react-router-dom';

import { api } from '../../api/ApiClient.js';
import { REGIONS, regionLabel } from '../../constants.js';

export default function SubscribePage() {
  const [form, setForm] = useState({
    channels: [], phone: '', email: '', region: 'ALL', wantsVolunteerNews: false, consentGiven: false,
  });
  const [errors, setErrors] = useState({});
  const [done, setDone] = useState(null);
  const [submitting, setSubmitting] = useState(false);

  const toggleChannel = (ch) => (e) => {
    setForm({
      ...form,
      channels: e.target.checked ? [...form.channels, ch] : form.channels.filter((c) => c !== ch),
    });
    setErrors((er) => ({ ...er, channels: undefined }));
  };
  const set = (field) => (e) => {
    setForm({ ...form, [field]: e.target.type === 'checkbox' ? e.target.checked : e.target.value });
    setErrors((er) => ({ ...er, [field]: undefined, form: undefined }));
  };

  const submit = async (e) => {
    e.preventDefault();
    setSubmitting(true);
    try {
      setDone(await api.subscribe(form));
    } catch (err) {
      setErrors(err.details && Object.keys(err.details).length ? err.details : { form: err.message });
    } finally {
      setSubmitting(false);
    }
  };

  if (done) {
    return (
      <div className="page">
        <section className="card center">
          <h1>You are subscribed</h1>
          <p>
            We will send {done.channels.map((c) => (c === 'SMS' ? 'SMS' : 'email')).join(' and ')} alerts
            for {regionLabel(done.region).toLowerCase()}. A confirmation has been sent.
          </p>
          <Link to="/" className="btn btn-primary">Back to alerts</Link>
        </section>
      </div>
    );
  }

  return (
    <div className="page">
      <form onSubmit={submit} noValidate className="card form">
        <div>
          <h1>Get health alerts</h1>
          <p className="muted">Official dengue and disease alerts for your area, by SMS and/or email. Free.</p>
        </div>
        {errors.form && <p className="banner-error">{errors.form}</p>}

        <div className="field">
          <span className="field-label">Send alerts by <span className="req">*</span></span>
          <div className="choice-row">
            <label className="choice"><input type="checkbox" checked={form.channels.includes('SMS')} onChange={toggleChannel('SMS')} /> SMS</label>
            <label className="choice"><input type="checkbox" checked={form.channels.includes('EMAIL')} onChange={toggleChannel('EMAIL')} /> Email</label>
          </div>
          {errors.channels && <p className="field-error">{errors.channels}</p>}
        </div>

        {form.channels.includes('SMS') && (
          <label className="field">
            <span>Mobile number <span className="req">*</span></span>
            <input inputMode="tel" value={form.phone} onChange={set('phone')} placeholder="e.g. 9123 4567" className={errors.phone ? 'input-error' : ''} autoComplete="tel" />
            {errors.phone && <p className="field-error">{errors.phone}</p>}
          </label>
        )}
        {form.channels.includes('EMAIL') && (
          <label className="field">
            <span>Email <span className="req">*</span></span>
            <input type="email" value={form.email} onChange={set('email')} className={errors.email ? 'input-error' : ''} autoComplete="email" />
            {errors.email && <p className="field-error">{errors.email}</p>}
          </label>
        )}

        <label className="field">
          <span>Region <span className="req">*</span></span>
          <select value={form.region} onChange={set('region')} className={errors.region ? 'input-error' : ''}>
            {REGIONS.map((r) => <option key={r} value={r}>{regionLabel(r)}</option>)}
          </select>
          {errors.region && <p className="field-error">{errors.region}</p>}
        </label>

        <label className="check">
          <input type="checkbox" checked={form.wantsVolunteerNews} onChange={set('wantsVolunteerNews')} />
          <span>Also tell me about new volunteer activities</span>
        </label>
        <label className="check">
          <input type="checkbox" checked={form.consentGiven} onChange={set('consentGiven')} />
          <span>I agree to receive alerts and to my contact details being stored (PDPA) <span className="req">*</span></span>
        </label>
        {errors.consentGiven && <p className="field-error">{errors.consentGiven}</p>}

        <div className="form-actions">
          <button type="submit" className="btn btn-primary" disabled={submitting}>
            {submitting ? 'Subscribing…' : 'Subscribe'}
          </button>
        </div>
      </form>
    </div>
  );
}
