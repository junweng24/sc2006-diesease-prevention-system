/**
 * «boundary» Hotspot Map page (UC1, includes UC2 geolocation lookup).
 */
import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';

import { api } from '../../api/ApiClient.js';
import AddressSearch from '../../components/AddressSearch.jsx';
import HotspotMap, { SINGAPORE_CENTER, STREET_ZOOM } from '../../components/HotspotMap.jsx';
import { DISEASES, diseaseLabel } from '../../constants.js';
import { describeLocation, formatDateTime } from '../../utils/format.js';

export default function HotspotMapPage() {
  const [diseaseType, setDiseaseType] = useState('');
  const [data, setData] = useState(null);
  const [view, setView] = useState({ center: SINGAPORE_CENTER, zoom: undefined });
  const [here, setHere] = useState(null);
  const [notice, setNotice] = useState('');
  const [error, setError] = useState('');

  // UC2 step 1: ask for GPS; fall back to the centre of Singapore if denied (UC2 2a).
  useEffect(() => {
    navigator.geolocation?.getCurrentPosition(
      (pos) => {
        const loc = { latitude: pos.coords.latitude, longitude: pos.coords.longitude };
        // Only zoom in if the device is actually in Singapore.
        if (loc.latitude > 1.15 && loc.latitude < 1.48 && loc.longitude > 103.6 && loc.longitude < 104.1) {
          setHere(loc);
          setView({ center: [loc.latitude, loc.longitude], zoom: 14 });
        }
      },
      () => setNotice('Automatic location detection is disabled. Showing all of Singapore.'),
    );
  }, []);

  // UC1 steps 2–3: load clusters/hotspots whenever the filter changes.
  useEffect(() => {
    api.getMapData(diseaseType)
      .then((d) => { setData(d); setError(''); })
      .catch(() => setError('You appear to be offline. Please reconnect.')); // UC1 exception 1a
  }, [diseaseType]);

  const goTo = (loc) => {
    setHere(loc);
    setView({ center: [loc.latitude, loc.longitude], zoom: STREET_ZOOM });
  };

  const clusters = data?.clusters ?? [];
  const hotspots = data?.hotspots ?? [];
  const highRisk = [
    ...clusters.filter((c) => c.riskLevel === 'HIGH').map((c) => ({
      key: `c${c.clusterId}`, name: c.locality, cases: c.caseCount, kind: 'NEA dengue cluster',
      at: c.boundary[0],
    })),
    ...hotspots.filter((h) => h.riskLevel === 'HIGH').map((h) => ({
      key: `h${h.id}`, name: describeLocation(h.location), cases: h.caseCount,
      kind: `${diseaseLabel(h.diseaseType)} hotspot`, at: h.location,
    })),
  ].sort((a, b) => b.cases - a.cases);

  return (
    <div className="page">
      <div className="page-header">
        <div>
          <h1>Disease hotspot map</h1>
          <p>Live NEA dengue clusters from data.gov.sg, plus hotspots confirmed by officials.</p>
        </div>
        <Link to="/report" className="btn btn-primary">Report a hotspot</Link>
      </div>

      {notice && <p className="banner banner-info">{notice}</p>}
      {error && <p className="banner-error">{error}</p>}
      {data?.isStale && (
        <p className="banner banner-warning">
          Live data unavailable.{' '}
          {data.lastSyncedAt
            ? `Showing data last synced ${formatDateTime(data.lastSyncedAt)}.`
            : 'NEA cluster data could not be loaded; officials’ hotspots are still shown.'}
        </p>
      )}

      <div className="card card-tight" style={{ marginBottom: 12 }}>
        <div className="grid map-toolbar">
          <label className="field">
            <span>Disease</span>
            <select value={diseaseType} onChange={(e) => setDiseaseType(e.target.value)}>
              <option value="">All diseases</option>
              {DISEASES.map(([code, label]) => <option key={code} value={code}>{label}</option>)}
            </select>
          </label>
          <div className="field">
            <span className="field-label">Go to a location</span>
            <AddressSearch onSelect={goTo} />
          </div>
        </div>
      </div>

      <HotspotMap
        clusters={clusters} hotspots={hotspots} center={view.center} zoom={view.zoom}
        pin={here} pinLabel="You are here" legend
      />
      {data && (
        <p className="small muted" style={{ marginTop: 8 }}>
          {clusters.length} NEA cluster(s) · {hotspots.length} hotspot(s)
          {data.lastSyncedAt && ` · cluster data synced ${formatDateTime(data.lastSyncedAt)}`}
        </p>
      )}

      {highRisk.length > 0 && (
        <>
          <div className="section-title"><h2>High-risk areas</h2></div>
          <div className="grid grid-3">
            {highRisk.map((r) => (
              <button
                key={r.key} type="button" className="card card-tight card-link"
                style={{ textAlign: 'left', font: 'inherit', cursor: 'pointer', display: 'flex', flexDirection: 'column', justifyContent: 'flex-start' }}
                onClick={() => setView({ center: [r.at.latitude, r.at.longitude], zoom: STREET_ZOOM })}
              >
                <strong>{r.name}</strong>
                <span className="small muted" style={{ display: 'block' }}>{r.kind} · {r.cases} cases</span>
              </button>
            ))}
          </div>
        </>
      )}
    </div>
  );
}
