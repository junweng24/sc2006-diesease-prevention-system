/**
 * «boundary» Report Confirmation page: shows the reference ID (UC3 step 7, FR-13) and the
 * report's current review status.
 */
import { useEffect, useState } from 'react';
import { Link, useParams } from 'react-router-dom';

import { api } from '../../api/ApiClient.js';
import Badge from '../../components/Badge.jsx';
import { formatDateTime } from '../../utils/format.js';

export default function ReportConfirmationPage() {
  const { referenceId } = useParams();
  const [status, setStatus] = useState(null);
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    api.getReportStatus(referenceId).then(setStatus).catch(() => setStatus(null));
  }, [referenceId]);

  const copy = async () => {
    await navigator.clipboard?.writeText(referenceId).catch(() => {});
    setCopied(true);
  };

  return (
    <div className="page">
      <section className="card center">
        <h1>Thank you, your report has been submitted</h1>
        <p className="muted">Keep this reference ID if you want to follow up with NEA.</p>
        <p><span className="ref-id">{referenceId}</span></p>
        <p>
          <button type="button" className="btn btn-sm" onClick={copy}>{copied ? 'Copied' : 'Copy ID'}</button>
        </p>
        {status && (
          <p className="small">
            Status: <Badge value={status.status} /> · submitted {formatDateTime(status.submittedAt)}
          </p>
        )}
        <p className="muted small">
          An official will check the site. Verified hotspots appear on the public map.
        </p>
        <div className="row" style={{ justifyContent: 'center' }}>
          <Link to="/hotspots" className="btn btn-primary">View hotspot map</Link>
          <Link to="/report" className="btn">Report another</Link>
          <Link to="/" className="btn btn-ghost">Back to home</Link>
        </div>
      </section>
    </div>
  );
}
