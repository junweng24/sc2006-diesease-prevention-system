/**
 * «boundary» Officials' dashboard: overview of reports, hotspots, alerts and activities (FR-18).
 */
import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';

import { api } from '../../api/ApiClient.js';
import Badge from '../../components/Badge.jsx';
import HotspotMap from '../../components/HotspotMap.jsx';
import { regionLabel, siteTypeLabel } from '../../constants.js';
import { describeLocation, timeAgo } from '../../utils/format.js';

export default function AdminDashboardPage() {
  const [data, setData] = useState(null);
  const [hotspots, setHotspots] = useState([]);
  const [pending, setPending] = useState([]);
  const [error, setError] = useState('');

  useEffect(() => {
    api.getDashboard().then(setData).catch((e) => setError(e.message));
    api.getHotspots().then(setHotspots).catch(() => {});
    api.getReports('UNVERIFIED').then((r) => setPending(r.slice(0, 5))).catch(() => {});
  }, []);

  if (error) return <div className="page"><p className="banner-error">{error}</p></div>;
  if (!data) return <div className="page muted">Loading…</div>;

  const stats = [
    ['Reports awaiting review', data.pendingReports, '/admin/reports', 'var(--sev-high)'],
    ['Active hotspots', data.activeHotspots, '/admin/hotspots', 'var(--danger)'],
    ['Open volunteer activities', data.openActivities, '/admin/activities', 'var(--info)'],
    ['Recent alerts', data.recentAlerts.length, '/admin/alerts', 'var(--brand)'],
  ];

  return (
    <div className="page">
      <div className="page-header">
        <div>
          <h1>Dashboard</h1>
          <p>What needs attention today.</p>
        </div>
        <div className="row">
          <Link to="/admin/alerts/new" className="btn btn-primary">+ New alert</Link>
          <Link to="/admin/activities/new" className="btn">+ New activity</Link>
        </div>
      </div>

      <div className="grid grid-4">
        {stats.map(([label, value, to, accent]) => (
          <Link key={label} to={to} className="card card-link stat stat-accent" style={{ '--accent': accent }}>
            <span className="stat-value">{value}</span>
            <span className="stat-label">{label}</span>
          </Link>
        ))}
      </div>

      <div className="grid grid-2" style={{ marginTop: 20 }}>
        <section className="card">
          <div className="section-title" style={{ marginTop: 0 }}>
            <h2>Reports to review</h2>
            <Link to="/admin/reports" className="small">View all</Link>
          </div>
          {pending.length === 0 && <p className="muted">No reports waiting.</p>}
          <ul className="list-plain">
            {pending.map((r) => (
              <li key={r.referenceId}>
                <Link to={`/admin/reports/${r.referenceId}`}><strong>{r.referenceId}</strong></Link>
                <span className="small muted"> · {siteTypeLabel(r.siteType)} · {timeAgo(r.submittedAt)}</span>
                <div className="small">{describeLocation(r.location)}</div>
              </li>
            ))}
          </ul>
        </section>
        <section className="card">
          <div className="section-title" style={{ marginTop: 0 }}>
            <h2>Hotspots on the public map</h2>
            <Link to="/admin/hotspots" className="small">Manage</Link>
          </div>
          <HotspotMap hotspots={hotspots} small zoom={11} />
        </section>
      </div>

      <section className="card" style={{ marginTop: 20 }}>
        <div className="section-title" style={{ marginTop: 0 }}>
          <h2>Recent alerts</h2>
          <Link to="/admin/alerts" className="small">All alerts</Link>
        </div>
        {data.recentAlerts.length === 0 && <p className="muted">No alerts published yet.</p>}
        <ul className="list-plain">
          {data.recentAlerts.map((a) => (
            <li key={a.id} className="row">
              <Badge value={a.severity} />
              <strong>{a.title}</strong>
              <span className="spacer" />
              <span className="small muted">{regionLabel(a.targetRegion)} · {timeAgo(a.publishedAt)}</span>
            </li>
          ))}
        </ul>
      </section>
    </div>
  );
}
