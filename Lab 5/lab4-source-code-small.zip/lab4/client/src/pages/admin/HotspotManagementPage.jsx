/**
 * «boundary» Hotspots tab ("Official Heat Map Page"): view, add and remove hotspots (UC17).
 */
import { useEffect, useState } from 'react';

import { api } from '../../api/ApiClient.js';
import AddressSearch from '../../components/AddressSearch.jsx';
import Badge from '../../components/Badge.jsx';
import HotspotMap, { SINGAPORE_CENTER, STREET_ZOOM } from '../../components/HotspotMap.jsx';
import { diseaseLabel } from '../../constants.js';
import { describeLocation, formatDate } from '../../utils/format.js';

const EMPTY = { diseaseType: 'DENGUE', caseCount: '0', location: null };

/** UC17 steps 2–4: add a hotspot by address search or map pin. */
function AddHotspotForm({ diseaseTypes, location, onLocation, onAdded }) {
  const [form, setForm] = useState(EMPTY);
  const [errors, setErrors] = useState({});
  const [saving, setSaving] = useState(false);

  const submit = async (e) => {
    e.preventDefault();
    setSaving(true);
    try {
      const added = await api.addHotspot({ ...form, location, caseCount: Number(form.caseCount) });
      setForm(EMPTY);
      setErrors({});
      onAdded(added);
    } catch (err) {
      setErrors(err.details && Object.keys(err.details).length ? err.details : { form: err.message });
    } finally {
      setSaving(false);
    }
  };

  const count = Number(form.caseCount);
  return (
    <form onSubmit={submit} noValidate className="card form">
      <h2>Add a hotspot</h2>
      {errors.form && <p className="banner-error">{errors.form}</p>}
      <label className="field">
        <span>Disease type <span className="req">*</span></span>
        <select value={form.diseaseType} onChange={(e) => setForm({ ...form, diseaseType: e.target.value })}>
          {diseaseTypes.map((d) => <option key={d.code} value={d.code}>{d.label}</option>)}
        </select>
        {errors.diseaseType && <p className="field-error">{errors.diseaseType}</p>}
      </label>
      <label className="field">
        <span>Confirmed cases</span>
        <input
          type="number" min="0" value={form.caseCount} className={errors.caseCount ? 'input-error' : ''}
          onChange={(e) => setForm({ ...form, caseCount: e.target.value })}
        />
        <span className="field-hint">
          {Number.isInteger(count) && count >= 10 ? 'High risk (10 or more cases)' : 'Low risk (under 10 cases)'}
        </span>
        {errors.caseCount && <p className="field-error">{errors.caseCount}</p>}
      </label>
      <div className="field">
        <span className="field-label">Location <span className="req">*</span></span>
        <AddressSearch onSelect={onLocation} allowGps={false} />
        <span className="field-hint">…or click the map.</span>
        {location && <span className="small">Selected: {describeLocation(location)}</span>}
        {errors.location && <p className="field-error">{errors.location}</p>}
      </div>
      <button type="submit" className="btn btn-primary" disabled={saving}>{saving ? 'Adding…' : 'Add to public map'}</button>
    </form>
  );
}

export default function HotspotManagementPage() {
  const [hotspots, setHotspots] = useState([]);
  const [diseaseTypes, setDiseaseTypes] = useState([]);
  const [location, setLocation] = useState(null);
  const [view, setView] = useState({ center: SINGAPORE_CENTER, zoom: undefined });
  const [notice, setNotice] = useState('');
  const [error, setError] = useState('');

  const load = () => api.getHotspots().then(setHotspots).catch((e) => setError(e.message));
  useEffect(() => {
    load();
    api.getDiseaseTypes().then(setDiseaseTypes).catch(() => {});
  }, []);

  const chooseLocation = async (loc, recentre = true) => {
    setLocation(loc);
    if (recentre) setView({ center: [loc.latitude, loc.longitude], zoom: STREET_ZOOM });
    if (!loc.address) {
      const found = await api.reverseGeocode(loc.latitude, loc.longitude).catch(() => null);
      if (found?.address) setLocation(found);
    }
  };

  const remove = async (h) => {
    if (!window.confirm(`Remove the ${diseaseLabel(h.diseaseType)} hotspot at ${describeLocation(h.location)} from the public map?`)) return; // UC17 2a
    try {
      await api.removeHotspot(h.id);
      setNotice('Hotspot removed from the public map.');
      load();
    } catch (err) {
      setError(err.message);
    }
  };

  return (
    <div className="page">
      <div className="page-header">
        <div>
          <h1>Hotspots</h1>
          <p>Hotspots shown on the public map, added by officials or from verified reports.</p>
        </div>
      </div>
      {error && <p className="banner-error">{error}</p>}
      {notice && <p className="banner-success">{notice}</p>}

      <div className="split">
        <AddHotspotForm
          diseaseTypes={diseaseTypes} location={location} onLocation={chooseLocation}
          onAdded={(h) => { setLocation(null); setNotice(`Added ${diseaseLabel(h.diseaseType)} hotspot at ${describeLocation(h.location)}.`); load(); }}
        />
        <HotspotMap
          hotspots={hotspots} legend center={view.center} zoom={view.zoom}
          pin={location} pinLabel="New hotspot"
          onPick={(lat, lng) => chooseLocation({ latitude: lat, longitude: lng, address: null }, false)}
        />
      </div>

      <div className="section-title"><h2>Active hotspots ({hotspots.length})</h2></div>
      <div className="table-wrap">
        <table>
          <thead><tr><th>Disease</th><th>Location</th><th>Cases</th><th>Risk</th><th>Source</th><th>Added</th><th /></tr></thead>
          <tbody>
            {hotspots.map((h) => (
              <tr key={h.id}>
                <td>{diseaseLabel(h.diseaseType)}</td>
                <td>
                  <button type="button" className="btn-ghost btn btn-sm" style={{ padding: 0 }} onClick={() => setView({ center: [h.location.latitude, h.location.longitude], zoom: STREET_ZOOM })}>
                    {describeLocation(h.location)}
                  </button>
                </td>
                <td>{h.caseCount}</td>
                <td><Badge value={h.riskLevel === 'HIGH' ? 'HIGH' : 'MEDIUM'} label={h.riskLevel === 'HIGH' ? 'High' : 'Low'} /></td>
                <td className="small">{h.source === 'VERIFIED_REPORT' ? `Report ${h.sourceReportId}` : 'Official'}</td>
                <td className="small">{formatDate(h.createdAt)}</td>
                <td><button type="button" className="btn btn-sm btn-danger" onClick={() => remove(h)}>Remove</button></td>
              </tr>
            ))}
          </tbody>
        </table>
        {hotspots.length === 0 && <p className="empty">No active hotspots.</p>}
      </div>
    </div>
  );
}
