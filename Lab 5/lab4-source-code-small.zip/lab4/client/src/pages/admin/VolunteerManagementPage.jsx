/**
 * «boundary» Volunteers tab ("Official Volunteer Page"): activity list with status filter
 * (UC9 step 1, UC10 1a).
 */
import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';

import { api } from '../../api/ApiClient.js';
import Badge from '../../components/Badge.jsx';
import { formatDateTime } from '../../utils/format.js';

const FILTERS = [['', 'All'], ['OPEN', 'Open slots'], ['FULL', 'Fully booked'], ['COMPLETED', 'Completed']];

export default function VolunteerManagementPage() {
  const [status, setStatus] = useState('');
  const [activities, setActivities] = useState(null);

  useEffect(() => {
    setActivities(null);
    api.getActivities(status).then(setActivities).catch(() => setActivities([]));
  }, [status]);

  return (
    <div className="page">
      <div className="page-header">
        <div>
          <h1>Volunteer activities</h1>
          <p>Create deployments and track how many volunteers have signed up.</p>
        </div>
        <Link to="/admin/activities/new" className="btn btn-primary">+ Create new deployment</Link>
      </div>
      <div className="tabs" role="tablist">
        {FILTERS.map(([value, label]) => (
          <button key={value} type="button" role="tab" aria-selected={status === value} className={status === value ? 'active' : ''} onClick={() => setStatus(value)}>
            {label}
          </button>
        ))}
      </div>
      <div className="table-wrap">
        <table>
          <thead><tr><th>Title</th><th>Area</th><th>Date</th><th style={{ minWidth: 140 }}>Registered</th><th>Status</th><th /></tr></thead>
          <tbody>
            {activities?.map((a) => {
              const percent = Math.round((a.registeredCount / a.headcountQuota) * 100);
              return (
                <tr key={a.id}>
                  <td><Link to={`/admin/activities/${a.id}`}><strong>{a.title}</strong></Link></td>
                  <td>{a.targetArea}</td>
                  <td>{formatDateTime(a.eventDateTime)}</td>
                  <td>
                    <div className="small">{a.registeredCount} / {a.headcountQuota}</div>
                    <div className={`meter${percent >= 100 ? ' meter-full' : ''}`}><span style={{ width: `${percent}%` }} /></div>
                  </td>
                  <td><Badge value={a.status} /></td>
                  <td>
                    <div className="row" style={{ flexWrap: 'nowrap' }}>
                      <Link to={`/admin/activities/${a.id}`} className="btn btn-sm">Status</Link>
                      {a.status !== 'COMPLETED' && <Link to={`/admin/activities/${a.id}/edit`} className="btn btn-sm">Edit</Link>}
                    </div>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
        {!activities && <p className="empty">Loading…</p>}
        {activities?.length === 0 && <p className="empty">No activities.</p>}
      </div>
    </div>
  );
}
