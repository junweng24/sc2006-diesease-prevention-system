/**
 * «boundary» Admin Login page (UC14). Also shows why the official was sent here
 * (logged out, UC18, or session expired, UC7 1a).
 */
import { useEffect, useState } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';

import { api } from '../../api/ApiClient.js';

/** Demo account created by `npm run seed`, shown and pre-filled for the project demo. */
const DEMO_USERNAME = 'officer';
const DEMO_PASSWORD = 'ChangeMe123!';

export default function AdminLoginPage() {
  const navigate = useNavigate();
  const notice = useLocation().state?.message;
  const [username, setUsername] = useState(DEMO_USERNAME);
  const [password, setPassword] = useState(DEMO_PASSWORD);
  const [error, setError] = useState('');
  const [submitting, setSubmitting] = useState(false);

  // Already logged in (e.g. opened /admin/login from a bookmark): go straight in.
  useEffect(() => {
    api.me().then(() => navigate('/admin', { replace: true })).catch(() => {});
  }, [navigate]);

  const submit = async (e) => {
    e.preventDefault();
    setSubmitting(true);
    try {
      await api.login(username, password);
      navigate('/admin', { replace: true });
    } catch (err) {
      setError(err.message); // "Invalid login" (2a) or "Account locked…" (2b)
      setPassword('');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="admin-theme">
    <main className="login-shell">
      <form onSubmit={submit} className="card login-card form">
        <div>
          <h1>Officials login</h1>
          <p className="muted small" style={{ margin: 0 }}>Disease Prevention System · authorised NEA officials only</p>
        </div>
        <div className="banner banner-info" style={{ margin: 0 }}>
          <strong>Demo account</strong><br />
          Username: <code>{DEMO_USERNAME}</code><br />
          Password: <code>{DEMO_PASSWORD}</code>
          <div style={{ marginTop: 6 }}>
            <button type="button" className="btn btn-sm" onClick={() => { setUsername(DEMO_USERNAME); setPassword(DEMO_PASSWORD); setError(''); }}>
              Fill in demo account
            </button>
          </div>
        </div>
        {notice && !error && <p className="banner banner-info" style={{ margin: 0 }}>{notice}</p>}
        {error && <p className="banner-error" style={{ margin: 0 }}>{error}</p>}
        <label className="field">
          <span>Username</span>
          <input value={username} onChange={(e) => setUsername(e.target.value)} autoComplete="username" autoFocus />
        </label>
        <label className="field">
          <span>Password</span>
          <input type="password" value={password} onChange={(e) => setPassword(e.target.value)} autoComplete="current-password" />
        </label>
        <button type="submit" className="btn btn-primary btn-block" disabled={submitting || !username || !password}>
          {submitting ? 'Logging in…' : 'Login'}
        </button>
        <p className="small muted center" style={{ margin: 0 }}>
          After 5 failed attempts the account is locked for 15 minutes. · <Link to="/">Public site</Link>
        </p>
      </form>
    </main>
    </div>
  );
}
