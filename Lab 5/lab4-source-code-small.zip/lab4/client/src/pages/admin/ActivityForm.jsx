/**
 * «boundary» Create / Edit Activity form (UC9 create, UC11 edit). With an :id it edits.
 * Dates are entered and shown in Singapore time whatever the computer's time zone.
 */
import { useEffect, useState } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';

import { api } from '../../api/ApiClient.js';
import { fromSgtInputValue, toSgtInputValue } from '../../utils/format.js';

const EMPTY = {
  title: '', targetArea: '', eventDateTime: '', headcountQuota: '', priority: 'NORMAL',
  description: '', contactName: '', contactPhone: '',
};

export default function ActivityForm() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [form, setForm] = useState(EMPTY);
  const [registered, setRegistered] = useState(0);
  const [errors, setErrors] = useState({});
  const [saving, setSaving] = useState(false);

  // UC11 step 1: populate the form with current values.
  useEffect(() => {
    if (!id) return;
    api.getActivityStatus(id).then(({ activity: a }) => {
      setRegistered(a.registeredCount);
      setForm({
        title: a.title,
        targetArea: a.targetArea,
        eventDateTime: toSgtInputValue(a.eventDateTime),
        headcountQuota: String(a.headcountQuota),
        priority: a.priority,
        description: a.description ?? '',
        contactName: a.contactPerson?.name ?? '',
        contactPhone: a.contactPerson?.phone ?? '',
      });
    }).catch((err) => setErrors({ form: err.message }));
  }, [id]);

  const set = (field) => (e) => {
    setForm({ ...form, [field]: e.target.value });
    setErrors((er) => ({ ...er, [field]: undefined, form: undefined }));
  };

  const submit = async (e) => {
    e.preventDefault();
    setSaving(true);
    const payload = {
      ...form,
      eventDateTime: fromSgtInputValue(form.eventDateTime),
      headcountQuota: form.headcountQuota === '' ? '' : Number(form.headcountQuota),
    };
    try {
      if (id) await api.editActivity(id, payload);
      else await api.createActivity(payload);
      navigate(id ? `/admin/activities/${id}` : '/admin/activities'); // UC9 step 6 / UC11 step 3
    } catch (err) {
      setErrors(err.details && Object.keys(err.details).length ? err.details : { form: err.message }); // UC9 3a / UC11 2a
    } finally {
      setSaving(false);
    }
  };

  const field = (name, label, { required = false, hint, ...props } = {}) => (
    <label className="field">
      <span>{label} {required && <span className="req">*</span>}</span>
      <input value={form[name]} onChange={set(name)} className={errors[name] ? 'input-error' : ''} {...props} />
      {hint && <span className="field-hint">{hint}</span>}
      {errors[name] && <p className="field-error">{errors[name]}</p>}
    </label>
  );

  return (
    <div className="page">
      <Link to="/admin/activities" className="back-link">&lt; All activities</Link>
      <form onSubmit={submit} noValidate className="card form">
        <h1>{id ? 'Edit activity' : 'Create deployment'}</h1>
        {errors.form && <p className="banner-error">{errors.form}</p>}
        {field('title', 'Title', { required: true, maxLength: 120 })}
        {field('targetArea', 'Target area / meeting point', { required: true })}
        <div className="grid grid-2">
          {field('eventDateTime', 'Date & time (SGT)', {
            required: true, type: 'datetime-local',
            hint: id ? 'Registered volunteers are told if this or the area changes.' : undefined,
          })}
          {field('headcountQuota', 'Volunteers needed', {
            required: true, type: 'number', min: Math.max(1, registered),
            hint: id && registered > 0 ? `${registered} already registered` : undefined,
          })}
        </div>
        <label className="field">
          <span>Priority</span>
          <select value={form.priority} onChange={set('priority')}>
            <option value="LOW">Low</option><option value="NORMAL">Normal</option><option value="HIGH">High</option>
          </select>
        </label>
        <label className="field">
          <span>Description</span>
          <textarea value={form.description} onChange={set('description')} placeholder="What volunteers will do, what to bring…" />
        </label>
        <div className="grid grid-2">
          {field('contactName', 'Person in charge')}
          {field('contactPhone', 'Contact number', { inputMode: 'tel', placeholder: '8 digits' })}
        </div>
        <div className="form-actions">
          <button type="submit" className="btn btn-primary" disabled={saving}>{saving ? 'Saving…' : 'Save'}</button>
          <Link to="/admin/activities" className="btn btn-ghost">Cancel</Link>
        </div>
      </form>
    </div>
  );
}
