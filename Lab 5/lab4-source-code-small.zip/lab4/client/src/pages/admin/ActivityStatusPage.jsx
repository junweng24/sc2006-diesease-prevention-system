/**
 * «boundary» Activity Status page: occupancy bar and optional roster (UC10).
 * The roster contains personal data and is only served to officials (NFR-02).
 */
import { useEffect, useState } from 'react';
import { Link, useParams } from 'react-router-dom';

import { api } from '../../api/ApiClient.js';
import Badge from '../../components/Badge.jsx';
import { formatDateTime } from '../../utils/format.js';

export default function ActivityStatusPage() {
  const { id } = useParams();
  const [status, setStatus] = useState(null);
  const [roster, setRoster] = useState(null);
  const [error, setError] = useState('');

  useEffect(() => {
    api.getActivityStatus(id).then(setStatus).catch((e) => setError(e.message)); // UC10 1a
  }, [id]);

  const loadRoster = () => api.getRoster(id).then(setRoster).catch((e) => setError(e.message));

  if (error) return <div className="page"><Link to="/admin/activities" className="back-link">&lt; Back</Link><p className="banner-error">{error}</p></div>;
  if (!status) return <div className="page muted">Loading…</div>;
  const a = status.activity;

  return (
    <div className="page">
      <Link to="/admin/activities" className="back-link">&lt; All activities</Link>
      <div className="page-header">
        <div>
          <div className="row" style={{ marginBottom: 6 }}><Badge value={a.status} /> {a.priority === 'HIGH' && <Badge value="HIGH" label="High priority" />}</div>
          <h1>{a.title}</h1>
          <p>Area: {a.targetArea} | Date: {formatDateTime(a.eventDateTime)}</p>
        </div>
        {a.status !== 'COMPLETED' && <Link to={`/admin/activities/${id}/edit`} className="btn">Edit activity</Link>}
      </div>

      <div className="grid grid-3">
        <div className="card stat"><span className="stat-value">{status.registeredCount}</span><span className="stat-label">Registered</span></div>
        <div className="card stat"><span className="stat-value">{status.remainingSlots}</span><span className="stat-label">Slots left</span></div>
        <div className="card stat"><span className="stat-value">{status.occupancyPercent}%</span><span className="stat-label">of {status.headcountQuota} filled</span></div>
      </div>
      <div className={`meter${status.remainingSlots === 0 ? ' meter-full' : ''}`} style={{ margin: '16px 0', height: 12 }}>
        <span style={{ width: `${status.occupancyPercent}%` }} />
      </div>

      {(a.description || a.contactPerson?.name) && (
        <section className="card" style={{ marginBottom: 16 }}>
          {a.description && <p>{a.description}</p>}
          {a.contactPerson?.name && <p className="small muted" style={{ margin: 0 }}>Person in charge: {a.contactPerson.name} {a.contactPerson.phone}</p>}
        </section>
      )}

      <div className="section-title">
        <h2>Roster</h2>
        {!roster && <button type="button" className="btn" onClick={loadRoster}>View roster</button>}
      </div>
      {roster && (
        <div className="table-wrap">
          <table>
            <thead><tr><th>#</th><th>Name</th><th>Phone</th><th>Email</th><th>Registered</th></tr></thead>
            <tbody>
              {roster.map((r, i) => (
                <tr key={r.id}>
                  <td>{i + 1}</td>
                  <td>{r.contact.name}</td>
                  <td><a href={`tel:${r.contact.phone}`}>{r.contact.phone}</a></td>
                  <td><a href={`mailto:${r.contact.email}`}>{r.contact.email}</a></td>
                  <td>{formatDateTime(r.registeredAt)}</td>
                </tr>
              ))}
            </tbody>
          </table>
          {roster.length === 0 && <p className="empty">Nobody has registered yet.</p>}
        </div>
      )}
      {!roster && <p className="muted small">The roster contains personal data and is only shown when you ask for it.</p>}
    </div>
  );
}
