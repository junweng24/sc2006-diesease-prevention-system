/**
 * «boundary» Create Alert form with preview, then publish and dispatch (UC7 steps 2–6).
 */
import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';

import { api } from '../../api/ApiClient.js';
import Badge from '../../components/Badge.jsx';
import { REGIONS, SEVERITIES, regionLabel } from '../../constants.js';

const CATEGORIES = ['Dengue', 'Zika', 'Chikungunya', 'Prevention', 'General'];

export default function CreateAlertForm() {
  const navigate = useNavigate();
  const [form, setForm] = useState({
    title: '', body: '', category: 'Dengue', severity: 'MEDIUM', targetRegion: 'ALL',
  });
  const [errors, setErrors] = useState({});
  const [preview, setPreview] = useState(null);
  const [summary, setSummary] = useState(null);
  const [publishing, setPublishing] = useState(false);

  const set = (field) => (e) => {
    setForm({ ...form, [field]: e.target.value });
    setErrors((er) => ({ ...er, [field]: undefined, form: undefined }));
    setPreview(null); // the preview no longer matches
  };

  const showPreview = async () => { // UC7 step 4
    try {
      setPreview(await api.previewAlert(form));
    } catch (err) {
      setErrors({ form: err.message });
    }
  };

  const publish = async () => {
    if (!window.confirm(`Publish this alert to ${regionLabel(form.targetRegion).toLowerCase()} and notify subscribers?`)) return;
    setPublishing(true);
    try {
      const { dispatch } = await api.publishAlert(form);
      setSummary(dispatch); // UC7 step 6: dispatch report summary
    } catch (err) {
      setErrors(err.details && Object.keys(err.details).length ? err.details : { form: err.message });
    } finally {
      setPublishing(false);
    }
  };

  if (summary) {
    return (
      <div className="page">
        <section className="card center">
          <h1>Alert published</h1>
          <p>It is now on the public home page.</p>
          <p>
            Notifications sent: <strong>{summary.sent}</strong> · Failed (logged for retry): <strong>{summary.failed}</strong>
          </p>
          <div className="row" style={{ justifyContent: 'center' }}>
            <button type="button" className="btn btn-primary" onClick={() => navigate('/admin/alerts')}>Back to alerts</button>
            <Link to="/" target="_blank" className="btn">View public site</Link>
          </div>
        </section>
      </div>
    );
  }

  const error = (f) => errors[f] && <p className="field-error">{errors[f]}</p>;
  return (
    <div className="page">
      <Link to="/admin/alerts" className="back-link">&lt; All alerts</Link>
      <div className="page-header"><h1>Create alert</h1></div>
      <div className="split split-even">
        <form onSubmit={(e) => e.preventDefault()} noValidate className="card form">
          {errors.form && <p className="banner-error">{errors.form}</p>}
          <label className="field">
            <span>Title <span className="req">*</span></span>
            <input value={form.title} onChange={set('title')} maxLength={120} className={errors.title ? 'input-error' : ''} />
            {error('title')}
          </label>
          <label className="field">
            <span>Message <span className="req">*</span></span>
            <textarea value={form.body} onChange={set('body')} maxLength={2000} className={errors.body ? 'input-error' : ''} />
            <span className="field-hint">{form.body.length}/2000</span>
            {error('body')}
          </label>
          <div className="grid grid-3">
            <label className="field">
              <span>Category <span className="req">*</span></span>
              <select value={form.category} onChange={set('category')}>
                {CATEGORIES.map((c) => <option key={c}>{c}</option>)}
              </select>
              {error('category')}
            </label>
            <label className="field">
              <span>Severity <span className="req">*</span></span>
              <select value={form.severity} onChange={set('severity')}>
                {SEVERITIES.map((s) => <option key={s} value={s}>{s.charAt(0) + s.slice(1).toLowerCase()}</option>)}
              </select>
              {error('severity')}
            </label>
            <label className="field">
              <span>Target region <span className="req">*</span></span>
              <select value={form.targetRegion} onChange={set('targetRegion')}>
                {REGIONS.map((r) => <option key={r} value={r}>{regionLabel(r)}</option>)}
              </select>
              {error('targetRegion')}
            </label>
          </div>
          <div className="form-actions">
            <button type="button" className="btn" onClick={showPreview}>Preview</button>
            <button type="button" className="btn btn-primary" onClick={publish} disabled={publishing}>
              {publishing ? 'Publishing…' : 'Publish and dispatch alert'}
            </button>
            <Link to="/admin/alerts" className="btn btn-ghost">Cancel</Link>
          </div>
        </form>

        <aside className="card stack">
          <h2>Preview</h2>
          {!preview && <p className="muted">Press “Preview” to see how the alert will look on the website and by SMS.</p>}
          {preview && (
            <>
              <div className={`card alert-card sev-${preview.card.severity}`}>
                <div className="row" style={{ marginBottom: 6 }}>
                  <Badge value={preview.card.severity} />
                  <span className="badge">{preview.card.category}</span>
                  <span className="badge">{regionLabel(preview.card.targetRegion)}</span>
                </div>
                <h3>{preview.card.title || <span className="muted">(no title)</span>}</h3>
                <p className="muted" style={{ whiteSpace: 'pre-wrap', margin: 0 }}>{preview.card.body}</p>
              </div>
              <div>
                <p className="small muted">SMS ({preview.smsText.length}/160 characters)</p>
                <div className="sms-preview">{preview.smsText}</div>
              </div>
            </>
          )}
        </aside>
      </div>
    </div>
  );
}
