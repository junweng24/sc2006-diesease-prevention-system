/**
 * «boundary» Alerts tab ("Official Alerts Page"): published alerts + "Create alert" (UC7 step 1).
 */
import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';

import { api } from '../../api/ApiClient.js';
import Badge from '../../components/Badge.jsx';
import { regionLabel } from '../../constants.js';
import { formatDateTime } from '../../utils/format.js';

export default function AlertManagementPage() {
  const [alerts, setAlerts] = useState(null);
  const [error, setError] = useState('');

  useEffect(() => { api.getAdminAlerts().then(setAlerts).catch((e) => setError(e.message)); }, []);

  return (
    <div className="page">
      <div className="page-header">
        <div>
          <h1>Public alerts</h1>
          <p>Published alerts appear on the public home page and are sent to subscribers in the target region.</p>
        </div>
        <Link to="/admin/alerts/new" className="btn btn-primary">+ Create new alert</Link>
      </div>
      {error && <p className="banner-error">{error}</p>}
      <div className="table-wrap">
        <table>
          <thead><tr><th>Title</th><th>Severity</th><th>Category</th><th>Region</th><th>Published</th></tr></thead>
          <tbody>
            {alerts?.map((a) => (
              <tr key={a.id}>
                <td><Link to={`/alerts/${a.id}`} target="_blank">{a.title}</Link></td>
                <td><Badge value={a.severity} /></td>
                <td>{a.category}</td>
                <td>{regionLabel(a.targetRegion)}</td>
                <td>{formatDateTime(a.publishedAt)}</td>
              </tr>
            ))}
          </tbody>
        </table>
        {alerts?.length === 0 && <p className="empty">No alerts published yet.</p>}
      </div>
    </div>
  );
}
