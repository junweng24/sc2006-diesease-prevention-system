/**
 * «boundary» Hotspot Reports table + Report Review detail (UC8).
 * Without a :referenceId it shows the table; with one it shows the review panel.
 */
import { useEffect, useState } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';

import { api } from '../../api/ApiClient.js';
import Badge from '../../components/Badge.jsx';
import HotspotMap, { STREET_ZOOM } from '../../components/HotspotMap.jsx';
import { siteTypeLabel } from '../../constants.js';
import { describeLocation, formatDateTime, humanise } from '../../utils/format.js';

/** Status changes an official may choose from each status (mirrors HotspotReport rules). */
const NEXT_STATUSES = {
  UNVERIFIED: ['VERIFIED_ACTIVE', 'DISMISSED'],
  VERIFIED_ACTIVE: ['RESOLVED'],
  RESOLVED: [],
  DISMISSED: [],
};

/** Button text, style and confirmation question for each status change. */
const ACTIONS = {
  VERIFIED_ACTIVE: ['Verify: add to public map', 'btn-primary', 'Verify this report? A hotspot will appear on the public map.'],
  DISMISSED: ['Dismiss report', 'btn-danger', 'Dismiss this report? It will not appear on the map.'],
  RESOLVED: ['Mark resolved: remove from map', 'btn-primary', 'Mark the site as cleared? Its hotspot is removed from the public map.'],
};

function ReportTable() {
  const [status, setStatus] = useState('UNVERIFIED');
  const [reports, setReports] = useState(null);

  useEffect(() => {
    setReports(null);
    api.getReports(status).then(setReports).catch(() => setReports([]));
  }, [status]);

  return (
    <div className="page">
      <div className="page-header">
        <div>
          <h1>Hotspot reports</h1>
          <p>Reports from the public. Verify them to put a hotspot on the public map.</p>
        </div>
      </div>
      <div className="tabs" role="tablist">
        {Object.keys(NEXT_STATUSES).map((s) => (
          <button key={s} type="button" role="tab" aria-selected={status === s} className={status === s ? 'active' : ''} onClick={() => setStatus(s)}>
            {humanise(s)}
          </button>
        ))}
      </div>
      <div className="table-wrap">
        <table>
          <thead><tr><th>Reference</th><th>Location</th><th>Site type</th><th>Photo</th><th>Submitted</th></tr></thead>
          <tbody>
            {reports?.map((r) => (
              <tr key={r.referenceId}>
                <td><Link to={`/admin/reports/${r.referenceId}`}><strong>{r.referenceId}</strong></Link></td>
                <td>{describeLocation(r.location)}</td>
                <td>{siteTypeLabel(r.siteType)}</td>
                <td>{r.photoPath ? 'Yes' : <span className="muted">No</span>}</td>
                <td>{formatDateTime(r.submittedAt)}</td>
              </tr>
            ))}
          </tbody>
        </table>
        {!reports && <p className="empty">Loading…</p>}
        {reports?.length === 0 && <p className="empty">No {humanise(status).toLowerCase()} reports.</p>}
      </div>
    </div>
  );
}

function ReportReview({ referenceId }) {
  const navigate = useNavigate();
  const [report, setReport] = useState(null);
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');
  const [photoFailed, setPhotoFailed] = useState(false);

  const load = () => api.getReport(referenceId).then(setReport).catch((e) => setError(e.message));
  useEffect(() => { load(); }, [referenceId]); // eslint-disable-line react-hooks/exhaustive-deps

  const changeStatus = async (status) => {
    if (!window.confirm(ACTIONS[status][2])) return;
    try {
      await api.reviewReport(referenceId, status, report.version);
      navigate('/admin/reports');
    } catch (err) {
      setMessage(err.message);
      if (err.status === 409) load(); // UC8 4a: reload latest record
    }
  };

  if (error) return <div className="page"><p className="banner-error">{error}</p></div>;
  if (!report) return <div className="page muted">Loading…</div>;
  const c = report.contact;
  return (
    <div className="page">
      <Link to="/admin/reports" className="back-link">&lt; All reports</Link>
      <div className="page-header">
        <div>
          <h1>Report {report.referenceId}</h1>
          <p>Submitted {formatDateTime(report.submittedAt)}</p>
        </div>
        <Badge value={report.status} />
      </div>
      {message && <p className="banner-error">{message}</p>}

      <div className="grid grid-2">
        <section className="card stack">
          <dl className="dl">
            <dt>Location</dt><dd>{describeLocation(report.location)}</dd>
            <dt>Site type</dt><dd>{siteTypeLabel(report.siteType)}</dd>
            <dt>Reported by</dt>
            <dd>
              {c?.name || c?.phone || c?.email
                ? <>{c.name}{c.phone && <> · <a href={`tel:${c.phone}`}>{c.phone}</a></>}{c.email && <> · <a href={`mailto:${c.email}`}>{c.email}</a></>}</>
                : <span className="muted">Anonymous</span>}
            </dd>
            {report.reviewedAt && <><dt>Last reviewed</dt><dd>{formatDateTime(report.reviewedAt)}</dd></>}
          </dl>
          <div>
            <strong>Description</strong>
            <p style={{ whiteSpace: 'pre-wrap' }}>{report.description}</p>
          </div>
          {NEXT_STATUSES[report.status].length > 0 ? (
            <div className="form-actions">
              {NEXT_STATUSES[report.status].map((s) => (
                <button key={s} type="button" className={`btn ${ACTIONS[s][1]}`} onClick={() => changeStatus(s)}>
                  {ACTIONS[s][0]}
                </button>
              ))}
            </div>
          ) : <p className="muted small">This report is closed; no further changes are possible.</p>}
        </section>

        <section className="stack">
          {report.photoPath && (
            <div className="photo-frame">
              {photoFailed
                ? <p className="empty">The photo could not be loaded.</p>
                : <img src={api.reportPhotoUrl(report.referenceId)} alt={`Photo for report ${report.referenceId}`} onError={() => setPhotoFailed(true)} />}
            </div>
          )}
          <HotspotMap
            small pin={report.location} pinLabel="Reported location"
            center={[report.location.latitude, report.location.longitude]} zoom={STREET_ZOOM}
          />
        </section>
      </div>
    </div>
  );
}

export default function HotspotReviewPage() {
  const { referenceId } = useParams();
  return referenceId ? <ReportReview referenceId={referenceId} /> : <ReportTable />;
}
