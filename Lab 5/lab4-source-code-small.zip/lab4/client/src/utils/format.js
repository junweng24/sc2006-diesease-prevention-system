/**
 * Display helpers shared by all pages. Every date is shown in Singapore time, whatever the
 * time zone of the computer running the browser.
 */

const SGT = 'Asia/Singapore';
const SGT_OFFSET_MS = 8 * 60 * 60 * 1000;

/** @param {string|Date} value @returns {string} e.g. "23 Oct 2026, 9:00 am" */
export const formatDateTime = (value) =>
  new Date(value).toLocaleString('en-SG', { timeZone: SGT, dateStyle: 'medium', timeStyle: 'short' });

/** @param {string|Date} value @returns {string} e.g. "Fri, 23 Oct 2026" */
export const formatDate = (value) =>
  new Date(value).toLocaleDateString('en-SG', {
    timeZone: SGT, weekday: 'short', day: 'numeric', month: 'short', year: 'numeric',
  });

/** @param {string|Date} value @returns {string} e.g. "5 hours ago" */
export function timeAgo(value) {
  const seconds = Math.round((Date.now() - new Date(value).getTime()) / 1000);
  const units = [['day', 86400], ['hour', 3600], ['minute', 60]];
  for (const [unit, size] of units) {
    if (Math.abs(seconds) >= size) {
      return new Intl.RelativeTimeFormat('en', { numeric: 'auto' }).format(-Math.round(seconds / size), unit);
    }
  }
  return 'just now';
}

/**
 * A `<input type="datetime-local">` has no time zone, so values are converted to and from
 * Singapore time explicitly.
 * @param {string|Date} value ISO timestamp
 * @returns {string} "yyyy-MM-ddTHH:mm" in SGT
 */
export const toSgtInputValue = (value) =>
  new Date(new Date(value).getTime() + SGT_OFFSET_MS).toISOString().slice(0, 16);

/**
 * @param {string} inputValue "yyyy-MM-ddTHH:mm" typed as Singapore time
 * @returns {string} ISO timestamp with +08:00 offset, or '' if empty
 */
export const fromSgtInputValue = (inputValue) => (inputValue ? `${inputValue}:00+08:00` : '');

/** @param {{address?: string|null, latitude: number, longitude: number}} location */
export const describeLocation = (location) =>
  location.address || `${Number(location.latitude).toFixed(5)}, ${Number(location.longitude).toFixed(5)}`;

/** Turns "VERIFIED_ACTIVE" into "Verified active". */
export const humanise = (code) =>
  (code ? code.charAt(0) + code.slice(1).toLowerCase().replaceAll('_', ' ') : '');
