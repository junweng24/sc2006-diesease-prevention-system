/**
 * «startup» Route table. Each route is one state of the dialog map (docs/03-dialog-map.md).
 * Public and admin screens are separate modules (NFR-07); admin routes are wrapped in
 * RequireAuth, but the server also checks every admin request (NFR-01).
 */
import { Navigate, Route, Routes } from 'react-router-dom';

import AdminLayout from './components/AdminLayout.jsx';
import PublicLayout from './components/PublicLayout.jsx';
import RequireAuth from './components/RequireAuth.jsx';

import AlertDetailPage from './pages/public/AlertDetailPage.jsx';
import ClinicLocatorPage from './pages/public/ClinicLocatorPage.jsx';
import HomePage from './pages/public/HomePage.jsx';
import HotspotMapPage from './pages/public/HotspotMapPage.jsx';
import ReportConfirmationPage from './pages/public/ReportConfirmationPage.jsx';
import ReportHotspotPage from './pages/public/ReportHotspotPage.jsx';
import SubscribePage from './pages/public/SubscribePage.jsx';
import UnsubscribePage from './pages/public/UnsubscribePage.jsx';
import VolunteerPage from './pages/public/VolunteerPage.jsx';
import VolunteerRegistrationForm from './pages/public/VolunteerRegistrationForm.jsx';

import ActivityForm from './pages/admin/ActivityForm.jsx';
import ActivityStatusPage from './pages/admin/ActivityStatusPage.jsx';
import AdminDashboardPage from './pages/admin/AdminDashboardPage.jsx';
import AdminLoginPage from './pages/admin/AdminLoginPage.jsx';
import AlertManagementPage from './pages/admin/AlertManagementPage.jsx';
import CreateAlertForm from './pages/admin/CreateAlertForm.jsx';
import HotspotManagementPage from './pages/admin/HotspotManagementPage.jsx';
import HotspotReviewPage from './pages/admin/HotspotReviewPage.jsx';
import VolunteerManagementPage from './pages/admin/VolunteerManagementPage.jsx';

export default function App() {
  return (
    <Routes>
      <Route element={<PublicLayout />}>
        <Route index element={<HomePage />} />
        <Route path="alerts/:id" element={<AlertDetailPage />} />
        <Route path="hotspots" element={<HotspotMapPage />} />
        <Route path="report" element={<ReportHotspotPage />} />
        <Route path="report/confirmation/:referenceId" element={<ReportConfirmationPage />} />
        <Route path="volunteer" element={<VolunteerPage />} />
        <Route path="volunteer/:activityId/register" element={<VolunteerRegistrationForm />} />
        <Route path="subscribe" element={<SubscribePage />} />
        <Route path="unsubscribe/:token" element={<UnsubscribePage />} />
        <Route path="clinics" element={<ClinicLocatorPage />} />
      </Route>

      <Route path="admin/login" element={<AdminLoginPage />} />
      <Route
        path="admin"
        element={(
          <RequireAuth>
            <AdminLayout />
          </RequireAuth>
        )}
      >
        <Route index element={<AdminDashboardPage />} />
        <Route path="reports" element={<HotspotReviewPage />} />
        <Route path="reports/:referenceId" element={<HotspotReviewPage />} />
        <Route path="hotspots" element={<HotspotManagementPage />} />
        <Route path="alerts" element={<AlertManagementPage />} />
        <Route path="alerts/new" element={<CreateAlertForm />} />
        <Route path="activities" element={<VolunteerManagementPage />} />
        <Route path="activities/new" element={<ActivityForm />} />
        <Route path="activities/:id/edit" element={<ActivityForm />} />
        <Route path="activities/:id" element={<ActivityStatusPage />} />
      </Route>

      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
}
