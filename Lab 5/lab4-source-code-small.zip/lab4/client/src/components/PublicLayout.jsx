/**
 * «boundary» Shell for all public pages: top navigation + page content (NFR-09 responsive).
 */
import { Link, NavLink, Outlet } from 'react-router-dom';

import Brand from './Brand.jsx';

export default function PublicLayout() {
  return (
    <>
      <header className="site-header">
        <div className="site-header-inner">
          <Brand to="/" subtitle="Singapore" />
          <nav className="nav" aria-label="Main">
            <NavLink to="/" end>Alerts</NavLink>
            <NavLink to="/hotspots">Hotspot Map</NavLink>
            <NavLink to="/report">Report a Hotspot</NavLink>
            <NavLink to="/volunteer">Volunteer</NavLink>
            <NavLink to="/clinics">Clinics</NavLink>
            <NavLink to="/subscribe">Get Alerts</NavLink>
          </nav>
        </div>
      </header>
      <main>
        <Outlet />
      </main>
      <footer className="site-footer">
        <div className="site-footer-inner">
          <span>Disease Prevention System · SC2006 Team VibeCoders prototype</span>
          <span>
            Data: NEA dengue clusters &amp; MOH CHAS clinics (data.gov.sg), maps by OneMap ·{' '}
            <Link to="/admin/login">Officials login</Link>
          </span>
        </div>
      </footer>
    </>
  );
}
