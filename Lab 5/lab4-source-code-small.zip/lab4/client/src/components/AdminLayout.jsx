/**
 * «boundary» Tabbed shell for the officials' portal ("Admin Management" state on the dialog
 * map). Logout is reachable from every tab (UC18). If any admin API call reports that the
 * session has ended, the official is sent back to the login page (UC7 1a).
 */
import { useEffect } from 'react';
import { NavLink, Outlet, useNavigate } from 'react-router-dom';

import { api, SESSION_EXPIRED_EVENT } from '../api/ApiClient.js';
import Brand from './Brand.jsx';

export default function AdminLayout() {
  const navigate = useNavigate();

  useEffect(() => {
    const onExpired = () => navigate('/admin/login', {
      replace: true, state: { message: 'Session expired, please log in again.' },
    });
    window.addEventListener(SESSION_EXPIRED_EVENT, onExpired);
    return () => window.removeEventListener(SESSION_EXPIRED_EVENT, onExpired);
  }, [navigate]);

  const handleLogout = async () => {
    await api.logout().catch(() => {});
    navigate('/admin/login', { replace: true, state: { message: 'You have logged out.' } });
  };

  return (
    <div className="admin-theme">
      <header className="site-header admin-header">
        <div className="site-header-inner">
          <Brand to="/admin" subtitle="Officials portal" />
          <nav className="nav" aria-label="Officials portal">
            <NavLink to="/admin" end>Dashboard</NavLink>
            <NavLink to="/admin/reports">Hotspot Reports</NavLink>
            <NavLink to="/admin/hotspots">Hotspots</NavLink>
            <NavLink to="/admin/alerts">Alerts</NavLink>
            <NavLink to="/admin/activities">Volunteers</NavLink>
          </nav>
          <button type="button" className="btn btn-sm" onClick={handleLogout}>Logout</button>
        </div>
      </header>
      <main>
        <Outlet />
      </main>
    </div>
  );
}
