/**
 * «boundary» Location lookup (UC2 Geolocation Lookup): search a Singapore address or postal
 * code through OneMap, or use the device's GPS. Included by UC1, UC3, UC17 and UC19.
 */
import { useState } from 'react';

import { api } from '../api/ApiClient.js';

/**
 * @param {{onSelect: (loc: {latitude: number, longitude: number, address?: string|null,
 *            postalCode?: string|null}) => void, placeholder?: string, allowGps?: boolean}} props
 */
export default function AddressSearch({ onSelect, placeholder = 'Address, building or postal code', allowGps = true }) {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState([]);
  const [message, setMessage] = useState('');
  const [busy, setBusy] = useState(false);

  const choose = (loc) => {
    setResults([]);
    setMessage('');
    if (loc.address) setQuery(loc.address);
    onSelect(loc);
  };

  // UC2 step 2: typed address → candidate locations.
  const search = async (e) => {
    e?.preventDefault();
    if (!query.trim()) return;
    setBusy(true);
    try {
      const found = await api.searchAddress(query);
      if (found.length === 0) {
        setResults([]);
        setMessage('Address not found, please try another address or pick a point on the map.');
      } else if (found.length === 1) {
        choose(found[0]);
      } else {
        setResults(found.slice(0, 6));
        setMessage('');
      }
    } catch {
      setMessage('Address search is unavailable right now. Please pick a point on the map.');
    } finally {
      setBusy(false);
    }
  };

  // UC2 step 1: GPS position (UC2 2a if the user denies permission).
  const useGps = () => {
    if (!navigator.geolocation) {
      setMessage('This browser cannot detect your location. Please search for an address.');
      return;
    }
    setBusy(true);
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        setBusy(false);
        choose({ latitude: pos.coords.latitude, longitude: pos.coords.longitude, address: null });
      },
      () => {
        setBusy(false);
        setMessage('Automatic location detection is disabled. Please search for an address.');
      },
      { timeout: 10000 },
    );
  };

  return (
    <div>
      {/* A div, not a <form>: this component is also used inside other forms. */}
      <div className="search-bar" role="search">
        <input
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          onKeyDown={(e) => { if (e.key === 'Enter') search(e); }}
          placeholder={placeholder}
          aria-label="Search address"
        />
        <button type="button" className="btn btn-primary" onClick={search} disabled={busy}>Search</button>
        {allowGps && (
          <button type="button" className="btn" onClick={useGps} disabled={busy} title="Use my current location">
            Use my location
          </button>
        )}
      </div>
      {message && <p className="field-error" style={{ marginTop: 6 }}>{message}</p>}
      {results.length > 0 && (
        <ul className="search-results" aria-label="Search results">
          {results.map((r) => (
            <li key={`${r.latitude},${r.longitude},${r.address}`}>
              <button type="button" onClick={() => choose(r)}>{r.address}</button>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
