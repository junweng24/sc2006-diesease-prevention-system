/**
 * «boundary» Small coloured label for a severity, risk level or status code.
 */
import { humanise } from '../utils/format.js';

/** @param {{value: string, label?: string}} props */
export default function Badge({ value, label }) {
  return <span className={`badge badge-${value}`}>{label ?? humanise(value)}</span>;
}
