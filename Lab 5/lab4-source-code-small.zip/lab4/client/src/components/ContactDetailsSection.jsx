/**
 * «boundary» Optional, collapsible contact-details fields for a hotspot report
 * (UC5, «extend» UC3). Fields are clearly marked optional (NFR-10).
 */
import { useState } from 'react';

/**
 * @param {{value: {name?: string, phone?: string, email?: string},
 *          onChange: (v: object) => void, errors?: Record<string, string>}} props
 */
export default function ContactDetailsSection({ value, onChange, errors = {} }) {
  const [open, setOpen] = useState(false);

  const toggle = (e) => {
    setOpen(e.target.checked);
    if (!e.target.checked) onChange({}); // UC5 1a: unchecking clears the fields
  };
  const set = (field) => (e) => onChange({ ...value, [field]: e.target.value });

  return (
    <div className="form">
      <label className="check">
        <input type="checkbox" checked={open} onChange={toggle} />
        <span>
          I am happy to be contacted about this report
          <span className="field-hint" style={{ display: 'block' }}>
            Optional. Officials may call you to locate the site.
          </span>
        </span>
      </label>
      {open && (
        <div className="grid grid-3">
          <label className="field">
            <span>Name</span>
            <input value={value.name ?? ''} onChange={set('name')} autoComplete="name" />
          </label>
          <label className="field">
            <span>Phone</span>
            <input
              inputMode="tel" value={value.phone ?? ''} onChange={set('phone')} placeholder="8 digits"
              className={errors['contact.phone'] ? 'input-error' : ''} autoComplete="tel"
            />
            {errors['contact.phone'] && <p className="field-error">{errors['contact.phone']}</p>}
          </label>
          <label className="field">
            <span>Email</span>
            <input
              type="email" value={value.email ?? ''} onChange={set('email')}
              className={errors['contact.email'] ? 'input-error' : ''} autoComplete="email"
            />
            {errors['contact.email'] && <p className="field-error">{errors['contact.email']}</p>}
          </label>
          <small className="muted">Your details are only visible to authorised officials (PDPA).</small>
        </div>
      )}
    </div>
  );
}
