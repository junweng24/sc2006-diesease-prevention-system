/**
 * «boundary» Logo + product name, shown in both the public and the officials' headers.
 */
import { Link } from 'react-router-dom';

/** @param {{to: string, subtitle: string}} props */
export default function Brand({ to, subtitle }) {
  return (
    <Link to={to} className="brand">
      <span className="brand-mark" aria-hidden="true">
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
          <path d="M12 3l7 3v5c0 4.5-3 8.4-7 10-4-1.6-7-5.5-7-10V6l7-3z" />
          <path d="M9 12l2 2 4-4" />
        </svg>
      </span>
      <span>
        Disease Prevention
        <small>{subtitle}</small>
      </span>
    </Link>
  );
}
