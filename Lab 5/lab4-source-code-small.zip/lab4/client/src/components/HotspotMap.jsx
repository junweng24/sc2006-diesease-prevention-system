/**
 * «boundary» Interactive map (Lab 2 "Interactive Hotspot Map"). Draws dengue clusters as
 * polygons coloured by risk level and official hotspots as circle markers (UC1, FR-04..06),
 * with a legend explaining the colours (FR-05).
 * Reused by the public map, the report form (pin picker), the clinic locator and the
 * officials' pages.
 */
import { useEffect } from 'react';
import { CircleMarker, MapContainer, Polygon, Popup, TileLayer, Tooltip, useMap, useMapEvents } from 'react-leaflet';

import { diseaseLabel } from '../constants.js';

/** Centre of Singapore, the default view when GPS is denied (UC2 2a). */
export const SINGAPORE_CENTER = [1.3521, 103.8198];
export const DEFAULT_ZOOM = 12;
export const STREET_ZOOM = 15;

const RISK_COLOURS = { HIGH: '#d32f2f', LOW: '#f9a825' };
const CLINIC_COLOUR = '#2e7d32';
const PIN_COLOUR = '#1565c0';

/** Calls onPick(lat, lng) when the map is clicked (used to place a report pin). */
function ClickHandler({ onPick }) {
  useMapEvents({ click: (e) => onPick?.(e.latlng.lat, e.latlng.lng) });
  return null;
}

/** Moves the map when `center` or `zoom` changes (MapContainer only reads them once). */
function Recenter({ center, zoom }) {
  const map = useMap();
  useEffect(() => { map.setView(center, zoom ?? map.getZoom()); }, [map, center[0], center[1], zoom]); // eslint-disable-line react-hooks/exhaustive-deps
  return null;
}

/** @param {{items: [string, string, boolean?][]}} props colour, label, isDot */
function Legend({ items }) {
  return (
    <div className="legend" aria-label="Map legend">
      <h4>Legend</h4>
      <ul>
        {items.map(([colour, label, dot]) => (
          <li key={label}>
            <span className={`swatch${dot ? ' swatch-dot' : ''}`} style={{ '--c': colour }} />
            {label}
          </li>
        ))}
      </ul>
    </div>
  );
}

/**
 * @param {{clusters?: object[], hotspots?: object[], clinics?: object[],
 *          center?: [number, number], zoom?: number, small?: boolean, legend?: boolean,
 *          pin?: {latitude: number, longitude: number}|null, pinLabel?: string,
 *          onPick?: (lat: number, lng: number) => void}} props
 */
export default function HotspotMap({
  clusters = [], hotspots = [], clinics = [], center = SINGAPORE_CENTER, zoom, small = false,
  legend = false, pin = null, pinLabel = 'Selected location', onPick,
}) {
  const legendItems = [
    ...(clusters.length ? [[RISK_COLOURS.HIGH, 'High-risk cluster (10+ cases)'], [RISK_COLOURS.LOW, 'Cluster (under 10 cases)']] : []),
    ...(hotspots.length ? [[RISK_COLOURS.HIGH, 'High-risk hotspot', true], [RISK_COLOURS.LOW, 'Hotspot', true]] : []),
    ...(clinics.length ? [[CLINIC_COLOUR, 'CHAS clinic', true]] : []),
    ...(pin ? [[PIN_COLOUR, pinLabel, true]] : []),
  ];

  return (
    <div className="map-wrap">
      <MapContainer
        className={`map${small ? ' map-sm' : ''}`}
        center={center}
        zoom={zoom ?? DEFAULT_ZOOM}
        scrollWheelZoom
        style={onPick ? { cursor: 'crosshair' } : undefined}
      >
        <Recenter center={center} zoom={zoom} />
        {/* OneMap base map (SLA). Tiles are free to use with this attribution. */}
        <TileLayer
          url="https://www.onemap.gov.sg/maps/tiles/Default/{z}/{x}/{y}.png"
          attribution='<img src="https://www.onemap.gov.sg/web-assets/images/logo/om_logo.png" style="height:16px;vertical-align:middle"/> <a href="https://www.onemap.gov.sg/" target="_blank" rel="noopener noreferrer">OneMap</a> &copy; contributors | <a href="https://www.sla.gov.sg/" target="_blank" rel="noopener noreferrer">Singapore Land Authority</a>'
          maxZoom={19}
          minZoom={11}
        />
        {clusters.map((c) => (
          <Polygon
            key={c.clusterId}
            positions={c.boundary.map((p) => [p.latitude, p.longitude])}
            pathOptions={{ color: RISK_COLOURS[c.riskLevel], fillOpacity: 0.35, weight: 2 }}
          >
            <Popup>
              <strong>Dengue cluster</strong><br />
              {c.locality}<br />
              Cases: {c.caseCount} · {c.riskLevel === 'HIGH' ? 'High risk' : 'Lower risk'}
            </Popup>
          </Polygon>
        ))}
        {hotspots.map((h) => (
          <CircleMarker
            key={h.id}
            center={[h.location.latitude, h.location.longitude]}
            radius={10}
            pathOptions={{ color: RISK_COLOURS[h.riskLevel], fillOpacity: 0.5 }}
          >
            <Popup>
              <strong>{diseaseLabel(h.diseaseType)} hotspot</strong><br />
              {h.location.address}<br />
              Cases: {h.caseCount} · {h.riskLevel === 'HIGH' ? 'High risk' : 'Lower risk'}<br />
              <small>{h.source === 'VERIFIED_REPORT' ? 'Verified public report' : 'Added by officials'}</small>
            </Popup>
          </CircleMarker>
        ))}
        {clinics.map((c) => (
          <CircleMarker
            key={c.code}
            center={[c.location.latitude, c.location.longitude]}
            radius={7}
            pathOptions={{ color: CLINIC_COLOUR, fillOpacity: 0.6 }}
          >
            <Popup>
              <strong>{c.name}</strong><br />
              {c.location.address}<br />
              {c.phone && <>Tel: {c.phone}<br /></>}
              {c.distanceKm} km away
            </Popup>
          </CircleMarker>
        ))}
        {pin && (
          <CircleMarker
            center={[pin.latitude, pin.longitude]}
            radius={9}
            pathOptions={{ color: '#fff', weight: 3, fillColor: PIN_COLOUR, fillOpacity: 1 }}
          >
            <Tooltip direction="top" offset={[0, -8]}>{pinLabel}</Tooltip>
          </CircleMarker>
        )}
        {onPick && <ClickHandler onPick={onPick} />}
      </MapContainer>
      {legend && legendItems.length > 0 && <Legend items={legendItems} />}
    </div>
  );
}
