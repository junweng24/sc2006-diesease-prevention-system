/**
 * «boundary» Route guard: shows admin pages only if the server confirms a valid session,
 * otherwise redirects to Admin Login. This is for user experience only. The real access
 * control is on the server (requireOfficial middleware, NFR-01). A session that ends while
 * the official is working is handled by AdminLayout.
 */
import { useEffect, useState } from 'react';
import { Navigate } from 'react-router-dom';

import { api } from '../api/ApiClient.js';

export default function RequireAuth({ children }) {
  const [state, setState] = useState('checking'); // 'checking' | 'ok' | 'denied'

  useEffect(() => {
    api.me().then(() => setState('ok')).catch(() => setState('denied'));
  }, []);

  if (state === 'checking') return <p className="page muted">Checking session…</p>;
  if (state === 'denied') return <Navigate to="/admin/login" replace />;
  return children;
}
