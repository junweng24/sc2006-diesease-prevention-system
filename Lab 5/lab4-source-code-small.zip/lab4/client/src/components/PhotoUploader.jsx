/**
 * «boundary» Optional photo attachment for a hotspot report (UC4, «extend» UC3).
 * Checks JPEG / under 5 MB in the browser for quick feedback; the server checks again.
 * Large photos are shrunk in the browser before upload (UC4 special requirement), which also
 * drops the EXIF block with the phone's GPS position.
 */
import { useEffect, useState } from 'react';

const MAX_BYTES = 5 * 1024 * 1024;
/** Longest side after compression; plenty for an official to judge a breeding site. */
const MAX_DIMENSION = 1600;
const JPEG_QUALITY = 0.82;

/**
 * Re-encodes a photo as a smaller JPEG. If the browser cannot do it, the original is kept.
 * @param {File} file
 * @returns {Promise<File>}
 */
async function compress(file) {
  try {
    const bitmap = await createImageBitmap(file); // applies the EXIF orientation
    const scale = Math.min(1, MAX_DIMENSION / Math.max(bitmap.width, bitmap.height));
    const canvas = document.createElement('canvas');
    canvas.width = Math.round(bitmap.width * scale);
    canvas.height = Math.round(bitmap.height * scale);
    canvas.getContext('2d').drawImage(bitmap, 0, 0, canvas.width, canvas.height);
    bitmap.close();
    const blob = await new Promise((resolve) => canvas.toBlob(resolve, 'image/jpeg', JPEG_QUALITY));
    if (!blob || blob.size >= file.size) return file;
    return new File([blob], file.name.replace(/\.\w+$/, '') + '.jpg', { type: 'image/jpeg' });
  } catch {
    return file;
  }
}

/**
 * @param {{photo: File|null, onChange: (file: File|null) => void, error?: string}} props
 */
export default function PhotoUploader({ photo, onChange, error: serverError }) {
  const [error, setError] = useState('');
  const [previewUrl, setPreviewUrl] = useState(null);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (!photo) { setPreviewUrl(null); return undefined; }
    const url = URL.createObjectURL(photo);
    setPreviewUrl(url);
    return () => URL.revokeObjectURL(url);
  }, [photo]);

  const handleFile = async (e) => {
    const file = e.target.files?.[0] ?? null;
    e.target.value = '';
    if (!file) return;
    if (file.type !== 'image/jpeg' || file.size >= MAX_BYTES) {
      setError('File must be JPEG format under 5MB'); // UC4 exception 2a
      return;
    }
    setError('');
    setBusy(true);
    onChange(await compress(file));
    setBusy(false);
  };

  const shown = error || serverError;
  return (
    <div className="field">
      {!photo && (
        <input type="file" accept="image/jpeg" capture="environment" onChange={handleFile} disabled={busy} />
      )}
      <span className="field-hint">JPEG only, under 5 MB. Location data inside the photo is removed.</span>
      {busy && <span className="muted small">Preparing photo…</span>}
      {shown && <p className="field-error">{shown}</p>}
      {previewUrl && (
        <div className="photo-preview">
          <img src={previewUrl} alt="Selected hotspot" />
          <div>
            <div className="small muted">{photo.name} · {(photo.size / 1024).toFixed(0)} KB</div>
            <button type="button" className="btn btn-sm" onClick={() => onChange(null)}>Remove / change photo</button>
          </div>
        </div>
      )}
    </div>
  );
}
