/**
 * Option lists shared by several pages. The server validates every value again (NFR-04).
 */

/** The five URA planning regions, plus "ALL" (alerts for everyone). */
export const REGIONS = ['ALL', 'Central', 'East', 'North', 'North-East', 'West'];
export const regionLabel = (r) => (r === 'ALL' ? 'All regions' : r);

export const SEVERITIES = ['LOW', 'MEDIUM', 'HIGH', 'CRITICAL'];

/** Matches BreedingSiteType on the server. */
export const SITE_TYPES = [
  ['STAGNANT_WATER', 'Stagnant water'],
  ['CONTAINER', 'Container / pail'],
  ['DRAIN', 'Drain / gully'],
  ['PLANT_POT', 'Plant pot / tray'],
  ['CONSTRUCTION_SITE', 'Construction site'],
  ['OTHER', 'Other'],
];
export const siteTypeLabel = (code) => SITE_TYPES.find(([c]) => c === code)?.[1] ?? code;

/** Disease types shown in the public map filter (the server's disease_types table). */
export const DISEASES = [
  ['DENGUE', 'Dengue'],
  ['ZIKA', 'Zika'],
  ['CHIKUNGUNYA', 'Chikungunya'],
];
export const diseaseLabel = (code) => DISEASES.find(([c]) => c === code)?.[1] ?? code;
