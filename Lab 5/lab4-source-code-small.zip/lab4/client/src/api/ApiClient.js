/**
 * «boundary» The only place in the frontend that talks to the REST API. Pages call these
 * functions instead of using fetch directly, so URL or format changes stay in one file.
 */

/** Error thrown for non-2xx responses; `details` holds per-field validation messages. */
export class ApiError extends Error {
  constructor(status, message, details) {
    super(message);
    this.status = status;
    this.details = details ?? {};
  }
}

/** Fired on `window` when an admin call is rejected because the session ended (UC7 1a). */
export const SESSION_EXPIRED_EVENT = 'dps:session-expired';

/**
 * @param {string} path e.g. "/alerts"
 * @param {RequestInit} [options]
 */
async function request(path, options = {}) {
  const isForm = options.body instanceof FormData;
  const res = await fetch(`/api${path}`, {
    credentials: 'same-origin', // send the session cookie on admin calls
    ...options,
    headers: isForm ? options.headers : { 'Content-Type': 'application/json', ...options.headers },
  });
  if (res.status === 204) return null;
  const body = await res.json().catch(() => ({}));
  if (res.status === 401 && path.startsWith('/admin')) {
    window.dispatchEvent(new CustomEvent(SESSION_EXPIRED_EVENT));
  }
  if (!res.ok) throw new ApiError(res.status, body.error ?? 'Request failed', body.details);
  return body;
}

const post = (path, data) => request(path, { method: 'POST', body: JSON.stringify(data) });
const put = (path, data) => request(path, { method: 'PUT', body: JSON.stringify(data) });
const patch = (path, data) => request(path, { method: 'PATCH', body: JSON.stringify(data) });

export const api = {
  // ---- Public (UC1-UC6, UC15, UC16, UC19) ----
  getAlerts: () => request('/alerts'),
  getAlert: (id) => request(`/alerts/${id}`),
  getMapData: (diseaseType) =>
    request(`/map${diseaseType ? `?diseaseType=${encodeURIComponent(diseaseType)}` : ''}`),
  searchAddress: (q) => request(`/map/search?q=${encodeURIComponent(q)}`),
  reverseGeocode: (lat, lng) => request(`/map/reverse?lat=${lat}&lng=${lng}`),
  /** @param {object} report @param {File|null} photo */
  submitReport: (report, photo) => {
    const form = new FormData();
    form.append('report', JSON.stringify(report));
    if (photo) form.append('photo', photo);
    return request('/reports', { method: 'POST', body: form });
  },
  getReportStatus: (ref) => request(`/reports/${encodeURIComponent(ref)}/status`),
  getVolunteerActivities: () => request('/volunteer-activities'),
  registerVolunteer: (activityId, data) =>
    post(`/volunteer-activities/${activityId}/registrations`, data),
  subscribe: (data) => post('/subscriptions', data),
  getUnsubscribeStatus: (token) => request(`/subscriptions/unsubscribe/${encodeURIComponent(token)}`),
  unsubscribe: (token) => request(`/subscriptions/unsubscribe/${encodeURIComponent(token)}`, { method: 'POST' }),
  getNearestClinics: (lat, lng) => request(`/clinics?lat=${lat}&lng=${lng}`),

  // ---- Auth (UC14, UC18) ----
  login: (username, password) => post('/auth/login', { username, password }),
  logout: () => request('/auth/logout', { method: 'POST' }),
  me: () => request('/auth/me'),

  // ---- Admin (UC7-UC11, UC17) ----
  getDashboard: () => request('/admin/dashboard'),
  getReports: (status) => request(`/admin/reports${status ? `?status=${status}` : ''}`),
  getReport: (ref) => request(`/admin/reports/${ref}`),
  reviewReport: (ref, status, version) => patch(`/admin/reports/${ref}`, { status, version }),
  /** URL for an <img>; the browser sends the session cookie with it. */
  reportPhotoUrl: (ref) => `/api/admin/reports/${encodeURIComponent(ref)}/photo`,
  getDiseaseTypes: () => request('/admin/disease-types'),
  getHotspots: () => request('/admin/hotspots'),
  addHotspot: (data) => post('/admin/hotspots', data),
  removeHotspot: (id) => request(`/admin/hotspots/${id}`, { method: 'DELETE' }),
  getAdminAlerts: () => request('/admin/alerts'),
  previewAlert: (data) => post('/admin/alerts/preview', data),
  publishAlert: (data) => post('/admin/alerts', data),
  getActivities: (status) => request(`/admin/activities${status ? `?status=${status}` : ''}`),
  createActivity: (data) => post('/admin/activities', data),
  editActivity: (id, data) => put(`/admin/activities/${id}`, data),
  getActivityStatus: (id) => request(`/admin/activities/${id}/status`),
  getRoster: (id) => request(`/admin/activities/${id}/roster`),
};
