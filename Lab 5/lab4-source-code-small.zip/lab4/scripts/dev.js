/**
 * Starts the API (port 3000) and the web client (port 5173) together for development, with
 * each line of output prefixed by where it came from. Ctrl+C stops both.
 * Usage (from lab3/): npm run dev
 */
import { spawn } from 'node:child_process';

const processes = [
  { name: 'api', dir: 'server', colour: 36 },
  { name: 'web', dir: 'client', colour: 35 },
].map(({ name, dir, colour }) => {
  const child = spawn('npm', ['run', 'dev', '--prefix', dir], {
    shell: true,
    env: { ...process.env, DEV_CLIENT_URL: 'http://localhost:5173' }, // for unsubscribe links
  });
  const tag = `\x1b[${colour}m[${name}]\x1b[0m `;
  const print = (stream) => (chunk) => {
    for (const line of chunk.toString().split(/\r?\n/)) if (line.trim()) stream.write(`${tag}${line}\n`);
  };
  child.stdout.on('data', print(process.stdout));
  child.stderr.on('data', print(process.stderr));
  child.on('exit', (code) => {
    console.log(`${tag}stopped (exit code ${code})`);
    stopAll();
  });
  return child;
});

console.log('Website: http://localhost:5173   Officials portal: http://localhost:5173/admin/login');

let stopping = false;
function stopAll() {
  if (stopping) return;
  stopping = true;
  for (const child of processes) if (child.exitCode === null) child.kill();
  setTimeout(() => process.exit(0), 500);
}
process.on('SIGINT', stopAll);
process.on('SIGTERM', stopAll);
