# 4. System Architecture

**Status:** DRAFT for team review (AI-assisted, see README)

## 4.1 Architectural style

![Architecture](diagrams/04-architecture.png)

*(Rendered image. Editable source: `diagrams/src/04-architecture.html`, rendered with headless Chrome; see the comment at the top of that file.)*

The system uses a **3-tier client–server architecture**. The application tier is a **layered (Boundary–Control–Entity) design**.

- **Presentation tier:** a React single-page application (SPA) in the browser. It contains the boundary classes for both the public website and the officials' portal.
- **Application tier:** a Node.js / Express REST API with four layers:
  1. HTTP boundary: routes and middleware
  2. Control classes
  3. Entity classes
  4. Repositories (containers)

  It also has boundary adapters for external systems.
- **Data tier:** a PostgreSQL relational database, plus file storage for uploaded photos.

Each layer only calls the layer directly below it. External systems are only reached through adapter or channel classes.

```mermaid
flowchart TB
  subgraph Client["Presentation tier — Browser (React SPA)"]
    direction LR
    PUB["Public pages<br/>Home, Map, Report,<br/>Volunteer, Subscribe"]
    ADM["Admin pages<br/>Login, Dashboard, Reports,<br/>Hotspots, Alerts, Volunteers"]
    API_C["ApiClient"]
    PUB --> API_C
    ADM --> API_C
  end

  subgraph Server["Application tier — Node.js + Express"]
    direction TB
    ROUTES["«boundary» Routes<br/>publicRoutes · authRoutes · adminRoutes"]
    MW["«boundary» Middleware<br/>requireOfficial · errorHandler"]
    CTRL["«control» Controllers<br/>Map · HotspotReport · HotspotMgmt · PublicAlert<br/>Subscription · VolunteerActivity · VolunteerEnrollment · Auth"]
    SVC["«control» NotificationService · InputValidator"]
    ENT["«entity» Domain classes"]
    REPO["«container» Repositories"]
    ADP["«boundary» OneMapAdapter · DataGovAdapter"]
    CH["«boundary» SmsChannel · EmailChannel"]
    ROUTES --> MW --> CTRL
    CTRL --> SVC
    CTRL --> ENT
    CTRL --> REPO
    CTRL --> ADP
    SVC --> CH
    SVC --> REPO
    REPO --> ENT
  end

  subgraph Data["Data tier"]
    DB[("PostgreSQL")]
    FS[["Photo storage<br/>(uploads/)"]]
  end

  subgraph Ext["External systems"]
    OM["OneMap API<br/>(geocoding, base map)"]
    DG["data.gov.sg API<br/>(dengue clusters)"]
    SMSG["SMS gateway"]
    EMG["Email (SMTP)"]
  end

  API_C -- "HTTPS / JSON (REST)" --> ROUTES
  REPO --> DB
  CTRL --> FS
  ADP --> OM
  ADP --> DG
  CH --> SMSG
  CH --> EMG
  PUB -. "map tiles" .-> OM
```

## 4.2 Why this architecture

| Concern | How the architecture addresses it |
|---|---|
| **NFR-07** Public and admin functions are separate modules | Separate route modules (`publicRoutes` vs `adminRoutes`) and separate page folders (`pages/public` vs `pages/admin`). Admin routes are guarded by one piece of middleware. |
| **NFR-01 / NFR-02** Security | Access control is enforced on the **server** (middleware), not just by hiding UI. Personal data is only returned by admin endpoints. |
| **NFR-08** Scalability / extensibility | New disease types are data rows, not code. New notification channels are new `NotificationChannel` classes. New data sources are new adapters. |
| **NFR-05 / NFR-06** Performance | The SPA loads once and later navigation needs no page reload. Dengue clusters are cached in the DB, so the map does not wait on data.gov.sg for every visit. |
| **UC1 2a** External API unavailable | `MapController` falls back to the last cached snapshot with a "last synced" timestamp |
| **Testability (Lab 4)** | Control classes receive repositories and adapters through their constructors, so tests can pass in fakes |
| **Low coupling, high cohesion** | Each layer has one job. The UI never talks to the DB or external APIs directly, except for map tiles. |

## 4.3 Technology stack

| Layer | Choice | Justification |
|---|---|---|
| Frontend | **React 18 + Vite**, **React Router** | Most common SPA library with a large ecosystem. The team's bolt.host mock-up is already React-style. Vite gives fast dev reloads. |
| Map | **Leaflet + react-leaflet** with **OneMap** base tiles | Free, lightweight, and works well on mobile (NFR-09). OneMap is the official Singapore base map. |
| Backend | **Node.js 20+ + Express 4** | Same language (JavaScript) as the frontend, so there is one language for the whole team. Express is minimal and easy to learn. |
| Database | **PostgreSQL** (accessed via `pg`) | Relational data with clear relationships (activities ↔ registrations). Supports transactions and unique constraints, which are needed for NFR-03 "no loss or duplication". |
| Auth | **bcrypt** (password hashing) + **JWT** in an httpOnly cookie | Standard, simple, and no external identity provider is needed (UC14 special requirement: hashed passwords) |
| File upload | **multer** | Standard Express middleware for multipart uploads (UC4) |
| Email | **Nodemailer** (SMTP; Ethereal / Gmail for demo) | Free for a course project |
| SMS | `SmsChannel` behind the Strategy interface. **Console/mock implementation** for development; a real gateway (e.g. Twilio trial) is optional. | Real SMS costs money. The interface means swapping it in later is a one-class change. |
| Testing (Lab 4) | **Vitest** (backend unit tests) | Jest-compatible, zero-config with Vite |
| Collaboration | **GitHub** (`softwarelab3/2006-SCEC-I4`) | Required by the lab |

> This stack is a **team decision to confirm**. The Lab 3 manual (2.5) lets you choose any technologies as long as you justify them in the demo and documentation.

## 4.4 Deployment view (demo)

For the Lab 4 demo, everything runs on one laptop:
- `client` runs on Vite dev server port 5173
- `server` runs on port 3000
- PostgreSQL runs locally or on a free hosted instance (e.g. Supabase / Neon)

The Vite dev server proxies `/api` calls to the Express server. A production deployment would serve the built React files from a static host (CDN) and run the API behind HTTPS. This is not required for the course.
