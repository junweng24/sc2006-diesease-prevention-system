"""Builds the three short Lab 4 documents as HTML (run from docs/lab4). Test tables come from results/."""
import base64, html, json
from collections import OrderedDict
e = html.escape
load = lambda p: json.load(open(p, encoding="utf8"))
CSS = "<style>body{font-family:Arial;font-size:10pt}table{border-collapse:collapse;width:100%}th{background-color:#d9e2f3;font-weight:bold}td,th{border:1px solid #999;padding:3pt;font-size:9pt;text-align:left}</style>"
def table(head, rows, raw=False):
    f = (lambda c: str(c)) if raw else (lambda c: e(str(c), quote=False))
    return "<table><tr>" + "".join(f"<th>{e(h)}</th>" for h in head) + "</tr>" + "".join("<tr>" + "".join(f"<td>{f(c)}</td>" for c in r) + "</tr>" for r in rows) + "</table>"
def page(title, body):
    return f'<html><head><meta charset="utf-8"><title>{e(title)}</title>{CSS}</head><body><h1>{e(title)}</h1>{body}</body></html>'
def info(*rows):
    return table(["Item", "Details"], rows, raw=True)
def write(name, title, body):
    open(name, "w", encoding="utf8").write(page(title, body))

# ---------- Test cases ----------
bb, login, review, smoke = (load(f"results/{n}.json") for n in ("blackbox-InputValidator", "basispath-login", "basispath-reviewReport", "smoke"))
before = {r["id"]: r for r in load("results/run1-before-fix/blackbox-InputValidator.json")}
img = lambda n: '<img width="460" src="data:image/png;base64,%s">' % base64.b64encode(open(f"diagrams/{n}-1bit.png", "rb").read()).decode()
pf = lambda ok: "Pass" if ok else "FAIL"
short = lambda s: s.split(":")[0] if "Error:" in s else s
def split_input(s):
    if "): " in s:
        a, t = s.split("): ", 1)
        return a + ")", t
    return tuple(s.split(": ", 1))
groups = OrderedDict()
for r in bb:
    area, text = split_input(r["input"])
    groups.setdefault(area, []).append((r["id"], r["technique"], text, r["expected"], r["actual"], pf(r["pass"])))
bbhtml = "".join(f"<h3>{e(a)}</h3>" + table(["ID", "Type", "Input", "Expected", "Actual", "Result"], rows) for a, rows in groups.items())
defects = [(i, split_input(before[i]["input"])[1], before[i]["expected"], before[i]["actual"]) for i in before if not before[i]["pass"]]
paths_login = {"P1":"1→E1","P2":"1,2→E1","P3":"1,2,3→E1","P4":"1,2,3,4→E2","P5":"1,2,3,4,5,7→E1","P6":"1,2,3,4,5,7→E2","P7":"1,2,3,4,5,6,X"}
paths_rev = {"P1":"1→E1","P2":"1,2→E2","P3":"1,2,3→E3","P4":"1,2,3,4→E2","P5":"1,2,3,4,5,8,6,X","P6":"1,2,3,4,5,6,X","P7":"1,2,3,4,5,6,7,X","P8":"1,2,3,4,5,6,7,9,7,X"}
bp = lambda rs, ps: table(["Path", "Nodes", "Input", "Expected", "Actual", "Result"], [(r["id"], ps[r["id"]], r["input"], short(r["expected"]), short(r["actual"]), pf(r["pass"])) for r in rs])
ec = table(["Input", "Valid classes", "Invalid classes", "Boundaries", "Tests"], [
 ("Phone", "Mobile 8/9, landline 6, +65", "Other first digit, letters, not a string, landline for SMS", "7, 8, 9 digits", "BB-01–10"),
 ("Email", "Normal address", "No @", "TLD 1, 2 letters; length 254, 255", "BB-11–16"),
 ("Photo", "None; JPEG under 5 MB", "Not JPEG; empty", "0, 1 bytes; 5 MB − 1, 5 MB", "BB-17–22"),
 ("Location", "Inside Singapore", "Missing, not numeric, outside", "Each edge and just past it", "BB-23–32"),
 ("Report", "1–1000 characters", "Blank, not text, unknown site type, bad contact", "1000, 1001", "BB-33–40"),
 ("Registration", "All fields, consent ticked", "Blank name, not text, consent false or text", "Name 100, 101", "BB-41–47"),
 ("Activity text", "1–120 characters", "Not text", "Title 120, 121", "BB-48–52"),
 ("Activity date", "Future", "Past, not a date", "1 ms past, now, 1 ms future", "BB-53–56"),
 ("Activity quota", "Whole number 1–500", "Fraction, text, boolean", "0, 1, 500, 501; registered and one below", "BB-57–65"),
 ("Alert", "All fields, known severity", "Unknown severity, not text, no region", "Message 2000, 2001", "BB-66–72"),
 ("Subscription", "SMS, email or both", "Unknown channel, landline, no address, no consent", "0 channels", "BB-73–80"),
 ("Hotspot", "Known disease, whole case count", "Unknown disease, fraction", "Case count −1, 0", "BB-81–85")])
SMOKE = [("UC16","Home feed, alert details",["UC16"]),("UC1, UC2","Map, live NEA clusters, disease filter, OneMap search",["UC1","UC2"]),("UC19","Live CHAS clinics",["UC19"]),
 ("UC15","Subscribe, refusals, unsubscribe link",["UC15"]),("UC3–UC5","Report with photo, PNG refused, field errors",["UC3-UC5","UC4","UC3"]),("UC6","Register, duplicate, quota full",["UC6"]),
 ("UC14, UC18","Login, wrong password, lock-out, logout",["UC14","UC18"]),("NFR-01, NFR-02","Portal and photos refused without login",["NFR-01","NFR-02"]),("FR-18, UC8","Dashboard, review, stale version, public map update",["FR-18","UC8"]),
 ("UC17","Add and remove hotspot",["UC17"]),("UC7","Preview, publish, dispatch, field errors",["UC7"]),("UC9–UC11","Create activity, occupancy, roster, edit",["UC9","UC10","UC11"])]
def smoke_rows():
    rows, seen = [], 0
    for uc, what, keys in SMOKE:
        rs = [r for r in smoke if r["uc"].split()[0] in keys]
        seen += len(rs)
        rows.append((uc, what, f'{sum(r["ok"] for r in rs)}/{len(rs)}'))
    assert seen == len(smoke), (seen, len(smoke))
    return rows
summary = table(["Suite", "Technique", "Passed"], [
 ("InputValidator", "Black box (EC, BVA)", f'{sum(r["pass"] for r in bb)}/{len(bb)}'),
 ("AuthController.login", "Basis path, V(G) = 7", f'{sum(r["pass"] for r in login)}/{len(login)}'),
 ("HotspotReportController.reviewReport", "Basis path, V(G) = 8", f'{sum(r["pass"] for r in review)}/{len(review)}'),
 ("Unsubscribe", "Feature tests", "29/29"),
 ("Smoke test", "Real server, HTTP, live data", f'{sum(r["ok"] for r in smoke)}/{len(smoke)}')])
trace = table(["Requirements", "Use case", "Main classes", "Tests"], [
 ("FR-01–03","UC16 View alerts","PublicAlertController, HomePage","Smoke"),
 ("FR-04–06, NFR-04, NFR-06","UC1 Hotspot map","MapController, DataGovAdapter","Smoke"),
 ("FR-04, FR-08","UC2 Geolocation","MapController, OneMapAdapter","BB-23–32, smoke"),
 ("FR-07–13, NFR-10","UC3–UC5 Report hotspot","HotspotReportController, PhotoSanitizer","BB-01–08, BB-11–40, smoke"),
 ("FR-14–16, NFR-03","UC6 Volunteer","VolunteerEnrollmentController","BB-41–47, smoke"),
 ("FR-22, 24, 26, 27","UC7 Publish alert","PublicAlertController, NotificationService","BB-66–72, smoke"),
 ("FR-18, FR-29","UC8 Review reports","HotspotReportController.reviewReport","P1–P8, smoke"),
 ("FR-23, 25, 30, 31","UC9–UC11 Activities","VolunteerActivityController","BB-48–65, smoke"),
 ("FR-17, NFR-01","UC14 Authenticate","AuthController.login, PasswordHasher","P1–P7, smoke"),
 ("FR-32; unsubscribe (no FR yet)","UC15 Subscribe","SubscriptionController, NotificationService","BB-09–10, BB-73–80, 29 tests, smoke"),
 ("FR-19–21, NFR-08","UC17 Hotspots","HotspotManagementController","BB-81–85, smoke"),
 ("FR-33","UC18 Log out","AuthController.logout","Smoke"),
 ("FR-28","UC19 Nearest clinic","ClinicController, DataGovAdapter","Smoke"),
 ("NFR-02","UC5, UC10","requireOfficial, adminRoutes","Smoke")])
write("Test-Cases-Detailed.html", "Lab 4: Test Cases (detailed)", info(
 ("Team", "VibeCoders, Disease Prevention System"), ("Authors", "TBC by team"),
 ("Environment", "Node.js 24.16, vitest 2.1.9, Windows 11, 2 Nov 2026"),
 ("To run", "<code>cd lab4/server</code>, then <code>npm test</code> and <code>npm run smoke</code>"),
 ("AI use", "Drafted with Claude Code; team to review. Actual outputs were recorded by the test run."))
 + "<h2>1. Summary</h2>" + summary
 + "<h2>2. Black-box: InputValidator</h2><p><b>Why:</b> it enforces the rules for every form (NFR-03, NFR-04).</p><p><b>EC</b> = equivalence class. <b>BVA</b> = boundary value. Each test changes one field, so a failure points to one rule.</p>"
 + "<h3>Equivalence classes and boundaries</h3>" + ec
 + bbhtml
 + "<h3>Defects found on the first run (all fixed)</h3>" + table(["ID", "Input", "Expected", "Actual, first run"], defects)
 + "<p><b>Effect:</b> non-text values reached <code>.trim()</code> and gave HTTP 500; a quota of <code>true</code> was stored as 1. Only a direct API call can send these.</p><p><b>Fix:</b> required text must be a string; quota and case count must be a number or numeric string.</p>"
 + "<h2>3. Basis path</h2><p>V(G) = predicates + 1. One test per independent path, using fakes passed through the constructor.</p>"
 + "<h3>AuthController.login (V(G) = 7)</h3><p><b>Why:</b> it controls portal access and the lock-out rule.</p><p>" + img("cfg-login") + "</p>" + bp(login, paths_login)
 + "<h3>HotspotReportController.reviewReport (V(G) = 8)</h3><p><b>Why:</b> it combines concurrent-edit checks, status rules and a map update.</p><p>" + img("cfg-reviewReport") + "</p><p>Node 8 leads to node 6 because the code has two consecutive <code>if</code> statements.</p>" + bp(review, paths_rev)
 + "<h2>4. Smoke test</h2><p>Real server, throwaway database, REST API. No browser clicks: rehearse the forms by hand.</p>" + table(["Area", "Checked", "Passed"], smoke_rows())
 + "<h2>5. Traceability</h2>" + trace)

three = ["Test Input", "Expected Output", "Actual Output"]
bp3 = lambda rs: table(three, [(r["id"] + ": " + r["input"], short(r["expected"]), short(r["actual"])) for r in rs])
write("Test-Cases-and-Results.html", "Lab 4: Test Cases and Testing Results",
 "<p>All 100 cases pass. Actual outputs were recorded by the final test run, after fixing 7 defects the first black-box run found.</p>"
 + "<h2>1. Black box: InputValidator (control class)</h2>" + table(three, [(r["input"], r["expected"], r["actual"]) for r in bb])
 + "<h2>2. Basis path: AuthController.login</h2>" + bp3(login)
 + "<h2>3. Basis path: HotspotReportController.reviewReport</h2>" + bp3(review))

# ---------- AI report ----------
write("AI-Report.html", "Lab 4: AI Report", info(
 ("Team", "VibeCoders, Disease Prevention System"), ("Authors", "TBC by team"),
 ("Tool", "Claude Code (Claude Opus 5.5), not Cline"),
 ("Setup", "2 Nov 2026, by Yim Zheng Rong. Each exercise used a new agent and its own copy of the project."),
 ("AI use", "This report was also AI-drafted; team to review. The codebase was largely AI-drafted, which may have helped the agents."))
 + "<h2>1. Exercise 3.3.2: Regenerate a deleted class</h2>"
 + info(("Class", "<code>InputValidator</code> (280 lines, 85 tests)"),
  ("Prompt", "One prompt: recreate the deleted class. Do not read outside the folder or change the tests. Report the rules you had to guess."),
  ("Materials", "Black-box tests, the rest of the codebase, design documents"),
  ("Iterations", "None; the first version passed. The agent says it read nothing outside its folder, but we cannot prove that."))
 + "<h3>Results</h3>" + table(["Check", "Result"], [
  ("Visible tests, first run", "85/85"), ("Smoke test, unseen by the agent", "46/46 (the test had 46 checks then)"),
  ("Old vs new class on 73 untested inputs", "55 same, 18 different"),
  ("Size", "348 lines vs our 280")])
 + "<h3>The 18 differences</h3>" + table(["Count", "Type", "Examples"], [
  ("12", "AI stricter, arguably better", "Unknown activity priority, non-text alert category or region, digits in a top-level domain"),
  ("6", "Judgement calls", "Regression: <code>6591234567</code> is valid in ours, refused by the AI's. Others include length after trimming; numeric timestamp, numeric photo size and empty case count refused.")], raw=True)
 + "<h3>Reflection</h3><ul><li><b>Met expectations:</b> yes. Working, documented code on the first try.</li><li><b>Decision:</b> kept our class, because the AI's was unreviewed and differs on untested inputs.</li><li><b>Lesson:</b> passing the tests does not make two classes equivalent.</li><li><b>Lab 5:</b> test the 65 prefix, consider the stricter checks, and fix the 7 document and test mismatches the agent listed.</li></ul>"
 + "<h2>2. Exercise 3.3.3: Finish an unfinished feature</h2>"
 + info(("Feature", "Unsubscribe from alerts (UC15 notes, PDPA TODO in <code>SubscriptionController</code>)"),
  ("Prompt", "One prompt: add an unsubscribe link, withdraw consent and show a result page. Follow the architecture, add vitest tests, report what you did not check."),
  ("Iterations", "9 test runs by the agent. It fixed a vitest and <code>node:sqlite</code> load failure, and broke its code on purpose to check its tests."),
  ("Output", "19 files, 29 tests, a database upgrade and a new page"))
 + "<h3>Good decisions it made unprompted</h3><ul><li>The link only shows a confirm button, because mail scanners open links automatically.</li><li>Tokens are random and stored, not signed with the JWT secret, whose default is public.</li><li>Unsubscribing erases the stored phone and email.</li><li>Alert SMS is shortened so the link fits in 160 characters.</li></ul>"
 + "<h3>Our checks before merging</h3>" + table(["Check", "Result"], [
  ("All tests", "129/129"), ("Smoke test, with 5 unsubscribe checks", "51/51"), ("Client build", "Pass"), ("<code>npm run dev</code> (agent had not run it)", "Works"),
  ("Lab 3 database upgrade (agent had not run it)", "2 subscribers kept their IDs and got tokens")], raw=True)
 + "<h3>Still needs people</h3><ul><li>Update the design documents and diagrams for Lab 5.</li><li>Decide PDPA retention: <code>notification_logs</code> keeps the phone or email.</li><li>Limit the length of confirmation and volunteer-news SMS, and set <code>PUBLIC_BASE_URL</code> for a real deployment.</li></ul>"
 + "<h3>Reflection</h3><ul><li><b>Met expectations:</b> mostly exceeded them; it found the database and mail-scanner problems itself.</li><li><b>Limits:</b> it could not make the PDPA decision or replace our own checks. Students must still be able to explain all 19 files (FAQ 3).</li><li><b>Process slip:</b> it ran a script from another agent in a shared scratch folder, which failed harmlessly. It flagged this itself. Parallel agents should not share a scratch folder.</li></ul>"
 + "<h2>3. Evidence</h2><p>In <code>lab4/docs/lab4/</code>: <code>ai-exercise/prompts.txt</code> (exact prompts), <code>ai-exercise/InputValidator.regenerated.js.txt</code>, <code>ai-exercise/compare-validators.mjs.txt</code>, <code>results/</code>.</p>")

# ---------- Demo script ----------
write("Demo-Script.html", "Lab 4: Demo Script", info(
 ("Team", "VibeCoders, Disease Prevention System"), ("Authors", "TBC by team"),
 ("Story", "A resident reports a dengue risk, an official verifies it and warns the area, and the community responds."),
 ("Time", "About 20 min. If you only have 15 (Lab 4 manual), skip the steps marked optional."),
 ("Roles", "Presenter: ____ | Resident: ____ | Official: ____ | Engineering and traceability: ____"),
 ("Status", "AI-drafted. Functions were checked through the API, but <b>the clicks are not rehearsed. Do one full run-through.</b>"))
 + "<h2>1. Setup</h2>" + table(["When", "Task"], [
  ("Day before", "Record the backup video. Put a JPEG under 5 MB and a PNG on the desktop."),
  ("30 min before", "In <code>lab4/</code>: stop the server, delete <code>server/data/</code>, run <code>npm run setup</code>, then <code>npm run create-official --prefix server -- demo2 ChangeMe123!</code>"),
  ("30 min before", "In <code>lab4/server</code>: <code>npm run smoke</code>. Expect 51/51."),
  ("10 min before", "In <code>lab4/</code>: <code>npm start</code>, open http://localhost:3000. Open the map and search a clinic once."),
  ("Screen", "Window 1: public site. Window 2: officials' portal. Terminal visible, because SMS and email links appear there.")], raw=True)
 + "<h2>2. Live demo (about 14 min)</h2>" + table(["Min", "Use case", "Do", "Say"], [
  ("0:00","Overview","Show the use case diagram.","Residents need no account; officials log in."),
  ("1:00","UC16","Home. Filter East. Open the Tampines alert.","Colour-coded by severity."),
  ("2:00","UC1, UC2","Map. Change the disease filter. Search Tampines.","Live NEA clusters, with cached fallback."),
  ("3:00","UC19","Clinics. Search 639798.","Live CHAS data, sorted by distance."),
  ("4:00","UC15","Get Alerts: SMS and email, 91234567, your email, East, volunteer news, consent.","Terminal shows messages with unsubscribe links."),
  ("5:00","UC3–UC5","Report: try the PNG, then a full report with the JPEG.","Anonymous is allowed. GPS data is stripped. Note the reference ID."),
  ("6:30","UC14","Window 2: <code>/admin/login</code>, officer, ChangeMe123!","Passwords are hashed. Access is enforced on the server."),
  ("7:00","UC8","Open the report, Verify, refresh the public map.","One transaction. Concurrent edits are detected."),
  ("8:00","UC17 (optional)","Add a hotspot with 12 cases, then remove it.","10 or more cases is high risk."),
  ("8:30","UC7","Create an East alert, Preview, Publish.","Dispatch shows sent 2. A failed delivery does not undo publishing."),
  ("9:30","UC9","Create an activity with a future date.","Opted-in subscribers are told."),
  ("10:30","UC6","Community talk helpers (2 slots): register two people, try a third.","Quota full. It cannot be overbooked."),
  ("11:30","UC10, UC11","Show the roster. Try quota 1. Change the venue.","Contacts are officials only. Volunteers are told."),
  ("12:30","Unsubscribe (optional)","Open the terminal link, click the button, publish another East alert.","Sent 0. Opening the link alone changes nothing."),
  ("13:15","UC18, NFR-01","Log out. Open <code>/admin</code>, then <code>/api/admin/dashboard</code>.","Back to login; the API answers 401."),
  ("13:45","UC14 2b (optional)","demo2 with a wrong password, 5 times.","Locked for 15 minutes.")], raw=True)
 + "<h2>3. Engineering and traceability (about 5 min)</h2>" + table(["Point", "Show", "Why"], [
  ("Layers","<code>server/src/</code>","Changes stay in one layer (NFR-07)."),
  ("Strategy","<code>NotificationChannel</code>","A new channel is one new class."),
  ("Observer","<code>PublicAlertController</code> → <code>NotificationService</code>","Publishing is separate from delivery."),
  ("Facade, Singleton, Repository","<code>MapController</code>, <code>Config</code>, <code>repository/</code>","Simple entry point; one configuration; swappable storage."),
  ("Dependency injection","<code>ServerApp</code>","Allows testing with fakes."),
  ("Testing","<code>npm test</code> (129 tests)","Black-box testing found 7 real failures, now fixed.")], raw=True)
 + "<h3>Traceability walk: UC8</h3>" + table(["Step", "Show"], [
  ("Requirement","FR-29: verified reports appear on the public map"),("Use case","UC8, including exception 4a"),("Design","Control class diagram, <code>HotspotReportController</code>"),
  ("Code","<code>reviewReport</code> and its JSDoc"),("Test","Control flow graph, V(G) = 8, paths P1–P8"),("Demo","The Verify step")], raw=True)
 + "<p><b>Future upgrades:</b> real SMS gateway, more diseases, automatic retry, two-factor login.</p><p><b>Tell the TA:</b> AI generated code and documents (FAQ 3). Every member must be able to explain <code>reviewReport</code>, <code>login</code> and the unsubscribe flow.</p>"
 + "<h2>4. If something goes wrong</h2>" + table(["Problem", "Do"], [
  ("Live data or internet down","Show the map's last-synced message (UC1 2a, NFR-04). Skip clinics if it errors. Click the map to place the pin."),
  ("No email link","Ethereal needs internet. Show the SMS lines instead."),
  ("Officer locked","Use demo2, or wait 15 minutes."),
  ("Already subscribed","Use a different phone and email. Do not reset mid-demo."),
  ("Anything else","Stay calm and switch to the backup video at that step."),
  ("Phone view","The navigation bar scrolls sideways.")])
 + "<h2>5. Backup video (about 5:30)</h2>" + table(["Time", "Content"], [
  ("0:00–0:30","Problem and users"),("0:30–1:30","Alerts, map, clinics, subscribe"),("1:30–2:15","Report a hotspot"),("2:15–3:30","Login, verify, publish, SMS in the terminal"),
  ("3:30–4:15","Volunteers: create, fill, roster"),("4:15–4:45","Unsubscribe, logout, access control"),("4:45–5:30","Architecture, patterns, tests, future upgrades")]))
