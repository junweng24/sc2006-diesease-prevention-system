"""Draws the two basis-path control flow graphs as small greyscale PNGs (needs Pillow)."""
import math, sys
from PIL import Image, ImageDraw, ImageFont
S = 1
font = ImageFont.truetype("arial.ttf", 13); small = ImageFont.truetype("arial.ttf", 11); bold = ImageFont.truetype("arialbd.ttf", 14)
def arrow(d, a, b, label=None, off=(4, -14)):
    for p, q in zip(a[:-1] if isinstance(a[0], tuple) else [], a[1:] if isinstance(a[0], tuple) else []): pass
    pts = a if isinstance(a[0], tuple) else [a, b]
    d.line(pts, fill=0, width=1)
    (x1, y1), (x2, y2) = pts[-2], pts[-1]
    ang = math.atan2(y2 - y1, x2 - x1)
    for s in (2.7, -2.7):
        d.line([(x2, y2), (x2 + 8 * math.cos(ang + s), y2 + 8 * math.sin(ang + s))], fill=0, width=1)
    if label:
        mx, my = pts[-2] if len(pts) > 2 else ((x1 + x2) / 2, (y1 + y2) / 2)
        d.text((mx + off[0], my + off[1]), label, font=small, fill=0)
def cfg(title, decisions, normal, path_out):
    """decisions: list of (node, text, exit node label or None, branch-to-exit label, continue label)."""
    w, row, r = 640, 62, 16
    h = 70 + row * (len(decisions) + len(normal)) + 20
    img = Image.new("L", (w, h), 255); d = ImageDraw.Draw(img)
    d.text((14, 10), title, font=bold, fill=0)
    x = 60; y = 56; prev = None; nodes = {}
    for i, (n, text, exit_lbl, yes, no) in enumerate(decisions):
        d.ellipse((x - r, y - r, x + r, y + r), outline=0, fill=255, width=2)
        tw = d.textlength(n, font=font); d.text((x - tw / 2, y - 8), n, font=font, fill=0)
        d.text((x + r + 8, y - 22), text, font=small, fill=0)
        if exit_lbl:
            ex = 560
            d.rounded_rectangle((ex - 60, y - 13, ex + 70, y + 13), 5, outline=0, fill=235)
            tw = d.textlength(exit_lbl, font=small); d.text((ex + 5 - tw / 2, y - 7), exit_lbl, font=small, fill=0)
            arrow(d, (x + r, y), (ex - 60, y), yes, off=(70, -14))
        if i + 1 < len(decisions) + len(normal):
            arrow(d, (x, y + r), (x, y + row - r), no, off=(5, -7))
        y += row
    for j, (n, text, exit_lbl) in enumerate(normal):
        d.rectangle((x - r, y - r + 2, x + r, y + r - 2), outline=0, fill=255, width=2)
        tw = d.textlength(n, font=font); d.text((x - tw / 2, y - 8), n, font=font, fill=0)
        d.text((x + r + 8, y - 8), text, font=small, fill=0)
        if j + 1 < len(normal):
            arrow(d, (x, y + r - 2), (x, y + row - r + 2))
        y += row
    return img, d
# login
img, d = cfg("AuthController.login  V(G) = 6 + 1 = 7", [
  ("1", "!username ?", "E1 AuthError", "true", "false"),
  ("2", "!password ?", "E1 AuthError", "true", "false"),
  ("3", "official not found ?", "E1 AuthError", "true", "false"),
  ("4", "official.isLocked(now) ?", "E2 AccountLocked", "true", "false"),
  ("5", "password wrong (!ok) ?", None, "", "false: correct"),
], [("6", "reset failures, save, issue token", None), ("X", "return token", None)], None)
# node 5 true branch -> 7 -> locked?
x, y5 = 60, 56 + 62 * 4
d.ellipse((290 - 16, y5 + 40 - 16, 290 + 16, y5 + 40 + 16), outline=0, fill=255, width=2)
d.text((286, y5 + 32), "7", font=font, fill=0)
d.text((312, y5 + 16), "record failure, save; now locked ?", font=small, fill=0)
arrow(d, (76, y5), (274, y5 + 36), "true: wrong", off=(-30, -18))
d.rounded_rectangle((500, y5 + 27, 630, y5 + 53), 5, outline=0, fill=235); d.text((510, y5 + 33), "E2 AccountLocked", font=small, fill=0)
arrow(d, (306, y5 + 40), (500, y5 + 40), "true", off=(70, -14))
d.rounded_rectangle((500, y5 + 78, 630, y5 + 104), 5, outline=0, fill=235); d.text((520, y5 + 84), "E1 AuthError", font=small, fill=0)
arrow(d, [(290, y5 + 56), (290, y5 + 91), (500, y5 + 91)], None, "false", off=(5, -25))
img = img.resize((img.width, img.height + 0)); img.quantize(8).save("cfg-login.png", optimize=True)
# reviewReport
img, d = cfg("HotspotReportController.reviewReport  V(G) = 7 + 1 = 8", [
  ("1", "report not found ? (inside getReport)", "E1 NotFound", "true", "false"),
  ("2", "report.version != expectedVersion ?", "E2 Conflict", "true", "false"),
  ("3", "transition not allowed ?", "E3 Validation", "true", "false"),
  ("4", "updateStatusWithVersion saved nothing ?", "E2 Conflict", "true", "false"),
  ("5", "newStatus = VERIFIED_ACTIVE ?", None, "", "false"),
  ("6", "", None, "", "true"),
  ("7", "", None, "", "false: loop done"),
], [("X", "", None)], None)
base = 56; row = 62
y5, y6, y7, yx = base + row * 4, base + row * 5, base + row * 6, base + row * 7
# 5 true -> 8 -> 6 (two consecutive ifs, so control still reaches node 6)
d.rectangle((300, y5 + 10, 480, y5 + 36), outline=0, fill=255, width=2); d.text((306, y5 + 16), "8  save new hotspot", font=small, fill=0)
arrow(d, (76, y5), (300, y5 + 20), "true", off=(-40, -20))
arrow(d, (300, y5 + 32), (75, y6 - 6))
# 6 false -> X
arrow(d, [(76, y6 + 4), (600, y6 + 4), (600, yx), (76, yx)], None)
d.text((300, y6 - 11), "false", font=small, fill=0)
d.text((86, y6 + 8), "newStatus = RESOLVED ?", font=small, fill=0)
# 7: loop
d.text((86, y7 - 24), "for each linked hotspot: any left ?", font=small, fill=0)
d.rectangle((300, y7 + 12, 480, y7 + 38), outline=0, fill=255, width=2); d.text((306, y7 + 18), "9  remove + save hotspot", font=small, fill=0)
arrow(d, (75, y7 + 6), (300, y7 + 24))
d.text((180, y7 + 19), "true", font=small, fill=0)
arrow(d, [(390, y7 + 12), (390, y7 - 6), (76, y7 - 6)], None)
d.text((84, yx + 6), "return report", font=small, fill=0)
img.quantize(8).save("cfg-reviewReport.png", optimize=True)
