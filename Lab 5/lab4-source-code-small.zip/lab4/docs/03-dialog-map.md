# 3. Dialog Map (refined)

**Status:** DRAFT for team review (AI-assisted, see README)
**Input:** Lab 2 "SC2006 Dialog Diagram.pdf" (VP Online), Figma mock-ups, use cases in doc 01

A dialog map is a state machine of UI screens (Fox p. 420):
- **States** are screens. Each has a `do /` activity.
- **Transitions** are labelled `event [guard] / action`.

Every state maps to a React boundary class in doc 02 §2.5.

## 3.1 What changed from the Lab 2 dialog map

| Change | Reason |
|---|---|
| Added **Alert Detail** state off the Public Alerts (home) page | FR-03 / UC16 |
| Added **Report Confirmation** state with the reference ID; failed validation self-loops on the form | UC3 steps 6–7, NFR-04 |
| Photo upload and contact details are shown as **sub-states of the Report form** | UC4 / UC5 are «extend» use cases that happen inside the same page |
| Volunteer flow now goes Activity List → Volunteer Form → Registration Success, with a **[quota full]** guard | UC6 alternative 2a |
| "Register SMS" renamed **Subscribe to Alerts** (email and/or SMS) | UC15, FR-26/27 |
| Admin login has **[invalid credentials]** and **[account locked]** transitions | UC14 alternatives |
| Admin side is a **tabbed shell**: Dashboard, Hotspot Reports, Hotspots, Alerts, Volunteers. Logout is reachable from every tab. | FR-18, UC18 |
| Added **Report Review**, **Activity Status / Roster** and **Edit Activity** states | UC8, UC10, UC11 |
| **Session expired** transition from any admin state back to Admin Login | UC7 exception 1a, NFR-01 |
| Clinic page kept but marked *optional* | No FR covers it yet; see doc 01 §1.4 item 7 |
| Breeding Sites page **merged into** Report Hotspot page | In the Lab 2 map it duplicated the report flow |

## 3.2 Public website

![Public dialog map](diagrams/03-dialog-map-public.png)

*(Rendered image. The diagram source below is the editable version.)*

```mermaid
stateDiagram-v2
    [*] --> PublicAlerts

    state "Public Alerts (Home)<br/>do / display alert feed" as PublicAlerts
    state "Alert Detail<br/>do / display full alert" as AlertDetail
    state "Hotspot Map<br/>do / display map, clusters, hotspots" as HotspotMap
    state "Report Hotspot Form<br/>do / allow input" as ReportForm
    state "Report Confirmation<br/>do / show reference ID" as ReportConfirm
    state "Volunteer Activities<br/>do / display activity list + open slots" as VolunteerList
    state "Volunteer Form<br/>do / allow input" as VolunteerForm
    state "Registration Success<br/>do / show activity, date, venue" as VolunteerSuccess
    state "Subscribe to Alerts<br/>do / allow input" as Subscribe
    state "Subscription Success" as SubscribeSuccess
    state "Clinic Locator (optional)<br/>do / display map + clinic list" as Clinics

    PublicAlerts --> AlertDetail : select alert
    AlertDetail --> PublicAlerts : back

    PublicAlerts --> HotspotMap : nav "Hotspots"
    PublicAlerts --> ReportForm : nav "Report a Hotspot"
    PublicAlerts --> VolunteerList : nav "Become a Volunteer"
    PublicAlerts --> Subscribe : nav "Get Alerts"
    PublicAlerts --> Clinics : nav "Clinics"

    HotspotMap --> HotspotMap : filter / pan / zoom / search address
    HotspotMap --> ReportForm : "Report a hotspot here"

    state ReportForm {
        [*] --> Location
        Location --> Details : location resolved [OneMap OK]
        Location --> Location : address not found / show error
        Details --> Photo : attach photo (optional)
        Photo --> Details : photo accepted [JPEG and < 5MB]
        Photo --> Photo : invalid file / show warning
        Details --> Contact : add contact details (optional)
        Contact --> Details : confirm [valid email / SG phone]
    }
    ReportForm --> ReportForm : submit [validation fails] / highlight fields
    ReportForm --> ReportConfirm : submit [validation_success] / save, create ref ID
    ReportForm --> PublicAlerts : cancel
    ReportConfirm --> PublicAlerts : done

    VolunteerList --> VolunteerForm : select "Register" [slots > 0]
    VolunteerList --> VolunteerList : select "Register" [quota full] / show "Activity quota full"
    VolunteerForm --> VolunteerForm : submit [invalid or duplicate] / show error
    VolunteerForm --> VolunteerSuccess : submit [validation_success] / save registration
    VolunteerForm --> VolunteerList : cancel
    VolunteerSuccess --> VolunteerList : done

    Subscribe --> Subscribe : save [invalid contact] / highlight field
    Subscribe --> SubscribeSuccess : save [all segments filled and consent given] / send confirmation
    Subscribe --> PublicAlerts : cancel
    SubscribeSuccess --> PublicAlerts : done
```

## 3.3 Officials' portal

![Officials portal dialog map](diagrams/03-dialog-map-admin.png)

*(Rendered image. The diagram source below is the editable version.)*

```mermaid
stateDiagram-v2
    [*] --> AdminLogin

    state "Admin Login<br/>do / allow input" as AdminLogin
    state "Admin Portal (tabbed)" as Portal {
        state "Dashboard<br/>do / display summary of reports, alerts, activities" as Dashboard
        state "Hotspot Reports<br/>do / display report table" as Reports
        state "Report Review<br/>do / display report + photo" as ReportReview
        state "Hotspots (Official Heat Map)<br/>do / display map + hotspot list" as Hotspots
        state "Add Hotspot Form" as AddHotspot
        state "Alerts<br/>do / display alert list" as Alerts
        state "Create Alert<br/>do / allow input + preview" as CreateAlert
        state "Volunteer Activities<br/>do / display deployment list" as Activities
        state "Create / Edit Activity<br/>do / allow input" as ActivityForm
        state "Activity Status<br/>do / show occupancy bar + roster" as ActivityStatus

        [*] --> Dashboard
        Dashboard --> Reports : tab
        Dashboard --> Hotspots : tab
        Dashboard --> Alerts : tab
        Dashboard --> Activities : tab

        Reports --> ReportReview : select report
        ReportReview --> Reports : save status [valid transition] / update DB, refresh map
        ReportReview --> ReportReview : save [version conflict] / reload latest record
        ReportReview --> Reports : back

        Hotspots --> AddHotspot : "Add hotspot"
        AddHotspot --> Hotspots : save [valid] / store hotspot
        AddHotspot --> AddHotspot : save [invalid] / highlight fields
        AddHotspot --> Hotspots : cancel
        Hotspots --> Hotspots : remove [confirmed] / soft-delete hotspot

        Alerts --> CreateAlert : "Create new alert"
        CreateAlert --> CreateAlert : preview / render card + SMS sample
        CreateAlert --> Alerts : publish [valid] / save, dispatch SMS + email
        CreateAlert --> Alerts : cancel

        Activities --> ActivityForm : "Create new deployment" / "Edit"
        ActivityForm --> Activities : save [valid future date and quota ≥ registered] / store, notify subscribers
        ActivityForm --> ActivityForm : save [invalid] / highlight fields
        ActivityForm --> Activities : cancel
        Activities --> ActivityStatus : select activity
        ActivityStatus --> Activities : back
    }

    AdminLogin --> Portal : login [credentials verified] / create session
    AdminLogin --> AdminLogin : login [invalid credentials] / show "Invalid login"
    AdminLogin --> AdminLogin : login [account locked] / show lock message
    Portal --> AdminLogin : logout / invalidate session
    Portal --> AdminLogin : [session expired] / prompt re-login
```

## 3.4 State → boundary class mapping

| Dialog map state | React boundary class |
|---|---|
| Public Alerts (Home) | `HomePage` |
| Alert Detail | `AlertDetailPage` |
| Hotspot Map | `HotspotMapPage` |
| Report Hotspot Form (+ sub-states) | `ReportHotspotPage`, `PhotoUploader`, `ContactDetailsSection` |
| Report Confirmation | `ReportConfirmationPage` |
| Volunteer Activities / Form / Success | `VolunteerPage`, `VolunteerRegistrationForm` |
| Subscribe / Success | `SubscribePage` |
| Clinic Locator | `ClinicLocatorPage` (optional) |
| Admin Login | `AdminLoginPage` |
| Admin Portal shell | `AdminLayout`, `RequireAuth` |
| Dashboard | `AdminDashboardPage` |
| Hotspot Reports / Report Review | `HotspotReviewPage` |
| Hotspots / Add Hotspot | `HotspotManagementPage` |
| Alerts / Create Alert | `AlertManagementPage`, `CreateAlertForm` |
| Volunteer Activities / Create-Edit Activity | `VolunteerManagementPage`, `ActivityForm` |
| Activity Status | `ActivityStatusPage` |
