# 2. Design Class Model

**Status:** DRAFT for team review (AI-assisted, see README)
**Input:** Lab 2 conceptual model (entity / boundary / control objects) + the use cases in doc 01
**Tech stack assumed:** React (frontend) · Node.js + Express (backend) · PostgreSQL (database), see doc 04

This document follows the Lab 3 procedure (3.1.3, Fox pp. 341–345):
1. add a **start-up class**,
2. **distribute control responsibilities** across several control classes,
3. add **container classes** for collections,
4. apply **design patterns**,
5. add **attributes and operations** to every class.

---

## 2.1 From conceptual model to design model

| Lab 2 conceptual class | Design model class(es) | Reason for change |
|---|---|---|
| User (abstract) ← Public User, Government Official User | `Official` only; public user data → `ContactDetails` value object | Public users are **anonymous** (UC3 special req.: anonymous reporting) and never log in. A persistent PublicUser class would never be instantiated, so only officials need an account record. |
| Device | *(removed)* | Not persisted and no behaviour. The browser's geolocation is handled by `MapController` / `GeoLocation`. |
| Hotspot Report Submission | `HotspotReport` + `GeoLocation` + `ContactDetails` | Location and contact are reusable value objects (also used by `Hotspot` and `VolunteerRegistration`). |
| *(implicit)* | `Hotspot` | FR-19..21 need hotspots managed by officials, separate from user reports. A verified report **creates** a `Hotspot`. |
| *(implicit)* | `DengueCluster` | Represents a cluster fetched from data.gov.sg (UC1). |
| Volunteering Submission | `VolunteerRegistration` | Renamed for clarity |
| Volunteer Activity Record | `VolunteerActivity` | Gains operations (`remainingSlots()`, `isFull()`, `refreshStatus()`) |
| Public Alert Record | `PublicAlert` | Gains `toSmsText()` (160-char limit, UC7) |
| Alert Subscription | `AlertSubscription` | Adds `wantsVolunteerNews` (FR-25), `consentGiven` (PDPA) |
| *(implicit, UC7 6a)* | `NotificationLog` | Stores delivery failures for retry |
| Database (entity) | `Database` (singleton connection pool) + **Repository** classes | The "database" is infrastructure, not a domain entity. Repositories act as the container classes. |
| Interactive Hotspot Map, Adding/Removing Hotspot Page, Adding Public Alert Page, Adding Volunteer Activity Page | React page components (see §2.5) | One boundary class per screen of the dialog map |
| Geolocation APIs | `OneMapAdapter`, `DataGovAdapter` | Adapter pattern: one class per external system |
| Gateway APIs (SMS & Email) | `NotificationChannel` interface, `SmsChannel`, `EmailChannel` | Strategy pattern |
| Secure Identity Provider | `AuthController` + `PasswordHasher` + `TokenService` | Implemented in-house (bcrypt + JWT) instead of an external IdP. Simpler for a course project. |
| Hotspot Management Controller | `HotspotReportController` + `HotspotManagementController` | Split for high cohesion: public report flow vs official hotspot CRUD |
| Map Rendering Controller | `MapController` | — |
| Volunteer Enrollment Controller | `VolunteerEnrollmentController` + `VolunteerActivityController` | Split: public registration vs official activity management |
| Public Alert Controller | `PublicAlertController` + `NotificationService` | Notification dispatch is shared by UC7, UC9, UC15, so it gets its own class |
| Authentication Controller | `AuthController` | — |
| Database Transaction Controller | *(replaced by Repositories)* | Repository pattern; see §2.4 |
| *(new)* | `SubscriptionController` | UC15 |
| *(new)* | `InputValidator` | Centralises all validation rules (phone, email, photo, dates). Used by every control class. |
| *(new)* | `ServerApp` (start-up class) | Fox heuristic: system initialisation |

## 2.2 Packages (folders) by stereotype

```
server/src/
  ServerApp.js           «startup»   builds and wires all objects, starts Express
  config/                «utility»   Config (singleton)
  boundary/
    routes/              «boundary»  REST endpoints (HTTP boundary)
    middleware/          «boundary»  authentication / error handling
    adapters/            «boundary»  OneMapAdapter, DataGovAdapter
    channels/            «boundary»  NotificationChannel, SmsChannel, EmailChannel
  control/               «control»   *Controller, NotificationService, InputValidator, auth helpers
  entity/                «entity»    domain classes + enums
  repository/            «container» one repository per persistent entity + Database

client/src/
  main.jsx, App.jsx      «startup»   React root + router
  api/                   «boundary»  ApiClient (frontend → REST API)
  pages/public/          «boundary»  public screens
  pages/admin/           «boundary»  officials' screens
  components/            «boundary»  shared UI pieces (map, forms, layout, route guard)
```

## 2.3 Entity classes

![Entity classes](diagrams/02-entity-classes.png)

*(Rendered image. The diagram source below is the editable version.)*

```mermaid
classDiagram
direction LR

class Official {
  <<entity>>
  -id: number
  -username: string
  -passwordHash: string
  -role: OfficialRole
  -failedLoginAttempts: number
  -lockedUntil: Date
  +isLocked(now: Date) boolean
  +recordFailedLogin(now: Date, maxAttempts: number, lockoutMinutes: number) void
  +resetFailedLogins() void
}

class GeoLocation {
  <<entity>>
  -latitude: number
  -longitude: number
  -address: string
  -postalCode: string
  +isWithinSingapore() boolean
}

class ContactDetails {
  <<entity>>
  -name: string
  -phone: string
  -email: string
  +isEmpty() boolean
}

class HotspotReport {
  <<entity>>
  -referenceId: string
  -location: GeoLocation
  -siteType: BreedingSiteType
  -description: string
  -photoPath: string
  -contact: ContactDetails
  -status: ReportStatus
  -submittedAt: Date
  -reviewedBy: number
  -reviewedAt: Date
  -version: number
  +canTransitionTo(next: ReportStatus) boolean
  +transitionTo(next: ReportStatus, officialId: number, now: Date) void
  +generateReferenceId(now: Date)$ string
}

class Hotspot {
  <<entity>>
  -id: number
  -diseaseType: string
  -location: GeoLocation
  -caseCount: number
  -riskLevel: RiskLevel
  -source: HotspotSource
  -sourceReportId: string
  -isActive: boolean
  -createdBy: number
  -createdAt: Date
  +remove() void
  +fromVerifiedReport(report: HotspotReport, officialId: number, diseaseType: string)$ Hotspot
}

class DengueCluster {
  <<entity>>
  -clusterId: string
  -locality: string
  -caseCount: number
  -boundary: GeoLocation[]
  +riskLevel() RiskLevel
}

class PublicAlert {
  <<entity>>
  -id: number
  -title: string
  -body: string
  -category: string
  -severity: Severity
  -targetRegion: string
  -publishedAt: Date
  -publishedBy: number
  +toSmsText() string
}

class AlertSubscription {
  <<entity>>
  -id: number
  -email: string
  -phone: string
  -channels: ChannelType[]
  -region: string
  -wantsVolunteerNews: boolean
  -consentGiven: boolean
  -createdAt: Date
  +matchesRegion(region: string) boolean
}

class VolunteerActivity {
  <<entity>>
  -id: number
  -title: string
  -targetArea: string
  -eventDateTime: Date
  -headcountQuota: number
  -registeredCount: number
  -priority: string
  -description: string
  -contactPerson: ContactDetails
  -status: ActivityStatus
  -createdBy: number
  +remainingSlots() number
  +isFull() boolean
  +canAcceptRegistration(now: Date) boolean
  +refreshStatus(now: Date) void
}

class VolunteerRegistration {
  <<entity>>
  -id: number
  -activityId: number
  -contact: ContactDetails
  -consentGiven: boolean
  -registeredAt: Date
}

class NotificationLog {
  <<entity>>
  -id: number
  -subjectType: string
  -subjectId: number
  -channel: ChannelType
  -recipient: string
  -status: DeliveryStatus
  -errorMessage: string
  -attemptCount: number
  -createdAt: Date
}

class ReportStatus {
  <<enumeration>>
  UNVERIFIED
  VERIFIED_ACTIVE
  RESOLVED
  DISMISSED
}
class ActivityStatus {
  <<enumeration>>
  OPEN
  FULL
  COMPLETED
  CANCELLED
}

HotspotReport *-- "1" GeoLocation
HotspotReport *-- "0..1" ContactDetails
HotspotReport "0..*" --> "0..1" Official : reviewedBy
HotspotReport --> ReportStatus
Hotspot *-- "1" GeoLocation
Hotspot "0..1" --> "0..1" HotspotReport : created from
Hotspot "0..*" --> "1" Official : createdBy
PublicAlert "0..*" --> "1" Official : publishedBy
VolunteerActivity "0..*" --> "1" Official : createdBy
VolunteerActivity o-- "0..*" VolunteerRegistration : registrations
VolunteerActivity --> ActivityStatus
VolunteerRegistration *-- "1" ContactDetails
NotificationLog "0..*" --> "1" PublicAlert : about
DengueCluster *-- "1..*" GeoLocation
```

Other enumerations: `OfficialRole {OFFICIAL, ADMIN}`, `Severity {LOW, MEDIUM, HIGH, CRITICAL}`, `RiskLevel {LOW, HIGH}`, `HotspotSource {OFFICIAL, VERIFIED_REPORT}`, `BreedingSiteType {STAGNANT_WATER, CONTAINER, DRAIN, PLANT_POT, CONSTRUCTION_SITE, OTHER}`, `ChannelType {SMS, EMAIL}`, `DeliveryStatus {SENT, FAILED, PENDING_RETRY}`.

**Key business rules held in entities**
- `HotspotReport.canTransitionTo()`: allowed transitions are UNVERIFIED → VERIFIED_ACTIVE | DISMISSED, and VERIFIED_ACTIVE → RESOLVED. All others are rejected (UC8).
- `VolunteerActivity.remainingSlots() = headcountQuota − registeredCount`; `isFull()` when it is 0 (UC6 2a).
- `VolunteerActivity.refreshStatus(now)`: COMPLETED once `eventDateTime` < now (UC9 special requirement), FULL when full, otherwise OPEN.
- `DengueCluster.riskLevel()`: HIGH if caseCount ≥ 10, else LOW. This mirrors NEA's red/yellow cluster alert levels.
- `PublicAlert.toSmsText()`: truncates to 160 characters (UC7 special requirement).

## 2.4 Control, container and boundary classes (backend)

![Control, container and boundary classes](diagrams/02-control-boundary-classes.png)

*(Rendered image. The diagram source below is the editable version.)*

```mermaid
classDiagram
direction TB

class ServerApp {
  <<startup>>
  -config: Config
  -expressApp: Express
  +start() Promise~void~
  -buildRepositories() void
  -buildControllers() void
  -registerRoutes() void
}

class MapController {
  <<control>>
  +getMapData(filter, now) Promise~MapData~
  +searchAddress(query: string) Promise~GeoLocation[]~
  +reverseGeocode(lat, lng) Promise~GeoLocation~
}
class HotspotReportController {
  <<control>>
  +submitReport(input, photo, now) Promise~string~
  +listReports(filter) Promise~HotspotReport[]~
  +getReport(referenceId) Promise~HotspotReport~
  +reviewReport(referenceId, newStatus, officialId, expectedVersion, now) Promise~HotspotReport~
}
class HotspotManagementController {
  <<control>>
  +listHotspots(filter) Promise~Hotspot[]~
  +addHotspot(input, officialId) Promise~Hotspot~
  +removeHotspot(hotspotId) Promise~void~
}
class PublicAlertController {
  <<control>>
  +listPublishedAlerts() Promise~PublicAlert[]~
  +getAlert(id) Promise~PublicAlert~
  +publishAlert(input, officialId, now) Promise~PublishResult~
  +previewAlert(input) AlertPreview
}
class SubscriptionController {
  <<control>>
  +subscribe(input) Promise~AlertSubscription~
}
class VolunteerActivityController {
  <<control>>
  +listActivities(filter, now) Promise~VolunteerActivity[]~
  +createActivity(input, officialId, now) Promise~VolunteerActivity~
  +editActivity(id, changes, now) Promise~VolunteerActivity~
  +getActivityStatus(id, now) Promise~ActivityStatusSummary~
  +getRoster(id) Promise~VolunteerRegistration[]~
}
class VolunteerEnrollmentController {
  <<control>>
  +listOpenActivities(now) Promise~VolunteerActivity[]~
  +register(activityId, input, now) Promise~VolunteerRegistration~
}
class AuthController {
  <<control>>
  +login(username, password, now) Promise~LoginResult~
  +logout(token) void
  +verifyToken(token) TokenPayload
}
class NotificationService {
  <<control>>
  -channels: Map~ChannelType, NotificationChannel~
  +notifyAlertPublished(alert) Promise~DispatchSummary~
  +notifyActivityPublished(activity) Promise~DispatchSummary~
  +sendSubscriptionConfirmation(sub) Promise~void~
}
class InputValidator {
  <<control>>
  +isValidSingaporePhone(phone)$ boolean
  +isValidEmail(email)$ boolean
  +validatePhoto(file)$ ValidationResult
  +validateReportInput(input)$ ValidationResult
  +validateRegistrationInput(input)$ ValidationResult
  +validateActivityInput(input, now, registeredCount)$ ValidationResult
  +validateAlertInput(input)$ ValidationResult
  +validateSubscriptionInput(input)$ ValidationResult
  +validateHotspotInput(input, knownDiseaseTypes)$ ValidationResult
  +validateLocation(location)$ ValidationResult
  +validateOptionalContact(contact)$ ValidationResult
}

class Repository~T~ {
  <<container>>
  +findById(id) Promise~T~
  +findAll(filter) Promise~T[]~
  +save(entity: T) Promise~T~
}
class Database {
  <<singleton>>
  +getInstance()$ Database
  +query(sql, params) Promise~Rows~
  +transaction(work) Promise~R~
}

class OneMapAdapter {
  <<boundary>>
  +search(address) Promise~GeoLocation[]~
  +reverseGeocode(lat, lng) Promise~GeoLocation~
}
class DataGovAdapter {
  <<boundary>>
  +fetchDengueClusters() Promise~DengueCluster[]~
}
class NotificationChannel {
  <<interface>>
  +type: ChannelType
  +send(recipient, message) Promise~void~
}
class SmsChannel {
  <<boundary>>
}
class EmailChannel {
  <<boundary>>
}

NotificationChannel <|.. SmsChannel
NotificationChannel <|.. EmailChannel
NotificationService o-- NotificationChannel

ServerApp ..> MapController : creates
ServerApp ..> Database : creates

MapController --> OneMapAdapter
MapController --> DataGovAdapter
MapController --> Repository : HotspotRepository, ClusterCacheRepository
HotspotReportController --> Repository : HotspotReportRepository, HotspotRepository
HotspotReportController ..> InputValidator
HotspotManagementController --> Repository : HotspotRepository
HotspotManagementController --> OneMapAdapter
PublicAlertController --> Repository : PublicAlertRepository
PublicAlertController --> NotificationService
SubscriptionController --> Repository : SubscriptionRepository
SubscriptionController --> NotificationService
VolunteerActivityController --> Repository : VolunteerActivityRepository, VolunteerRegistrationRepository
VolunteerActivityController --> NotificationService
VolunteerEnrollmentController --> Repository : VolunteerActivityRepository, VolunteerRegistrationRepository
AuthController --> Repository : OfficialRepository
NotificationService --> Repository : SubscriptionRepository, NotificationLogRepository
Repository --> Database
```

**Concrete repositories** (all extend `Repository<T>`): `OfficialRepository`, `HotspotReportRepository`, `HotspotRepository`, `ClusterCacheRepository`, `PublicAlertRepository`, `SubscriptionRepository`, `VolunteerActivityRepository`, `VolunteerRegistrationRepository`, `NotificationLogRepository`. Extra query methods:
- `HotspotReportRepository.findByStatus(filter)`, `updateStatusWithVersion(report, expectedVersion)` (optimistic locking, UC8 4a)
- `HotspotRepository.findActive(filter)`, `findDiseaseTypeCodes()` (NFR-08)
- `OfficialRepository.findByUsername(username)`, `updateLoginState(official)`
- `PublicAlertRepository.findLatest(limit)`
- `VolunteerActivityRepository.findUpcoming(now)`, `findByIdForUpdate(id)` (row lock inside a transaction)
- `VolunteerRegistrationRepository.findByActivity(id)`, `existsByActivityAndContact(id, email, phone)` (UC6 duplicate check)
- `SubscriptionRepository.findByRegion(region)`, `findVolunteerNewsSubscribers()`, `existsByContact(email, phone)`
- `ClusterCacheRepository.saveSnapshot(clusters, syncedAt)`, `getLatestSnapshot()` (UC1 2a "last known state")

**HTTP boundary (`boundary/routes`)**: `publicRoutes` (`/api/alerts`, `/api/map`, `/api/reports`, `/api/volunteer-activities`, `/api/subscriptions`), `authRoutes` (`/api/auth/login`, `/api/auth/logout`), `adminRoutes` (`/api/admin/**`, every route guarded by `requireOfficial` middleware).

## 2.5 Boundary classes (frontend, React)

| Boundary class (page/component) | Dialog-map state | Calls (via `ApiClient`) | Use case |
|---|---|---|---|
| `HomePage` | Public Alerts Page | `GET /api/alerts` | UC16 |
| `AlertDetailPage` | Alert Detail | `GET /api/alerts/:id` | UC16 |
| `HotspotMapPage` (+ `HotspotMap` component) | Public Heat Map Page | `GET /api/map`, `GET /api/map/search` | UC1, UC2 |
| `ReportHotspotPage` (+ `PhotoUploader`, `ContactDetailsSection`) | Public Report / Breeding Sites Page | `POST /api/reports` | UC3, UC4, UC5 |
| `ReportConfirmationPage` | Confirmation Page | — | UC3 step 7 |
| `VolunteerPage` | Volunteer activity list | `GET /api/volunteer-activities` | UC6 |
| `VolunteerRegistrationForm` | Volunteer form | `POST /api/volunteer-activities/:id/registrations` | UC6 |
| `SubscribePage` | Register SMS | `POST /api/subscriptions` | UC15 |
| `ClinicLocatorPage` *(optional)* | Public Clinic Page | `GET /api/clinics` | UC19 (decision pending) |
| `AdminLoginPage` | Admin Login | `POST /api/auth/login` | UC14 |
| `AdminLayout` + `RequireAuth` | Admin Management (shell with tabs + Logout) | `POST /api/auth/logout` | UC18, NFR-01 |
| `AdminDashboardPage` | Dashboard | `GET /api/admin/dashboard` | FR-18 |
| `HotspotReviewPage` | Report review | `GET/PATCH /api/admin/reports` | UC8 |
| `HotspotManagementPage` | Official Heat Map Page | `GET/POST/DELETE /api/admin/hotspots` | UC17 |
| `AlertManagementPage` + `CreateAlertForm` | Official Alerts Page / Create Alert | `GET/POST /api/admin/alerts` | UC7 |
| `VolunteerManagementPage` + `ActivityForm` | Official Volunteer Page / Create Deployment | `GET/POST/PUT /api/admin/activities` | UC9, UC11 |
| `ActivityStatusPage` | Activity status | `GET /api/admin/activities/:id/status`, `/roster` | UC10 |

## 2.6 Design patterns applied

| Pattern | Where | Why (design principle) |
|---|---|---|
| **Layered / Boundary-Control-Entity (MVC-style)** | Whole system (doc 04) | Separates UI, logic and data. Satisfies NFR-07 (separate public/admin modules) and keeps classes cohesive. |
| **Repository (DAO)** | `repository/*` | Controllers never write SQL, so persistence can change without touching logic (loose coupling, NFR-08). This replaces the Lab 2 "Database Transaction Controller", which would have been a low-cohesion "god class". |
| **Strategy** | `NotificationChannel` ← `SmsChannel`, `EmailChannel` | `NotificationService` sends through any channel without knowing which one it is. Adding WhatsApp later means one new class (open/closed principle, FR-26/27). |
| **Adapter** | `OneMapAdapter`, `DataGovAdapter` | Converts external JSON / GeoJSON into our entities, so an API change only affects one class. |
| **Observer (publish–subscribe)** | `PublicAlertController` / `VolunteerActivityController` → `NotificationService` → subscribers | Publishing an alert does not depend on how many subscribers or channels exist (FR-24, FR-25). |
| **Singleton** | `Config`, `Database` | One shared configuration and one connection pool |
| **Façade** | `MapController` | One call (`getMapData`) hides OneMap + data.gov.sg + cache fallback from the UI |
| **Chain of Responsibility** | Express middleware: `requireOfficial` → `errorHandler` | Access control is applied uniformly before admin routes (NFR-01) |
| **Dependency Injection / Composition Root** | `ServerApp` | All objects are created in one place and passed via constructors, which makes control classes easy to unit-test with fake repositories in Lab 4 |

## 2.7 Traceability: use case → classes

| UC | Boundary | Control | Entity / Container |
|---|---|---|---|
| UC1, UC2 | `HotspotMapPage`, `HotspotMap`, `OneMapAdapter`, `DataGovAdapter` | `MapController` | `DengueCluster`, `Hotspot`, `GeoLocation`, `HotspotRepository`, `ClusterCacheRepository` |
| UC3–UC5 | `ReportHotspotPage`, `PhotoUploader`, `ContactDetailsSection` | `HotspotReportController`, `InputValidator` | `HotspotReport`, `ContactDetails`, `HotspotReportRepository` |
| UC6 | `VolunteerPage`, `VolunteerRegistrationForm` | `VolunteerEnrollmentController`, `InputValidator` | `VolunteerActivity`, `VolunteerRegistration`, repositories |
| UC7 | `AlertManagementPage`, `CreateAlertForm`, `SmsChannel`, `EmailChannel` | `PublicAlertController`, `NotificationService` | `PublicAlert`, `AlertSubscription`, `NotificationLog` |
| UC8 | `HotspotReviewPage` | `HotspotReportController` | `HotspotReport`, `Hotspot` |
| UC9–UC11 | `VolunteerManagementPage`, `ActivityForm`, `ActivityStatusPage` | `VolunteerActivityController`, `NotificationService` | `VolunteerActivity`, `VolunteerRegistration` |
| UC14, UC18 | `AdminLoginPage`, `AdminLayout`, `requireOfficial` | `AuthController` | `Official`, `OfficialRepository` |
| UC15 | `SubscribePage` | `SubscriptionController`, `NotificationService` | `AlertSubscription` |
| UC16 | `HomePage`, `AlertDetailPage` | `PublicAlertController` | `PublicAlert` |
| UC17 | `HotspotManagementPage` | `HotspotManagementController` | `Hotspot` |

## 2.8 Note for Lab 4 testing (forward planning)

Lab 4 needs **black-box tests on one important control class** and **basis-path tests on two complex methods**. This design deliberately isolates good candidates:
- Black-box (equivalence classes + boundary values): `InputValidator` or `VolunteerEnrollmentController.register()`. Examples: phone length 7/8/9 digits, first digit 6/8/9, photo size just below / at / above 5 MB, quota 0/1/remaining.
- Basis path: `HotspotReport.transitionTo()` / `HotspotReportController.reviewReport()` (multiple status branches + version conflict), and `VolunteerEnrollmentController.register()` (validation → activity exists → open → not full → not duplicate → save).
