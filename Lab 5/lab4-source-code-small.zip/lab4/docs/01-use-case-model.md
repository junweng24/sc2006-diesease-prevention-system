# 1. Complete Use Case Model

**Project:** Disease Prevention System — Team VibeCoders
**Status:** DRAFT for team review (AI-assisted, see README)
**Based on:** Lab 1 requirements (FR-01..FR-27, NFR-01..NFR-10) and Lab 2 use cases UC1..UC15

---

## 1.1 Actors

| Actor | Type | Description |
|---|---|---|
| Public User | Primary, human | Anonymous resident visiting the public website. Does **not** need an account. |
| Official | Primary, human | Authenticated health / environmental official (MOH, NEA) using the officials' portal. |
| OneMap API | Secondary, system | Singapore Land Authority geocoding / reverse geocoding and base map service. |
| data.gov.sg API | Secondary, system | Source of NEA dengue cluster data (and CHAS clinic data, if the clinic locator is kept). |
| SMS Gateway | Secondary, system | External service that delivers SMS notifications. |
| Email Gateway | Secondary, system | External service (SMTP / transactional email) that delivers email notifications. |

> Change from Lab 2: "Database" is no longer shown as an actor. The database is part of our own system, not an external actor. It is internal to the system boundary (see §1.4, note on UC12/UC13).

## 1.2 Use Case List (final)

| ID | Use Case | Primary Actor | Requirements | Relationships | Change vs Lab 2 |
|---|---|---|---|---|---|
| UC1 | View Disease Hotspot Map | Public User | FR-04, FR-05, FR-06, NFR-06, NFR-09 | «include» UC2 | — |
| UC2 | Geolocation Lookup | Public User | FR-04, FR-08 | included by UC1, UC3 | — |
| UC3 | Report Disease Hotspot | Public User | FR-07..FR-10, FR-13, NFR-03, NFR-04, NFR-10 | «include» UC2; «extend» by UC4, UC5 | — |
| UC4 | Attach a Photo | Public User | FR-11 | «extend» UC3 | — |
| UC5 | Provide Contact Details | Public User | FR-12, NFR-02 | «extend» UC3 | — |
| UC6 | Register for Volunteer Activity | Public User | FR-14, FR-15, FR-16, NFR-03 | — | Removed «include» UC12 (see §1.4) |
| UC7 | Publish Public Alert | Official | FR-22, FR-24, FR-26, FR-27, NFR-01 | — | Renamed from "Send public alert notification" |
| UC8 | Review Hotspot Reports | Official | FR-18, FR-19, NFR-01 | — | Renamed from "Manage hotspots and alerts"; scope narrowed |
| UC9 | Create Volunteering Activity | Official | FR-23, FR-25, NFR-01 | — | Added step: notify subscribed volunteers (FR-25) |
| UC10 | Check Activity Status | Official | FR-18, FR-23, NFR-02 | — | UC13 "View information" folded in as an optional step (see §1.4) |
| UC11 | Edit Volunteer Activity | Official | FR-23, FR-25 | — | — |
| UC14 | Authenticate Official | Official | FR-17, NFR-01 | — | — |
| UC15 | Subscribe to Public Alerts | Public User | FR-24, FR-26, FR-27, NFR-02 | — | — |
| **UC16** | **View Public Health Alerts** | Public User | FR-01, FR-02, FR-03, NFR-05 | — | **NEW** — FR-02/FR-03 had no use case |
| **UC17** | **Add / Remove Hotspot** | Official | FR-20, FR-21, NFR-08 | — | **NEW** — FR-20/FR-21 were only implied by UC8 |
| **UC18** | **Log Out** | Official | NFR-01 | — | **NEW** — shown on Lab 2 dialog map but had no use case |
| (UC19) | (Locate Nearest Clinic) | Public User | *(no FR yet)* | — | **DECISION NEEDED** — see §1.4 |

UC12 "Update information" and UC13 "View information" are **retired** (see §1.4).

## 1.3 Use Case Diagram (PlantUML source)

![Use case diagram](diagrams/01-use-case-diagram.png)

*(Rendered image. The diagram source below is the editable version.)*

> Redraw in Visual Paradigm. This source can also be rendered at any PlantUML renderer.

```plantuml
@startuml
left to right direction
skinparam packageStyle rectangle
actor "Public User" as PU
actor "Official" as OF
actor "OneMap API" as OM <<system>>
actor "data.gov.sg API" as DG <<system>>
actor "SMS Gateway" as SMS <<system>>
actor "Email Gateway" as EM <<system>>

rectangle "Disease Prevention System" {
  usecase "UC16 View Public Health Alerts" as UC16
  usecase "UC1 View Disease Hotspot Map" as UC1
  usecase "UC2 Geolocation Lookup" as UC2
  usecase "UC3 Report Disease Hotspot" as UC3
  usecase "UC4 Attach a Photo" as UC4
  usecase "UC5 Provide Contact Details" as UC5
  usecase "UC6 Register for Volunteer Activity" as UC6
  usecase "UC15 Subscribe to Public Alerts" as UC15

  usecase "UC14 Authenticate Official" as UC14
  usecase "UC18 Log Out" as UC18
  usecase "UC7 Publish Public Alert" as UC7
  usecase "UC8 Review Hotspot Reports" as UC8
  usecase "UC17 Add / Remove Hotspot" as UC17
  usecase "UC9 Create Volunteering Activity" as UC9
  usecase "UC10 Check Activity Status" as UC10
  usecase "UC11 Edit Volunteer Activity" as UC11
}

PU --> UC16
PU --> UC1
PU --> UC3
PU --> UC6
PU --> UC15

UC1 ..> UC2 : <<include>>
UC3 ..> UC2 : <<include>>
UC4 ..> UC3 : <<extend>>
UC5 ..> UC3 : <<extend>>

OF --> UC14
OF --> UC18
OF --> UC7
OF --> UC8
OF --> UC17
OF --> UC9
OF --> UC10
OF --> UC11

UC2 --> OM
UC1 --> DG
UC7 --> SMS
UC7 --> EM
UC9 --> SMS
UC9 --> EM
UC15 --> SMS
UC15 --> EM
@enduml
```

Notes on the diagram:
- Officials' use cases have precondition "Official is authenticated (UC14)". We show this as a **precondition**, not as «include» UC14, because login happens once per session, not inside every use case.
- Arrows from use cases to system actors show that the use case *uses* that external system.

## 1.4 Changes from Lab 2 and why

1. **New UC16 View Public Health Alerts.** FR-02 (home page shows alerts) and FR-03 (select alert to view details) were not covered by any use case. This is a traceability gap the Lab 5 checklist will catch.
2. **New UC17 Add / Remove Hotspot.** FR-20/FR-21 require officials to add and remove hotspots directly. Lab 2 UC8 only covered *reviewing user reports*. UC8 is renamed "Review Hotspot Reports" to match what its flow actually describes.
3. **UC9 now covers FR-25.** Added a step that notifies alert subscribers who opted in to volunteer news when a new activity is published.
4. **UC12 "Update information" and UC13 "View information" retired.** They describe internal database reads and writes, not goals that an actor wants to achieve. In UML a use case should give observable value to an actor. A database insert is a design detail, and it now appears in the design model as Repository classes (see doc 02). Their content is preserved:
   - UC12's insert-vs-update rule becomes the repository `save()` behaviour.
   - UC12's "no loss or duplication" becomes a DB unique constraint + transaction (see doc 05).
   - UC13's "view participant roster" becomes step 3 of UC10.
   - UC13's 3 s timeout / 500 ms read target becomes an implementation constraint in doc 05.
   > If your supervisor previously approved UC12/UC13, you may keep them. In that case, at least move "Database" off the actor list.
5. **UC18 Log Out added.** The Lab 2 dialog map already has a Logout transition.
6. **UC7 renamed** to "Publish Public Alert" because publishing to the feed is the main goal. SMS and email dispatch are secondary effects.
7. **Clinic locator (dialog map has a "Public Clinic Page") — DECISION NEEDED.** No FR covers it. Either:
   - (a) add **FR-28** "The system shall allow residents to view CHAS clinics near a selected location" plus **UC19 Locate Nearest Clinic**, or
   - (b) remove the Clinic page from the dialog map.
   The design and skeleton include it as an optional module, which is easy to delete.

## 1.5 New / changed use case descriptions

### UC16 View Public Health Alerts
| Field | Content |
|---|---|
| Actor | Public User |
| Description | Allows a public user to read the latest public health news and alerts and view the details of one alert [FR-01, FR-02, FR-03] |
| Preconditions | User has internet access |
| Postconditions | Selected alert details are displayed |
| Flow of events | 1. User opens the home page → System retrieves published alerts sorted by most recent and displays them as cards (title, severity, region, date) [FR-02]<br>2. User selects an alert card → System displays full alert details (title, body, category, severity, region, publish time) [FR-03]<br>3. User clicks "Back" → System returns to the alert feed |
| Alternative flows | 1a. No alerts published: System displays "No active alerts in your area". |
| Exceptions | 1b. Server unreachable: System shows an error banner and a retry button [NFR-04]. |
| Special requirements | Home page loads within 3 s [NFR-05]; responsive [NFR-09] |

### UC17 Add / Remove Hotspot
| Field | Content |
|---|---|
| Actor | Official |
| Description | Allows an official to add a new disease hotspot directly or remove an existing one from the public map [FR-19, FR-20, FR-21] |
| Preconditions | Official is authenticated [NFR-01] and on the "Hotspots" tab |
| Postconditions | Hotspot is created or removed and the public map reflects the change [NFR-08] |
| Flow of events | 1. Official opens the "Hotspots" tab → System lists existing hotspots and shows them on a map [FR-19]<br>2. Official clicks "Add hotspot" → System opens the form (location, disease type, case count, risk level)<br>3. Official enters details and places the pin → System validates the location via OneMap and checks required fields<br>4. Official clicks "Save" → System stores the hotspot and refreshes the public map dataset [FR-20]<br>5. System shows a confirmation |
| Alternative flows | 2a. Remove hotspot: Official selects a hotspot and clicks "Remove", then confirms → System marks the hotspot as removed (soft delete) and it disappears from the public map [FR-21]. |
| Exceptions | 3a. Invalid location / missing fields → highlighted in red, nothing stored [NFR-04]. Session expired → re-authenticate [NFR-01]. |
| Special requirements | New disease types are selectable from a configurable list, not hard-coded [NFR-08] |

### UC18 Log Out
| Field | Content |
|---|---|
| Actor | Official |
| Flow of events | 1. Official clicks "Logout" → System invalidates the session token and returns to the Admin Login page |
| Postconditions | Official must re-authenticate to access the portal [NFR-01] |

### UC9 Create Volunteering Activity — revised steps 5–6
5. System publishes the activity on the public "Become a volunteer" page **and asks the Notification service to inform alert subscribers who opted in to volunteer notifications, via SMS and/or email [FR-25]**
6. System displays the confirmation banner to the official

### UC10 Check Activity Status — revised step 3 (absorbs UC13)
3. (optional) Official clicks "View roster" → System retrieves and displays registered volunteers' names and contact details. These are visible to authenticated officials only [NFR-02].

## 1.6 Requirements → Use Case Traceability

| Req | Use case(s) |
|---|---|
| FR-01 | UC1, UC3, UC6, UC16 |
| FR-02, FR-03 | UC16 |
| FR-04, FR-05, FR-06 | UC1 (UC2) |
| FR-07 – FR-13 | UC3, UC4 (FR-11), UC5 (FR-12) |
| FR-14 – FR-16 | UC6 |
| FR-17 | UC14 |
| FR-18 | UC8, UC10 |
| FR-19 | UC8, UC17 |
| FR-20, FR-21 | UC17 |
| FR-22 | UC7 |
| FR-23 | UC9, UC10, UC11 |
| FR-24 | UC7, UC15 |
| FR-25 | UC9, UC11 |
| FR-26, FR-27 | UC7, UC9, UC15 |
| NFR-01 | UC7–UC11, UC14, UC17, UC18 |
| NFR-02 | UC5, UC10 |
| NFR-03 / NFR-04 | UC3, UC6, UC9, UC11 |

Every FR from Lab 1 now maps to at least one use case.
