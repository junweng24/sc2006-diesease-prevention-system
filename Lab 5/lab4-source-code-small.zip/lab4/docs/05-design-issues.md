# 5. Key Design Issues (Bruegge §7.4)

**Status:** DRAFT for team review (AI-assisted, see README)

Lab 3 (3.2.1) asks us to address two design issues from Bruegge ch. 7.4:
1. identifying and storing **persistent data**, and
2. providing **access control**.

A short note on **boundary conditions** (start-up, shutdown, failure) is added at the end because several use cases depend on them.

---

## 5.1 Persistent data

### 5.1.1 What must persist, and what doesn't

| Data | Persistent? | Storage | Reason |
|---|---|---|---|
| Official accounts | Yes | `officials` table | Needed for login (UC14); passwords stored as **bcrypt hash only** |
| Hotspot reports | Yes | `hotspot_reports` table | Must survive until reviewed (UC3 postcondition, NFR-03) |
| Report photos | Yes | File storage `uploads/` (path stored in DB) | Binary files do not belong in table rows. The DB keeps the path only. |
| Official hotspots | Yes | `hotspots` table | FR-19..21. Removal is a **soft delete** (`is_active = false`) for audit. |
| Dengue clusters (data.gov.sg) | Cached | `cluster_snapshots` table (JSON + `synced_at`) | Source of truth is external, but UC1 2a needs the "last known state" when the API is down |
| Public alerts | Yes | `public_alerts` table | Home feed (FR-02) + audit of who published |
| Alert subscriptions | Yes | `alert_subscriptions` table | FR-24..27; contains personal data (PDPA) |
| Volunteer activities | Yes | `volunteer_activities` table | FR-23 |
| Volunteer registrations | Yes | `volunteer_registrations` table | FR-14..16; personal data |
| Notification delivery log | Yes | `notification_logs` table | UC7 6a: failed recipients are kept for retry |
| Login session | No (stateless) | Signed JWT in httpOnly cookie | No session table needed; expiry is inside the token |
| Map view state, form drafts | No | Browser memory only | Transient UI state |
| Disease types, breeding site types | Yes (reference data) | `disease_types` table / enum | NFR-08: adding a disease type means adding a row, not changing code |

### 5.1.2 Choice of storage

We use a **relational database (PostgreSQL)** rather than flat files or a document store because:
- the data is **highly structured and related**: activities ↔ registrations, reports → hotspots, officials → alerts;
- we need **transactions** so a registration and the activity's `registered_count` update succeed or fail together (NFR-03, NFR-04: no incomplete record stored);
- we need **unique constraints** to prevent duplicate registrations (UC6 2a, NFR-03), which the DB guarantees even under concurrent requests;
- concurrent edits by two officials (UC8 4a) are handled with a `version` column (**optimistic locking**). The repository's `UPDATE … WHERE version = $expected` affects 0 rows if someone else saved first.

### 5.1.3 Database schema (ER diagram)

![ER diagram](diagrams/05-er-diagram.png)

*(Rendered image. The diagram source below is the editable version.)*

Full DDL is in [`server/db/schema.sql`](../server/db/schema.sql).

```mermaid
erDiagram
  OFFICIALS ||--o{ PUBLIC_ALERTS : publishes
  OFFICIALS ||--o{ VOLUNTEER_ACTIVITIES : creates
  OFFICIALS ||--o{ HOTSPOTS : creates
  OFFICIALS |o--o{ HOTSPOT_REPORTS : reviews
  HOTSPOT_REPORTS |o--o| HOTSPOTS : "verified into"
  VOLUNTEER_ACTIVITIES ||--o{ VOLUNTEER_REGISTRATIONS : has
  PUBLIC_ALERTS ||--o{ NOTIFICATION_LOGS : "dispatch results"

  OFFICIALS {
    serial id PK
    varchar username UK
    varchar password_hash
    varchar role
    int failed_login_attempts
    timestamptz locked_until
  }
  HOTSPOT_REPORTS {
    varchar reference_id PK
    numeric latitude
    numeric longitude
    varchar address
    varchar site_type
    text description
    varchar photo_path
    varchar contact_name
    varchar contact_phone
    varchar contact_email
    varchar status
    timestamptz submitted_at
    int reviewed_by FK
    timestamptz reviewed_at
    int version
  }
  HOTSPOTS {
    serial id PK
    varchar disease_type
    numeric latitude
    numeric longitude
    varchar address
    int case_count
    varchar risk_level
    varchar source
    varchar source_report_id FK
    boolean is_active
    int created_by FK
  }
  PUBLIC_ALERTS {
    serial id PK
    varchar title
    text body
    varchar category
    varchar severity
    varchar target_region
    timestamptz published_at
    int published_by FK
  }
  ALERT_SUBSCRIPTIONS {
    serial id PK
    varchar email UK
    varchar phone UK
    varchar channels
    varchar region
    boolean wants_volunteer_news
    boolean consent_given
  }
  VOLUNTEER_ACTIVITIES {
    serial id PK
    varchar title
    varchar target_area
    timestamptz event_datetime
    int headcount_quota
    int registered_count
    varchar priority
    text description
    varchar status
    int created_by FK
  }
  VOLUNTEER_REGISTRATIONS {
    serial id PK
    int activity_id FK
    varchar name
    varchar phone
    varchar email
    boolean consent_given
    timestamptz registered_at
  }
  NOTIFICATION_LOGS {
    serial id PK
    varchar subject_type
    int subject_id
    varchar channel
    varchar recipient
    varchar status
    text error_message
    int attempt_count
  }
  CLUSTER_SNAPSHOTS {
    serial id PK
    jsonb clusters
    timestamptz synced_at
  }
```

Key constraints:
- `UNIQUE (activity_id, email)` and `UNIQUE (activity_id, phone)` on `volunteer_registrations` prevent duplicate registrations (UC6 2a).
- `CHECK (registered_count <= headcount_quota)` makes overbooking impossible at DB level.
- Volunteer registration runs in **one transaction**: `SELECT … FOR UPDATE` on the activity, check `remainingSlots() > 0`, insert the registration, then increment `registered_count`.

### 5.1.4 Protecting personal data (PDPA, NFR-02)

- All traffic goes over **HTTPS** in deployment (encrypted in transit, UC5/UC6 special requirements).
- Contact fields are returned **only by `/api/admin/**` endpoints**. Public endpoints return reports and registrations without contact details.
- Explicit **consent checkbox** (`consent_given`) is required for subscriptions and registrations.
- *(Stretch)* column-level encryption at rest using PostgreSQL `pgcrypto` for phone/email.

---

## 5.2 Access control

### 5.2.1 Actors / roles

| Role | How identified |
|---|---|
| **Public (anonymous)** | No login |
| **Official** | Logged in; JWT contains `{officialId, role: "OFFICIAL"}` |
| **Admin** | An official with `role: "ADMIN"`. Can also unlock locked accounts (UC14 2b: "approach admin to unlock") |

### 5.2.2 Access matrix

| Object / operation | Public | Official | Admin |
|---|---|---|---|
| View published alerts (UC16) | ✔ | ✔ | ✔ |
| View hotspot map (UC1) | ✔ | ✔ | ✔ |
| Submit hotspot report (UC3–5) | ✔ | ✔ | ✔ |
| View **own** report confirmation by reference ID | ✔ (status only, no contact data) | ✔ | ✔ |
| Register for volunteer activity (UC6) | ✔ | — | — |
| Subscribe to alerts (UC15) | ✔ | — | — |
| View officials' dashboard (FR-18) | ✘ | ✔ | ✔ |
| View report details **including contact info and photo** (UC8) | ✘ | ✔ | ✔ |
| Change report status (UC8) | ✘ | ✔ | ✔ |
| Add / remove hotspot (UC17) | ✘ | ✔ | ✔ |
| Publish alert + dispatch SMS/email (UC7) | ✘ | ✔ | ✔ |
| Create / edit volunteer activity (UC9, UC11) | ✘ | ✔ | ✔ |
| View volunteer roster with contact details (UC10) | ✘ | ✔ | ✔ |
| Unlock official accounts / create officials | ✘ | ✘ | ✔ |

### 5.2.3 How it is enforced

1. **Authentication (UC14):** `AuthController.login()` loads the `Official` and rejects the attempt if `isLocked(now)`. It then compares the password with the bcrypt hash.
   - On failure it calls `recordFailedLogin()`. After **5** failures the account is locked for **15 minutes**.
   - On success it resets the counter and issues a JWT valid for **30 minutes**, stored in an **httpOnly, SameSite=Strict** cookie. This blocks access from JavaScript (XSS) and cross-site requests (CSRF).
2. **Authorisation:** every `/api/admin/**` route passes through the `requireOfficial` middleware. It verifies the JWT signature and expiry and attaches `req.official`. Admin-only routes also go through `requireRole('ADMIN')`. Expired tokens return **401**, and the SPA sends the user back to Admin Login (UC7 exception 1a).
3. **Defence in depth:** the React `RequireAuth` guard hides admin pages, but **the server never trusts the client**. Every admin request is checked again.
4. **Logout (UC18):** clears the cookie. Tokens are short-lived, so no server-side blacklist is needed for this project.
5. **Input validation:** every request body is validated server-side by `InputValidator` (never only client-side). All SQL uses **parameterised queries** to prevent SQL injection.

---

## 5.3 Boundary conditions (brief)

| Condition | Handling |
|---|---|
| **Start-up** | `ServerApp.start()` loads config, connects to the DB (fails fast if unreachable), creates repositories, adapters, services and controllers, registers routes, then starts listening. |
| **Shutdown** | On SIGINT/SIGTERM it stops accepting requests and closes the DB pool |
| **External API failure** | data.gov.sg down → serve cached snapshot with "last synced" time (UC1 2a). OneMap down → user can place a pin manually (UC3 2a). SMS/email failure → logged in `notification_logs`; the alert is still published (UC7 6a). |
| **DB write failure** | Transaction rolled back; client receives an error and keeps its form inputs (UC9 4a, NFR-04) |
